import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { format, formatDistanceToNow, isToday, isTomorrow, isYesterday, parseISO } from "date-fns";
import { ru } from "date-fns/locale";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function normalizePhone(phone: string): string {
  if (!phone) return "";
  let cleaned = phone.replace(/[^\d+]/g, "");
  if (!cleaned.startsWith("+")) {
    if (cleaned.startsWith("994")) {
      cleaned = "+" + cleaned;
    } else if (cleaned.startsWith("0")) {
      cleaned = "+994" + cleaned.substring(1);
    } else {
      cleaned = "+" + cleaned;
    }
  }
  return cleaned;
}

export function formatPhone(phone: string): string {
  const norm = normalizePhone(phone);
  if (norm.startsWith("+994") && norm.length === 13) {
    // +994 50 123 45 67
    return `${norm.slice(0, 4)} ${norm.slice(4, 6)} ${norm.slice(6, 9)} ${norm.slice(9, 11)} ${norm.slice(11, 13)}`;
  }
  return phone || norm;
}

export function formatCurrency(amount: number): string {
  return `$${Number(amount).toFixed(amount % 1 === 0 ? 0 : 2)}`;
}

export function formatRelativeDate(dateInput: string | Date | null | undefined): string {
  if (!dateInput) return "Никогда";
  const date = typeof dateInput === "string" ? parseISO(dateInput) : dateInput;
  if (isNaN(date.getTime())) return "—";

  return formatDistanceToNow(date, { addSuffix: true, locale: ru });
}

export function formatAppointmentDate(dateInput: string | Date): string {
  const date = typeof dateInput === "string" ? parseISO(dateInput) : dateInput;
  if (isToday(date)) return `Сегодня, ${format(date, "d MMMM", { locale: ru })}`;
  if (isTomorrow(date)) return `Завтра, ${format(date, "d MMMM", { locale: ru })}`;
  if (isYesterday(date)) return `Вчера, ${format(date, "d MMMM", { locale: ru })}`;
  return format(date, "d MMMM yyyy", { locale: ru });
}

export function formatTimeRange(start: string | Date, end: string | Date): string {
  const startDate = typeof start === "string" ? parseISO(start) : start;
  const endDate = typeof end === "string" ? parseISO(end) : end;
  return `${format(startDate, "HH:mm")} – ${format(endDate, "HH:mm")}`;
}

export const APPOINTMENT_STATUS_MAP = {
  pending: {
    label: "Ожидает",
    bg: "bg-amber-50 text-amber-700 border-amber-200",
    dot: "bg-amber-500",
  },
  completed: {
    label: "Завершён",
    bg: "bg-emerald-50 text-emerald-700 border-emerald-200",
    dot: "bg-emerald-500",
  },
  no_show: {
    label: "Не пришёл",
    bg: "bg-rose-50 text-rose-700 border-rose-200",
    dot: "bg-rose-500",
  },
  cancelled: {
    label: "Отменён",
    bg: "bg-zinc-100 text-zinc-600 border-zinc-200",
    dot: "bg-zinc-400",
  },
} as const;

export type AppointmentStatusKey = keyof typeof APPOINTMENT_STATUS_MAP;
