export type UserRole = "owner" | "admin" | "barber";

export interface SessionUser {
  id: string;
  shopId: string;
  name: string;
  phone: string | null;
  email: string;
  role: UserRole;
  color: string;
  isActive: boolean;
  shopName: string;
}

export interface BarberScheduleItem {
  id?: string;
  dayOfWeek: number; // 0=Sun, 1=Mon, ..., 6=Sat
  startTime: string;
  endTime: string;
  isWorking: boolean;
}

export interface BarberWithSchedule {
  id: string;
  name: string;
  phone: string | null;
  email: string;
  role: string;
  color: string;
  isActive: boolean;
  schedules: BarberScheduleItem[];
  appointmentCount?: number;
}

export interface ServiceItem {
  id: string;
  name: string;
  durationMinutes: number;
  price: number;
  isActive: boolean;
  sortOrder: number;
}

export interface ClientListItem {
  id: string;
  name: string;
  phone: string;
  phoneNormalized: string;
  notes: string | null;
  isArchived: boolean;
  createdAt: string;
  updatedAt: string;
  visitCount: number;
  lastVisitAt: string | null;
}

export interface ClientNoteItem {
  id: string;
  text: string;
  createdAt: string;
  author: {
    id: string;
    name: string;
    role: string;
  };
}

export interface AppointmentServiceItem {
  id: string;
  serviceId: string;
  price: number;
  durationMinutes: number;
  service: {
    id: string;
    name: string;
  };
}

export interface AppointmentItem {
  id: string;
  shopId: string;
  clientId: string;
  barberId: string;
  createdBy: string;
  startAt: string;
  endAt: string;
  status: "pending" | "completed" | "no_show" | "cancelled";
  totalPrice: number;
  manualDuration: number;
  comment: string | null;
  createdAt: string;
  updatedAt: string;
  cancelledAt: string | null;
  cancelledBy: string | null;
  client: {
    id: string;
    name: string;
    phone: string;
    notes?: string | null;
  };
  barber: {
    id: string;
    name: string;
    color: string;
  };
  services: AppointmentServiceItem[];
}

export interface SentMessageItem {
  id: string;
  shopId: string;
  appointmentId: string | null;
  clientId: string;
  channel: "whatsapp" | "telegram" | "sms";
  type: "reminder_24h" | "reminder_2h" | "manual";
  text: string;
  status: "sent" | "failed" | "pending";
  providerMessageId: string | null;
  errorMessage: string | null;
  sentAt: string | null;
  createdAt: string;
  client: {
    id: string;
    name: string;
    phone: string;
  };
  appointment?: {
    id: string;
    startAt: string;
  } | null;
}

export interface MessageTemplateItem {
  id: string;
  shopId: string;
  type: string;
  title: string;
  text: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}
