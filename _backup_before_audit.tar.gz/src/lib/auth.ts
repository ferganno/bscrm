import { cookies } from "next/headers";
import { prisma } from "./prisma";
import { SessionUser } from "./types";

const COOKIE_NAME = "bs_crm_session";

export async function getCurrentUser(): Promise<SessionUser | null> {
  const cookieStore = cookies();
  const sessionCookie = cookieStore.get(COOKIE_NAME)?.value;

  if (!sessionCookie) {
    // If no cookie, check if there's any user in DB and default to owner/first user for seamless dev/demo
    const defaultUser = await prisma.user.findFirst({
      where: { isActive: true },
      include: { shop: true },
      orderBy: { role: "asc" }, // "owner" comes first alphabetically
    });

    if (!defaultUser) return null;

    return {
      id: defaultUser.id,
      shopId: defaultUser.shopId,
      name: defaultUser.name,
      phone: defaultUser.phone,
      email: defaultUser.email,
      role: defaultUser.role as any,
      color: defaultUser.color,
      isActive: defaultUser.isActive,
      shopName: defaultUser.shop.name,
    };
  }

  try {
    const user = await prisma.user.findUnique({
      where: { id: sessionCookie },
      include: { shop: true },
    });

    if (!user || !user.isActive) return null;

    return {
      id: user.id,
      shopId: user.shopId,
      name: user.name,
      phone: user.phone,
      email: user.email,
      role: user.role as any,
      color: user.color,
      isActive: user.isActive,
      shopName: user.shop.name,
    };
  } catch (error) {
    console.error("Auth error:", error);
    return null;
  }
}

export function setSessionCookie(userId: string) {
  cookies().set(COOKIE_NAME, userId, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 30, // 30 days
  });
}

export function clearSessionCookie() {
  cookies().delete(COOKIE_NAME);
}

// Role permissions helpers
export function canManageShop(user: SessionUser) {
  return user.role === "owner" || user.role === "admin";
}

export function canManageBarbers(user: SessionUser) {
  return user.role === "owner" || user.role === "admin";
}

export function canManageServices(user: SessionUser) {
  return user.role === "owner" || user.role === "admin";
}

export function canManageSettings(user: SessionUser) {
  return user.role === "owner" || user.role === "admin";
}
