import { prisma } from "./prisma";
import { format } from "date-fns";
import { ru } from "date-fns/locale";

export interface TemplateContext {
  clientName: string;
  startAt: Date;
  barberName: string;
  servicesList: string;
  shopAddress: string;
  shopName: string;
}

export function renderMessageTemplate(template: string, ctx: TemplateContext): string {
  const dateStr = format(ctx.startAt, "d MMMM yyyy", { locale: ru });
  const timeStr = format(ctx.startAt, "HH:mm");

  return template
    .replace(/\{имя\}/g, ctx.clientName)
    .replace(/\{дата\}/g, dateStr)
    .replace(/\{время\}/g, timeStr)
    .replace(/\{барбер\}/g, ctx.barberName)
    .replace(/\{услуги\}/g, ctx.servicesList)
    .replace(/\{адрес\}/g, ctx.shopAddress)
    .replace(/\{название_барбершопа\}/g, ctx.shopName);
}

export async function sendNotificationMessage({
  shopId,
  appointmentId,
  clientId,
  channel,
  type,
  text,
  forceSuccess = false,
}: {
  shopId: string;
  appointmentId?: string;
  clientId: string;
  channel: "whatsapp" | "telegram" | "sms";
  type: "reminder_24h" | "reminder_2h" | "manual";
  text: string;
  forceSuccess?: boolean;
}) {
  // Check duplicate prevention: (appointmentId + type + channel) if appointmentId is present
  if (appointmentId && type !== "manual") {
    const existing = await prisma.sentMessage.findFirst({
      where: {
        appointmentId,
        type,
        channel,
        status: "sent",
      },
    });
    if (existing) {
      return { skipped: true, reason: "Already sent successfully", record: existing };
    }
  }

  // Simulate notification gateway (WhatsApp API, Telegram Bot, SMS Gateway)
  // 95% success rate simulation unless forceSuccess is true
  const isFailure = !forceSuccess && Math.random() < 0.05;

  const status = isFailure ? "failed" : "sent";
  const errorMessage = isFailure ? "Gateway timeout / phone unreachable" : null;
  const providerMessageId = isFailure ? null : `msg_${channel}_${Date.now()}_${Math.random().toString(36).substring(7)}`;
  const sentAt = isFailure ? null : new Date();

  const record = await prisma.sentMessage.create({
    data: {
      shopId,
      appointmentId,
      clientId,
      channel,
      type,
      text,
      status,
      providerMessageId,
      errorMessage,
      sentAt,
    },
    include: {
      client: true,
      appointment: true,
    },
  });

  return { skipped: false, record };
}

export async function processAutomaticReminders() {
  const now = new Date();
  // Find all active shops
  const shops = await prisma.shop.findMany({
    include: {
      messageTemplates: { where: { isActive: true } },
    },
  });

  const results: any[] = [];

  for (const shop of shops) {
    const defaultTemplate24h =
      shop.messageTemplates.find((t) => t.type === "reminder_24h")?.text ||
      "Здравствуйте, {имя}! Напоминаем, что завтра у вас запись в {время} к барберу {барбер}. Услуги: {услуги}. Адрес: {адрес}.";
    const defaultTemplate2h =
      shop.messageTemplates.find((t) => t.type === "reminder_2h")?.text ||
      "Здравствуйте, {имя}! Ждём вас сегодня в {время} к барберу {барбер}. Услуги: {услуги}. Адрес: {адрес}.";

    // 24 hours window: appointments starting between [now + 23h, now + 25h]
    if (shop.autoReminder24h) {
      const windowStart = new Date(now.getTime() + 23 * 3600 * 1000);
      const windowEnd = new Date(now.getTime() + 25 * 3600 * 1000);

      const appointments24h = await prisma.appointment.findMany({
        where: {
          shopId: shop.id,
          status: "pending",
          startAt: { gte: windowStart, lte: windowEnd },
        },
        include: {
          client: true,
          barber: true,
          services: { include: { service: true } },
        },
      });

      for (const app of appointments24h) {
        const servicesList = app.services.map((s) => s.service.name).join(", ");
        const text = renderMessageTemplate(defaultTemplate24h, {
          clientName: app.client.name,
          startAt: app.startAt,
          barberName: app.barber.name,
          servicesList: servicesList || "Стрижка",
          shopAddress: shop.address,
          shopName: shop.name,
        });

        const res = await sendNotificationMessage({
          shopId: shop.id,
          appointmentId: app.id,
          clientId: app.client.id,
          channel: (shop.primaryChannel as any) || "whatsapp",
          type: "reminder_24h",
          text,
        });
        results.push({ appointmentId: app.id, type: "reminder_24h", res });
      }
    }

    // 2 hours window: appointments starting between [now + 1.5h, now + 2.5h]
    if (shop.autoReminder2h) {
      const windowStart = new Date(now.getTime() + 1.5 * 3600 * 1000);
      const windowEnd = new Date(now.getTime() + 2.5 * 3600 * 1000);

      const appointments2h = await prisma.appointment.findMany({
        where: {
          shopId: shop.id,
          status: "pending",
          startAt: { gte: windowStart, lte: windowEnd },
        },
        include: {
          client: true,
          barber: true,
          services: { include: { service: true } },
        },
      });

      for (const app of appointments2h) {
        const servicesList = app.services.map((s) => s.service.name).join(", ");
        const text = renderMessageTemplate(defaultTemplate2h, {
          clientName: app.client.name,
          startAt: app.startAt,
          barberName: app.barber.name,
          servicesList: servicesList || "Стрижка",
          shopAddress: shop.address,
          shopName: shop.name,
        });

        const res = await sendNotificationMessage({
          shopId: shop.id,
          appointmentId: app.id,
          clientId: app.client.id,
          channel: (shop.primaryChannel as any) || "whatsapp",
          type: "reminder_2h",
          text,
        });
        results.push({ appointmentId: app.id, type: "reminder_2h", res });
      }
    }
  }

  return results;
}
