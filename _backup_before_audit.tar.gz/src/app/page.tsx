"use client";

import React from "react";
import { AppShell } from "@/components/layout/AppShell";
import { CalendarView } from "@/components/calendar/CalendarView";

export default function CalendarPage() {
  return (
    <AppShell>
      {({ currentUser, openNewAppointment, openAppointmentDetails, refreshTrigger }) => (
        <CalendarView
          currentUser={currentUser}
          onOpenNewAppointment={openNewAppointment}
          onSelectAppointment={openAppointmentDetails}
          refreshTrigger={refreshTrigger}
        />
      )}
    </AppShell>
  );
}
