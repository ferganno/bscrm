"use client";

import React from "react";
import { AppShell } from "@/components/layout/AppShell";
import { ServicesList } from "@/components/services/ServicesList";

export default function ServicesPage() {
  return (
    <AppShell>
      {({ currentUser }) => <ServicesList currentUser={currentUser} />}
    </AppShell>
  );
}
