"use client";

import React from "react";
import { AppShell } from "@/components/layout/AppShell";
import { BarbersList } from "@/components/barbers/BarbersList";

export default function BarbersPage() {
  return (
    <AppShell>
      {({ currentUser }) => <BarbersList currentUser={currentUser} />}
    </AppShell>
  );
}
