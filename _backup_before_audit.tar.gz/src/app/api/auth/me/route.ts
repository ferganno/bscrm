import { NextResponse } from "next/server";
import { getCurrentUser, setSessionCookie } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  // Also return all users in the shop so the UI can allow quick switching for demo/testing
  const allUsers = await prisma.user.findMany({
    where: { shopId: user.shopId },
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      color: true,
      isActive: true,
    },
    orderBy: { role: "asc" },
  });

  return NextResponse.json({
    user,
    availableUsers: allUsers,
  });
}
