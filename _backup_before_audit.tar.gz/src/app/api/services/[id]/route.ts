import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser, canManageServices } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!canManageServices(user)) {
    return NextResponse.json({ error: "Недостаточно прав" }, { status: 403 });
  }

  try {
    const body = await req.json();
    const { name, durationMinutes, price, isActive, sortOrder } = body;

    const data: any = {};
    if (name) data.name = name.trim();
    if (durationMinutes !== undefined) data.durationMinutes = Number(durationMinutes);
    if (price !== undefined) data.price = Number(price);
    if (isActive !== undefined) data.isActive = Boolean(isActive);
    if (sortOrder !== undefined) data.sortOrder = Number(sortOrder);

    const updated = await prisma.service.update({
      where: { id: params.id, shopId: user.shopId },
      data,
    });

    return NextResponse.json({ success: true, service: updated });
  } catch (error: any) {
    console.error("Update service error:", error);
    return NextResponse.json({ error: error.message || "Не удалось обновить услугу" }, { status: 500 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!canManageServices(user)) {
    return NextResponse.json({ error: "Недостаточно прав" }, { status: 403 });
  }

  // Soft delete / archive (Section 31 & 59: is_active = false)
  const archived = await prisma.service.update({
    where: { id: params.id, shopId: user.shopId },
    data: { isActive: false },
  });

  return NextResponse.json({ success: true, service: archived });
}
