import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser, canManageServices } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const activeOnly = searchParams.get("active") === "true";

  const services = await prisma.service.findMany({
    where: {
      shopId: user.shopId,
      ...(activeOnly ? { isActive: true } : {}),
    },
    orderBy: [
      { sortOrder: "asc" },
      { name: "asc" },
    ],
  });

  return NextResponse.json({ services });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!canManageServices(user)) {
    return NextResponse.json({ error: "Недостаточно прав" }, { status: 403 });
  }

  try {
    const body = await req.json();
    const { name, durationMinutes, price, sortOrder } = body;

    if (!name || !name.trim()) {
      return NextResponse.json({ error: "Укажите название услуги" }, { status: 400 });
    }

    const duration = Number(durationMinutes) || 30;
    const priceNum = Number(price) || 0;

    const newService = await prisma.service.create({
      data: {
        shopId: user.shopId,
        name: name.trim(),
        durationMinutes: duration,
        price: priceNum,
        sortOrder: Number(sortOrder) || 0,
        isActive: true,
      },
    });

    return NextResponse.json({ success: true, service: newService });
  } catch (error: any) {
    console.error("Create service error:", error);
    return NextResponse.json({ error: error.message || "Не удалось создать услугу" }, { status: 500 });
  }
}
