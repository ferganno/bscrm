import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { processAutomaticReminders } from "@/lib/notifications";

export async function POST() {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const results = await processAutomaticReminders();
    return NextResponse.json({
      success: true,
      message: `Проверка напоминаний выполнена. Обработано записей: ${results.length}`,
      results,
    });
  } catch (error: any) {
    console.error("Trigger reminders error:", error);
    return NextResponse.json({ error: error.message || "Ошибка отправки напоминаний" }, { status: 500 });
  }
}
