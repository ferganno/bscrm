import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { sendNotificationMessage } from "@/lib/notifications";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const channel = searchParams.get("channel");
  const type = searchParams.get("type");
  const status = searchParams.get("status");

  const whereClause: any = {
    shopId: user.shopId,
  };

  if (channel && channel !== "all") whereClause.channel = channel;
  if (type && type !== "all") whereClause.type = type;
  if (status && status !== "all") whereClause.status = status;

  const messages = await prisma.sentMessage.findMany({
    where: whereClause,
    include: {
      client: {
        select: { id: true, name: true, phone: true },
      },
      appointment: {
        select: { id: true, startAt: true },
      },
    },
    orderBy: { createdAt: "desc" },
    take: 100,
  });

  return NextResponse.json({ messages });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { clientId, appointmentId, channel, text } = await req.json();

    if (!clientId) {
      return NextResponse.json({ error: "Выберите клиента" }, { status: 400 });
    }
    if (!text || !text.trim()) {
      return NextResponse.json({ error: "Введите текст сообщения" }, { status: 400 });
    }

    const client = await prisma.client.findUnique({
      where: { id: clientId, shopId: user.shopId },
    });

    if (!client) {
      return NextResponse.json({ error: "Клиент не найден" }, { status: 404 });
    }

    const result = await sendNotificationMessage({
      shopId: user.shopId,
      appointmentId: appointmentId || undefined,
      clientId: client.id,
      channel: channel || "whatsapp",
      type: "manual",
      text: text.trim(),
      forceSuccess: true,
    });

    const cleanDigits = client.phoneNormalized.replace(/[^\d]/g, "");
    const whatsappUrl = `https://wa.me/${cleanDigits}?text=${encodeURIComponent(text.trim())}`;

    return NextResponse.json({
      success: true,
      message: result.record,
      whatsappUrl,
    });
  } catch (error: any) {
    console.error("Send message error:", error);
    return NextResponse.json({ error: error.message || "Не удалось отправить сообщение" }, { status: 500 });
  }
}
