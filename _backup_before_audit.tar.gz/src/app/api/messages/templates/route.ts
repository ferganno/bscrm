import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser, canManageSettings } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const templates = await prisma.messageTemplate.findMany({
    where: { shopId: user.shopId },
    orderBy: { createdAt: "asc" },
  });

  return NextResponse.json({ templates });
}

export async function PATCH(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!canManageSettings(user)) {
    return NextResponse.json({ error: "Недостаточно прав" }, { status: 403 });
  }

  try {
    const { id, text, title, isActive } = await req.json();
    if (!id) {
      return NextResponse.json({ error: "Template ID is required" }, { status: 400 });
    }

    const data: any = {};
    if (text !== undefined) data.text = text;
    if (title !== undefined) data.title = title;
    if (isActive !== undefined) data.isActive = Boolean(isActive);

    const updated = await prisma.messageTemplate.update({
      where: { id, shopId: user.shopId },
      data,
    });

    return NextResponse.json({ success: true, template: updated });
  } catch (error: any) {
    console.error("Update template error:", error);
    return NextResponse.json({ error: error.message || "Не удалось сохранить шаблон" }, { status: 500 });
  }
}
