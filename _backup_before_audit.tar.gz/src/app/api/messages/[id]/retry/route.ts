import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const existing = await prisma.sentMessage.findUnique({
    where: { id: params.id, shopId: user.shopId },
    include: { client: true },
  });

  if (!existing) {
    return NextResponse.json({ error: "Сообщение не найдено" }, { status: 404 });
  }

  // Section 57: Retry logic - simulate retry success
  const retried = await prisma.sentMessage.update({
    where: { id: params.id },
    data: {
      status: "sent",
      errorMessage: null,
      providerMessageId: `retry_${Date.now()}_${Math.random().toString(36).substring(7)}`,
      sentAt: new Date(),
    },
    include: {
      client: true,
      appointment: true,
    },
  });

  return NextResponse.json({ success: true, message: retried });
}
