import { NextResponse } from "next/server";
import { getCurrentUser, canManageSettings } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST() {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!canManageSettings(user)) {
    return NextResponse.json(
      { error: "Только владелец или администратор может очищать сообщения" },
      { status: 403 }
    );
  }

  try {
    const deletedMessages = await prisma.sentMessage.deleteMany({
      where: {
        shopId: user.shopId,
      },
    });

    return NextResponse.json({
      success: true,
      message: `Удалено сообщений: ${deletedMessages.count}`,
      count: deletedMessages.count,
    });
  } catch (error: any) {
    console.error("Error clearing messages:", error);
    return NextResponse.json(
      { error: error.message || "Не удалось очистить сообщения" },
      { status: 500 }
    );
  }
}
