import { NextResponse } from "next/server";
import { getCurrentUser, canManageSettings } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST() {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!canManageSettings(user)) {
    return NextResponse.json(
      { error: "Только владелец или администратор может очищать записи" },
      { status: 403 }
    );
  }

  try {
    // Delete appointment services for this shop
    await prisma.appointmentService.deleteMany({
      where: {
        appointment: {
          shopId: user.shopId,
        },
      },
    });

    // Delete all appointments for this shop
    const deletedApps = await prisma.appointment.deleteMany({
      where: {
        shopId: user.shopId,
      },
    });

    return NextResponse.json({
      success: true,
      message: `Удалено записей: ${deletedApps.count}`,
      count: deletedApps.count,
    });
  } catch (error: any) {
    console.error("Error clearing appointments:", error);
    return NextResponse.json(
      { error: error.message || "Не удалось очистить записи" },
      { status: 500 }
    );
  }
}
