import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser, canManageSettings } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const shop = await prisma.shop.findUnique({
    where: { id: user.shopId },
    include: {
      users: {
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
          phone: true,
          color: true,
          isActive: true,
        },
      },
    },
  });

  return NextResponse.json({ shop });
}

export async function PATCH(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!canManageSettings(user)) {
    return NextResponse.json({ error: "Недостаточно прав для изменения настроек" }, { status: 403 });
  }

  try {
    const body = await req.json();
    const {
      name,
      address,
      timezone,
      autoReminder24h,
      autoReminder2h,
      primaryChannel,
      fallbackChannel,
    } = body;

    const data: any = {};
    if (name) data.name = name.trim();
    if (address !== undefined) data.address = address.trim();
    if (timezone) data.timezone = timezone;
    if (autoReminder24h !== undefined) data.autoReminder24h = Boolean(autoReminder24h);
    if (autoReminder2h !== undefined) data.autoReminder2h = Boolean(autoReminder2h);
    if (primaryChannel) data.primaryChannel = primaryChannel;
    if (fallbackChannel) data.fallbackChannel = fallbackChannel;

    const updated = await prisma.shop.update({
      where: { id: user.shopId },
      data,
    });

    return NextResponse.json({ success: true, shop: updated });
  } catch (error: any) {
    console.error("Update settings error:", error);
    return NextResponse.json({ error: error.message || "Не удалось сохранить настройки" }, { status: 500 });
  }
}
