import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser, canManageBarbers } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const barbers = await prisma.user.findMany({
    where: {
      shopId: user.shopId,
      // Barbers or any user with schedule
    },
    include: {
      schedules: {
        orderBy: { dayOfWeek: "asc" },
      },
      _count: {
        select: {
          appointments: {
            where: { status: "pending" },
          },
        },
      },
    },
    orderBy: { name: "asc" },
  });

  return NextResponse.json({
    barbers: barbers.map((b) => ({
      id: b.id,
      name: b.name,
      phone: b.phone,
      email: b.email,
      role: b.role,
      color: b.color,
      isActive: b.isActive,
      schedules: b.schedules,
      pendingAppointmentsCount: b._count.appointments,
    })),
  });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!canManageBarbers(user)) {
    return NextResponse.json({ error: "Недостаточно прав" }, { status: 403 });
  }

  try {
    const body = await req.json();
    const { name, phone, email, color, role, schedules } = body;

    if (!name || !name.trim()) {
      return NextResponse.json({ error: "Укажите имя барбера" }, { status: 400 });
    }

    const barberEmail = email?.trim() || `${name.toLowerCase().replace(/\s+/g, "")}_${Date.now()}@barberstudio.az`;

    const newBarber = await prisma.user.create({
      data: {
        shopId: user.shopId,
        name: name.trim(),
        phone: phone?.trim() || null,
        email: barberEmail,
        color: color || "#2563EB",
        role: role || "barber",
        isActive: true,
      },
    });

    // Default schedules if none provided
    const defaultSchedules = schedules || [
      { dayOfWeek: 1, startTime: "10:00", endTime: "20:00", isWorking: true },
      { dayOfWeek: 2, startTime: "10:00", endTime: "20:00", isWorking: true },
      { dayOfWeek: 3, startTime: "10:00", endTime: "20:00", isWorking: true },
      { dayOfWeek: 4, startTime: "10:00", endTime: "20:00", isWorking: true },
      { dayOfWeek: 5, startTime: "10:00", endTime: "20:00", isWorking: true },
      { dayOfWeek: 6, startTime: "10:00", endTime: "20:00", isWorking: true },
      { dayOfWeek: 0, startTime: "10:00", endTime: "20:00", isWorking: false },
    ];

    for (const s of defaultSchedules) {
      await prisma.barberSchedule.create({
        data: {
          barberId: newBarber.id,
          dayOfWeek: s.dayOfWeek,
          startTime: s.startTime,
          endTime: s.endTime,
          isWorking: s.isWorking,
        },
      });
    }

    const created = await prisma.user.findUnique({
      where: { id: newBarber.id },
      include: { schedules: true },
    });

    return NextResponse.json({ success: true, barber: created });
  } catch (error: any) {
    console.error("Create barber error:", error);
    return NextResponse.json({ error: error.message || "Не удалось создать барбера" }, { status: 500 });
  }
}
