import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser, canManageBarbers } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const barber = await prisma.user.findUnique({
    where: { id: params.id, shopId: user.shopId },
    include: {
      schedules: {
        orderBy: { dayOfWeek: "asc" },
      },
    },
  });

  if (!barber) {
    return NextResponse.json({ error: "Барбер не найден" }, { status: 404 });
  }

  return NextResponse.json({ barber });
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!canManageBarbers(user)) {
    return NextResponse.json({ error: "Недостаточно прав" }, { status: 403 });
  }

  try {
    const body = await req.json();
    const { name, phone, email, color, isActive, schedules } = body;

    const updateData: any = {};
    if (name) updateData.name = name.trim();
    if (phone !== undefined) updateData.phone = phone ? phone.trim() : null;
    if (email) updateData.email = email.trim();
    if (color) updateData.color = color;
    if (isActive !== undefined) updateData.isActive = Boolean(isActive);

    const updated = await prisma.user.update({
      where: { id: params.id, shopId: user.shopId },
      data: updateData,
    });

    // Update schedules if provided
    if (schedules && Array.isArray(schedules)) {
      for (const s of schedules) {
        await prisma.barberSchedule.upsert({
          where: {
            barberId_dayOfWeek: {
              barberId: params.id,
              dayOfWeek: s.dayOfWeek,
            },
          },
          update: {
            startTime: s.startTime,
            endTime: s.endTime,
            isWorking: s.isWorking,
          },
          create: {
            barberId: params.id,
            dayOfWeek: s.dayOfWeek,
            startTime: s.startTime,
            endTime: s.endTime,
            isWorking: s.isWorking,
          },
        });
      }
    }

    const finalBarber = await prisma.user.findUnique({
      where: { id: params.id },
      include: {
        schedules: { orderBy: { dayOfWeek: "asc" } },
      },
    });

    return NextResponse.json({ success: true, barber: finalBarber });
  } catch (error: any) {
    console.error("Update barber error:", error);
    return NextResponse.json({ error: error.message || "Не удалось обновить барбера" }, { status: 500 });
  }
}
