import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { normalizePhone } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const search = searchParams.get("search")?.trim().toLowerCase() || "";
  const filter = searchParams.get("filter") || "all"; // "all" | "inactive"
  const inactiveDays = Number(searchParams.get("days") || 30);

  const whereClause: any = {
    shopId: user.shopId,
    isArchived: false,
  };

  // Barber role isolation: Barber sees only clients who have appointments with him
  if (user.role === "barber") {
    whereClause.appointments = {
      some: {
        barberId: user.id,
      },
    };
  }

  if (search) {
    const searchNormalized = normalizePhone(search);
    whereClause.OR = [
      { name: { contains: search } },
      { phone: { contains: search } },
      ...(searchNormalized ? [{ phoneNormalized: { contains: searchNormalized } }] : []),
    ];
  }

  // Fetch clients with appointments
  const clients = await prisma.client.findMany({
    where: whereClause,
    include: {
      appointments: {
        where: { status: { not: "cancelled" } },
        orderBy: { startAt: "desc" },
        take: 1,
      },
      _count: {
        select: {
          appointments: {
            where: { status: "completed" },
          },
        },
      },
    },
    orderBy: { createdAt: "desc" },
  });

  const now = new Date();
  const inactiveThreshold = new Date(now.getTime() - inactiveDays * 24 * 3600 * 1000);

  const formattedClients = clients.map((c) => {
    const lastVisit = c.appointments[0]?.startAt || null;
    return {
      id: c.id,
      name: c.name,
      phone: c.phone,
      phoneNormalized: c.phoneNormalized,
      notes: c.notes,
      isArchived: c.isArchived,
      createdAt: c.createdAt.toISOString(),
      updatedAt: c.updatedAt.toISOString(),
      visitCount: c._count.appointments,
      lastVisitAt: lastVisit ? lastVisit.toISOString() : null,
    };
  });

  // Filter "Давно не был" (> 30 days or never had appointment)
  let result = formattedClients;
  if (filter === "inactive") {
    result = formattedClients.filter((c) => {
      if (!c.lastVisitAt) return true;
      return new Date(c.lastVisitAt) < inactiveThreshold;
    });
  }

  return NextResponse.json({ clients: result });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { name, phone, notes } = body;

    if (!name || !name.trim()) {
      return NextResponse.json({ error: "Укажите имя клиента" }, { status: 400 });
    }

    if (!phone || !phone.trim()) {
      return NextResponse.json({ error: "Укажите номер телефона" }, { status: 400 });
    }

    const phoneNormalized = normalizePhone(phone);

    // Section 58: Client Duplicate Logic
    const existing = await prisma.client.findFirst({
      where: {
        shopId: user.shopId,
        phoneNormalized,
        isArchived: false,
      },
    });

    if (existing) {
      return NextResponse.json(
        {
          error: "duplicate",
          message: `Клиент с таким номером уже существует: ${existing.name}`,
          existingClient: {
            id: existing.id,
            name: existing.name,
            phone: existing.phone,
          },
        },
        { status: 409 }
      );
    }

    const newClient = await prisma.client.create({
      data: {
        shopId: user.shopId,
        name: name.trim(),
        phone: phone.trim(),
        phoneNormalized,
        notes: notes?.trim() || null,
      },
    });

    return NextResponse.json({ success: true, client: newClient });
  } catch (error: any) {
    console.error("Create client error:", error);
    return NextResponse.json({ error: error.message || "Не удалось создать клиента" }, { status: 500 });
  }
}
