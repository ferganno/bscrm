import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { text } = await req.json();
  if (!text || !text.trim()) {
    return NextResponse.json({ error: "Введите текст заметки" }, { status: 400 });
  }

  const note = await prisma.clientNote.create({
    data: {
      clientId: params.id,
      userId: user.id,
      text: text.trim(),
    },
    include: {
      author: {
        select: {
          id: true,
          name: true,
          role: true,
        },
      },
    },
  });

  return NextResponse.json({ success: true, note });
}
