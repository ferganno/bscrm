import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { normalizePhone } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const client = await prisma.client.findUnique({
    where: { id: params.id, shopId: user.shopId },
    include: {
      appointments: {
        include: {
          barber: { select: { id: true, name: true, color: true } },
          services: { include: { service: true } },
        },
        orderBy: { startAt: "desc" },
      },
      notesHistory: {
        include: {
          author: { select: { id: true, name: true, role: true } },
        },
        orderBy: { createdAt: "desc" },
      },
    },
  });

  if (!client) {
    return NextResponse.json({ error: "Клиент не найден" }, { status: 404 });
  }

  // Calculate favorite services
  const serviceCounts: Record<string, { name: string; count: number }> = {};
  for (const app of client.appointments) {
    if (app.status === "cancelled") continue;
    for (const appSvc of app.services) {
      const sId = appSvc.serviceId;
      if (!serviceCounts[sId]) {
        serviceCounts[sId] = { name: appSvc.service.name, count: 0 };
      }
      serviceCounts[sId].count += 1;
    }
  }

  const favoriteServices = Object.values(serviceCounts).sort(
    (a, b) => b.count - a.count
  );

  // Completed appointments count
  const completedCount = client.appointments.filter(
    (a) => a.status === "completed"
  ).length;

  const lastCompletedApp = client.appointments.find(
    (a) => a.status === "completed"
  );

  return NextResponse.json({
    client: {
      id: client.id,
      name: client.name,
      phone: client.phone,
      phoneNormalized: client.phoneNormalized,
      notes: client.notes,
      isArchived: client.isArchived,
      createdAt: client.createdAt,
      totalVisits: completedCount,
      lastVisitAt: lastCompletedApp ? lastCompletedApp.startAt : null,
      favoriteServices,
      appointments: client.appointments,
      notesHistory: client.notesHistory,
    },
  });
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { name, phone, notes } = body;

    const data: any = {};
    if (name) data.name = name.trim();
    if (phone) {
      data.phone = phone.trim();
      data.phoneNormalized = normalizePhone(phone);
    }
    if (notes !== undefined) data.notes = notes ? notes.trim() : null;

    const updated = await prisma.client.update({
      where: { id: params.id, shopId: user.shopId },
      data,
    });

    return NextResponse.json({ success: true, client: updated });
  } catch (error: any) {
    console.error("Update client error:", error);
    return NextResponse.json({ error: error.message || "Не удалось обновить данные клиента" }, { status: 500 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  // Soft archive client
  const archived = await prisma.client.update({
    where: { id: params.id, shopId: user.shopId },
    data: { isArchived: true },
  });

  return NextResponse.json({ success: true, client: archived });
}
