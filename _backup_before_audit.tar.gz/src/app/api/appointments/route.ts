import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { sendNotificationMessage, renderMessageTemplate } from "@/lib/notifications";
import { format } from "date-fns";
import { ru } from "date-fns/locale";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const startDateStr = searchParams.get("startDate");
  const endDateStr = searchParams.get("endDate");
  const barberId = searchParams.get("barberId");

  const whereClause: any = {
    shopId: user.shopId,
  };

  // Barber role isolation (Section 28): Barber sees only his own appointments
  if (user.role === "barber") {
    whereClause.barberId = user.id;
  } else if (barberId && barberId !== "all") {
    whereClause.barberId = barberId;
  }

  if (startDateStr && endDateStr) {
    whereClause.startAt = {
      gte: new Date(startDateStr),
      lte: new Date(endDateStr),
    };
  }

  const appointments = await prisma.appointment.findMany({
    where: whereClause,
    include: {
      client: {
        select: {
          id: true,
          name: true,
          phone: true,
          notes: true,
        },
      },
      barber: {
        select: {
          id: true,
          name: true,
          color: true,
        },
      },
      services: {
        include: {
          service: {
            select: {
              id: true,
              name: true,
            },
          },
        },
      },
    },
    orderBy: { startAt: "asc" },
  });

  return NextResponse.json({ appointments });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await req.json();
    const {
      clientId,
      barberId,
      startAt,
      serviceIds,
      manualDuration,
      manualPrice,
      comment,
      sendReminder,
    } = body;

    // 1. Validation: Client
    if (!clientId) {
      return NextResponse.json({ error: "Выберите клиента" }, { status: 400 });
    }

    const client = await prisma.client.findUnique({
      where: { id: clientId, shopId: user.shopId },
    });

    if (!client) {
      return NextResponse.json({ error: "Клиент не найден" }, { status: 404 });
    }

    if (!client.phone) {
      return NextResponse.json({ error: "У клиента должен быть номер телефона" }, { status: 400 });
    }

    // 2. Validation: Barber
    const effectiveBarberId = user.role === "barber" ? user.id : barberId;
    if (!effectiveBarberId) {
      return NextResponse.json({ error: "Выберите барбера" }, { status: 400 });
    }

    const barber = await prisma.user.findUnique({
      where: { id: effectiveBarberId, shopId: user.shopId },
    });

    if (!barber || !barber.isActive) {
      return NextResponse.json({ error: "Выбранный барбер не активен" }, { status: 400 });
    }

    // 3. Validation: Services
    if (!serviceIds || !Array.isArray(serviceIds) || serviceIds.length === 0) {
      return NextResponse.json({ error: "Выберите хотя бы одну услугу" }, { status: 400 });
    }

    const services = await prisma.service.findMany({
      where: {
        id: { in: serviceIds },
        shopId: user.shopId,
      },
    });

    if (services.length === 0) {
      return NextResponse.json({ error: "Выбранные услуги не найдены" }, { status: 400 });
    }

    // 4. Calculate Duration & Price
    const sumDuration = services.reduce((acc, s) => acc + s.durationMinutes, 0);
    const sumPrice = services.reduce((acc, s) => acc + s.price, 0);

    const effectiveDuration = manualDuration && Number(manualDuration) > 0 ? Number(manualDuration) : sumDuration;
    const effectivePrice = manualPrice !== undefined && manualPrice !== null && Number(manualPrice) >= 0 ? Number(manualPrice) : sumPrice;

    const startDate = new Date(startAt);
    if (isNaN(startDate.getTime())) {
      return NextResponse.json({ error: "Некорректная дата и время записи" }, { status: 400 });
    }

    const endDate = new Date(startDate.getTime() + effectiveDuration * 60 * 1000);

    // 5. Validation: Working hours logic (Section 54)
    // Note: Day of week: 0 = Sun, 1 = Mon ...
    const dayOfWeek = startDate.getDay();
    const barberSchedule = await prisma.barberSchedule.findUnique({
      where: {
        barberId_dayOfWeek: {
          barberId: effectiveBarberId,
          dayOfWeek,
        },
      },
    });

    if (!barberSchedule || !barberSchedule.isWorking) {
      return NextResponse.json({ error: `${barber.name} не работает в этот день.` }, { status: 400 });
    }

    // Check time range within barber's shift
    const [startH, startM] = barberSchedule.startTime.split(":").map(Number);
    const [endH, endM] = barberSchedule.endTime.split(":").map(Number);

    const shiftStart = new Date(startDate);
    shiftStart.setHours(startH, startM, 0, 0);

    const shiftEnd = new Date(startDate);
    shiftEnd.setHours(endH, endM, 0, 0);

    if (startDate < shiftStart || endDate > shiftEnd) {
      return NextResponse.json({
        error: `${barber.name} работает с ${barberSchedule.startTime} до ${barberSchedule.endTime}. Запись выходит за пределы рабочего времени.`,
      }, { status: 400 });
    }

    // 6. Validation: Conflict Checking (Section 53)
    // new_start < existing_end AND new_end > existing_start
    const conflictingAppointment = await prisma.appointment.findFirst({
      where: {
        barberId: effectiveBarberId,
        status: { not: "cancelled" },
        startAt: { lt: endDate },
        endAt: { gt: startDate },
      },
      include: { client: true },
    });

    if (conflictingAppointment) {
      const conflictStart = format(conflictingAppointment.startAt, "HH:mm");
      const conflictEnd = format(conflictingAppointment.endAt, "HH:mm");
      return NextResponse.json({
        error: `У барбера уже есть запись: ${conflictStart}–${conflictEnd} (${conflictingAppointment.client.name})`,
      }, { status: 400 });
    }

    // 7. Create Appointment with AppointmentServices
    const newAppointment = await prisma.appointment.create({
      data: {
        shopId: user.shopId,
        clientId,
        barberId: effectiveBarberId,
        createdBy: user.id,
        startAt: startDate,
        endAt: endDate,
        status: "pending",
        totalPrice: effectivePrice,
        manualDuration: effectiveDuration,
        comment: comment || null,
        services: {
          create: services.map((s) => ({
            serviceId: s.id,
            price: s.price,
            durationMinutes: s.durationMinutes,
          })),
        },
      },
      include: {
        client: true,
        barber: true,
        services: { include: { service: true } },
      },
    });

    // 8. If requested, send instant confirmation message (Section 18)
    let whatsappUrl = null;
    let messageText = null;

    if (sendReminder) {
      const shop = await prisma.shop.findUnique({
        where: { id: user.shopId },
        include: { messageTemplates: true },
      });

      if (shop) {
        const manualTpl =
          shop.messageTemplates.find((t) => t.type === "manual")?.text ||
          "Здравствуйте, {имя}! Вы записаны на {дата} в {время} к барберу {барбер}. Ждём вас в {название_барбершопа} ({адрес})!";

        const servicesList = services.map((s) => s.name).join(", ");
        const renderedText = renderMessageTemplate(manualTpl, {
          clientName: client.name,
          startAt: startDate,
          barberName: barber.name,
          servicesList,
          shopAddress: shop.address,
          shopName: shop.name,
        });

        messageText = renderedText;
        const cleanDigits = client.phoneNormalized.replace(/[^\d]/g, "");
        whatsappUrl = `https://wa.me/${cleanDigits}?text=${encodeURIComponent(renderedText)}`;

        await sendNotificationMessage({
          shopId: shop.id,
          appointmentId: newAppointment.id,
          clientId: client.id,
          channel: (shop.primaryChannel as any) || "whatsapp",
          type: "manual",
          text: renderedText,
          forceSuccess: true,
        });
      }
    }

    return NextResponse.json({
      success: true,
      appointment: newAppointment,
      whatsappUrl,
      messageText,
    });
  } catch (error: any) {
    console.error("Create appointment error:", error);
    return NextResponse.json({ error: error.message || "Не удалось сохранить запись" }, { status: 500 });
  }
}
