import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { status } = await req.json();
  if (!["pending", "completed", "no_show", "cancelled"].includes(status)) {
    return NextResponse.json({ error: "Недопустимый статус" }, { status: 400 });
  }

  const existing = await prisma.appointment.findUnique({
    where: { id: params.id, shopId: user.shopId },
  });

  if (!existing) {
    return NextResponse.json({ error: "Запись не найдена" }, { status: 404 });
  }

  if (user.role === "barber" && existing.barberId !== user.id) {
    return NextResponse.json({ error: "Доступ запрещен" }, { status: 403 });
  }

  const updated = await prisma.appointment.update({
    where: { id: params.id },
    data: {
      status,
      ...(status === "cancelled"
        ? { cancelledAt: new Date(), cancelledBy: user.id }
        : {}),
    },
    include: {
      client: true,
      barber: true,
    },
  });

  return NextResponse.json({ success: true, appointment: updated });
}
