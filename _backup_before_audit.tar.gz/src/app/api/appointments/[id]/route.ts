import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { format } from "date-fns";

export const dynamic = "force-dynamic";

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const appointment = await prisma.appointment.findUnique({
    where: { id: params.id, shopId: user.shopId },
    include: {
      client: true,
      barber: true,
      creator: true,
      services: {
        include: {
          service: true,
        },
      },
      sentMessages: {
        orderBy: { createdAt: "desc" },
      },
    },
  });

  if (!appointment) {
    return NextResponse.json({ error: "Запись не найдена" }, { status: 404 });
  }

  // Barber isolation check
  if (user.role === "barber" && appointment.barberId !== user.id) {
    return NextResponse.json({ error: "Доступ запрещен" }, { status: 403 });
  }

  return NextResponse.json({ appointment });
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const existing = await prisma.appointment.findUnique({
      where: { id: params.id, shopId: user.shopId },
      include: { barber: true, client: true },
    });

    if (!existing) {
      return NextResponse.json({ error: "Запись не найдена" }, { status: 404 });
    }

    if (user.role === "barber" && existing.barberId !== user.id) {
      return NextResponse.json({ error: "Доступ запрещен" }, { status: 403 });
    }

    const body = await req.json();
    const {
      barberId,
      startAt,
      serviceIds,
      manualDuration,
      manualPrice,
      comment,
      status,
    } = body;

    const targetBarberId = barberId || existing.barberId;
    const targetStartDate = startAt ? new Date(startAt) : existing.startAt;

    let targetDuration = existing.manualDuration;
    let targetPrice = existing.totalPrice;

    // If services are updated
    let servicesToConnect = null;
    if (serviceIds && Array.isArray(serviceIds)) {
      servicesToConnect = await prisma.service.findMany({
        where: { id: { in: serviceIds }, shopId: user.shopId },
      });
      const sumDur = servicesToConnect.reduce((acc, s) => acc + s.durationMinutes, 0);
      const sumPr = servicesToConnect.reduce((acc, s) => acc + s.price, 0);
      targetDuration = manualDuration && Number(manualDuration) > 0 ? Number(manualDuration) : sumDur;
      targetPrice = manualPrice !== undefined ? Number(manualPrice) : sumPr;
    } else {
      if (manualDuration) targetDuration = Number(manualDuration);
      if (manualPrice !== undefined) targetPrice = Number(manualPrice);
    }

    const targetEndDate = new Date(targetStartDate.getTime() + targetDuration * 60 * 1000);

    // If moving or changing barber, validate working hours and conflicts
    if (startAt || barberId || manualDuration) {
      const dayOfWeek = targetStartDate.getDay();
      const barberSchedule = await prisma.barberSchedule.findUnique({
        where: {
          barberId_dayOfWeek: {
            barberId: targetBarberId,
            dayOfWeek,
          },
        },
      });

      if (!barberSchedule || !barberSchedule.isWorking) {
        return NextResponse.json({ error: "Барбер не работает в этот день" }, { status: 400 });
      }

      const [startH, startM] = barberSchedule.startTime.split(":").map(Number);
      const [endH, endM] = barberSchedule.endTime.split(":").map(Number);

      const shiftStart = new Date(targetStartDate);
      shiftStart.setHours(startH, startM, 0, 0);

      const shiftEnd = new Date(targetStartDate);
      shiftEnd.setHours(endH, endM, 0, 0);

      if (targetStartDate < shiftStart || targetEndDate > shiftEnd) {
        return NextResponse.json({
          error: `Барбер работает с ${barberSchedule.startTime} до ${barberSchedule.endTime}. Запись выходит за пределы рабочего времени.`,
        }, { status: 400 });
      }

      // Check conflict with other appointments
      const conflict = await prisma.appointment.findFirst({
        where: {
          id: { not: existing.id },
          barberId: targetBarberId,
          status: { not: "cancelled" },
          startAt: { lt: targetEndDate },
          endAt: { gt: targetStartDate },
        },
        include: { client: true },
      });

      if (conflict) {
        return NextResponse.json({
          error: `Это время занято. У барбера уже есть запись с ${format(conflict.startAt, "HH:mm")} до ${format(conflict.endAt, "HH:mm")} (${conflict.client.name})`,
        }, { status: 400 });
      }
    }

    const updateData: any = {
      barberId: targetBarberId,
      startAt: targetStartDate,
      endAt: targetEndDate,
      totalPrice: targetPrice,
      manualDuration: targetDuration,
    };

    if (comment !== undefined) updateData.comment = comment;
    if (status) {
      updateData.status = status;
      if (status === "cancelled") {
        updateData.cancelledAt = new Date();
        updateData.cancelledBy = user.id;
      }
    }

    if (servicesToConnect) {
      await prisma.appointmentService.deleteMany({
        where: { appointmentId: existing.id },
      });
      updateData.services = {
        create: servicesToConnect.map((s) => ({
          serviceId: s.id,
          price: s.price,
          durationMinutes: s.durationMinutes,
        })),
      };
    }

    const updated = await prisma.appointment.update({
      where: { id: existing.id },
      data: updateData,
      include: {
        client: true,
        barber: true,
        services: { include: { service: true } },
      },
    });

    return NextResponse.json({ success: true, appointment: updated });
  } catch (error: any) {
    console.error("Update appointment error:", error);
    return NextResponse.json({ error: error.message || "Не удалось обновить запись" }, { status: 500 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const existing = await prisma.appointment.findUnique({
    where: { id: params.id, shopId: user.shopId },
  });

  if (!existing) {
    return NextResponse.json({ error: "Запись не найдена" }, { status: 404 });
  }

  // Soft cancel (Section 59: Appointment status = cancelled)
  const cancelled = await prisma.appointment.update({
    where: { id: params.id },
    data: {
      status: "cancelled",
      cancelledAt: new Date(),
      cancelledBy: user.id,
    },
  });

  return NextResponse.json({ success: true, appointment: cancelled });
}
