import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { normalizePhone } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q")?.trim() || "";

  if (!q || q.length < 2) {
    return NextResponse.json({ clients: [], appointments: [] });
  }

  const normalized = normalizePhone(q);

  // 1. Search clients
  const clientWhere: any = {
    shopId: user.shopId,
    isArchived: false,
    OR: [
      { name: { contains: q } },
      { phone: { contains: q } },
      ...(normalized ? [{ phoneNormalized: { contains: normalized } }] : []),
    ],
  };

  if (user.role === "barber") {
    clientWhere.appointments = { some: { barberId: user.id } };
  }

  const clients = await prisma.client.findMany({
    where: clientWhere,
    take: 5,
    select: {
      id: true,
      name: true,
      phone: true,
      notes: true,
    },
  });

  // 2. Search appointments (by client name, phone, or comment)
  const appWhere: any = {
    shopId: user.shopId,
    status: { not: "cancelled" },
    OR: [
      { client: { name: { contains: q } } },
      { client: { phone: { contains: q } } },
      { comment: { contains: q } },
    ],
  };

  if (user.role === "barber") {
    appWhere.barberId = user.id;
  }

  const appointments = await prisma.appointment.findMany({
    where: appWhere,
    take: 5,
    include: {
      client: { select: { id: true, name: true, phone: true } },
      barber: { select: { id: true, name: true, color: true } },
      services: { include: { service: { select: { name: true } } } },
    },
    orderBy: { startAt: "desc" },
  });

  return NextResponse.json({ clients, appointments });
}
