"use client";

import React from "react";
import { AppShell } from "@/components/layout/AppShell";
import { ClientsList } from "@/components/clients/ClientsList";

export default function ClientsPage() {
  return (
    <AppShell>
      {({ currentUser, openNewAppointment, openClientMessageModal }) => (
        <ClientsList
          currentUser={currentUser}
          onBookAgain={(client, barberId, serviceIds) => {
            openNewAppointment({
              clientId: client.id,
              barberId,
            });
          }}
          onOpenMessageModal={openClientMessageModal}
        />
      )}
    </AppShell>
  );
}
