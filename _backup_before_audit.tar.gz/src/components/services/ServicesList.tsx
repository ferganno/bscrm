"use client";

import React, { useState, useEffect } from "react";
import { Sparkles, Plus, Clock, DollarSign, Edit3, Trash2, CheckCircle } from "lucide-react";
import { Button } from "../ui/Button";
import { Input } from "../ui/Input";
import { Modal } from "../ui/Modal";
import { useToast } from "../ui/Toast";
import { ServiceItem, SessionUser } from "@/lib/types";
import { formatCurrency } from "@/lib/utils";

interface ServicesListProps {
  currentUser: SessionUser | null;
}

export function ServicesList({ currentUser }: ServicesListProps) {
  const { toast, success, error: toastError } = useToast();
  const [services, setServices] = useState<ServiceItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingService, setEditingService] = useState<ServiceItem | null>(null);

  // Form
  const [name, setName] = useState("");
  const [durationMinutes, setDurationMinutes] = useState(30);
  const [price, setPrice] = useState(15);
  const [isActive, setIsActive] = useState(true);
  const [sortOrder, setSortOrder] = useState(0);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const canManage = currentUser?.role === "owner" || currentUser?.role === "admin";

  const loadServices = () => {
    setLoading(true);
    fetch("/api/services")
      .then((r) => r.json())
      .then((d) => setServices(d.services || []))
      .catch((err) => console.error("Error loading services:", err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadServices();
  }, []);

  const openAddModal = () => {
    setEditingService(null);
    setName("");
    setDurationMinutes(30);
    setPrice(15);
    setIsActive(true);
    setSortOrder(services.length + 1);
    setFormError(null);
    setIsModalOpen(true);
  };

  const openEditModal = (s: ServiceItem) => {
    setEditingService(s);
    setName(s.name);
    setDurationMinutes(s.durationMinutes);
    setPrice(s.price);
    setIsActive(s.isActive);
    setSortOrder(s.sortOrder);
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleSave = async () => {
    if (!name.trim()) {
      setFormError("Укажите название услуги");
      return;
    }

    setSaving(true);
    setFormError(null);

    try {
      const url = editingService ? `/api/services/${editingService.id}` : "/api/services";
      const method = editingService ? "PATCH" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          durationMinutes,
          price,
          isActive,
          sortOrder,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Не удалось сохранить");

      success(editingService ? "✓ Услуга обновлена" : "✓ Услуга добавлена в каталог");
      setIsModalOpen(false);
      loadServices();
    } catch (err: any) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleToggleArchive = async (s: ServiceItem) => {
    try {
      const res = await fetch(`/api/services/${s.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isActive: !s.isActive }),
      });
      if (!res.ok) throw new Error("Ошибка обновления статуса");
      success(s.isActive ? "✓ Услуга перенесена в архив" : "✓ Услуга активирована");
      loadServices();
    } catch (err: any) {
      toastError(err.message);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-primary">Услуги</h1>
          <p className="text-xs text-secondary mt-0.5">
            Каталог услуг барбершопа, длительность и базовые цены
          </p>
        </div>

        {canManage && (
          <Button
            variant="primary"
            size="sm"
            onClick={openAddModal}
            className="h-9 px-3.5 text-xs font-semibold"
          >
            <Plus className="w-4 h-4 mr-1.5 stroke-[2.5]" />
            Добавить услугу
          </Button>
        )}
      </div>

      {/* Grid */}
      {loading ? (
        <div className="py-12 text-center text-xs text-secondary">
          Загрузка услуг...
        </div>
      ) : services.length === 0 ? (
        <div className="p-12 text-center bg-surface rounded-crm border border-border space-y-3">
          <div className="w-12 h-12 rounded-full bg-brand-100 flex items-center justify-center mx-auto text-secondary">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-primary">Каталог услуг пуст</h3>
            <p className="text-xs text-secondary mt-1">
              Добавьте услуги для быстрого выбора при создании записи.
            </p>
          </div>
          {canManage && (
            <Button variant="outline" size="sm" onClick={openAddModal} className="text-xs mt-2">
              Добавить услугу
            </Button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {services.map((svc) => (
            <div
              key={svc.id}
              className={`p-4 rounded-crm bg-surface border shadow-subtle flex flex-col justify-between space-y-3 transition-all ${
                svc.isActive ? "border-border hover:shadow-dropdown" : "border-border/60 opacity-60 bg-brand-50/40"
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-sm font-bold text-primary truncate">{svc.name}</h3>
                  <span
                    className={`text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full border shrink-0 ${
                      svc.isActive
                        ? "bg-emerald-50 text-emerald-700 border-emerald-200"
                        : "bg-zinc-100 text-zinc-500 border-zinc-200"
                    }`}
                  >
                    {svc.isActive ? "Активна" : "В архиве"}
                  </span>
                </div>

                <div className="flex items-center gap-3 mt-3 text-xs">
                  <div className="flex items-center gap-1.5 text-secondary">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{svc.durationMinutes} мин</span>
                  </div>
                  <span className="text-zinc-300">•</span>
                  <div className="flex items-center font-bold text-primary text-sm">
                    {formatCurrency(svc.price)}
                  </div>
                </div>
              </div>

              {canManage && (
                <div className="flex items-center gap-2 pt-2 border-t border-border/70">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openEditModal(svc)}
                    className="flex-1 text-xs"
                  >
                    <Edit3 className="w-3.5 h-3.5 mr-1" />
                    Изменить
                  </Button>
                  <button
                    onClick={() => handleToggleArchive(svc)}
                    className="p-2 text-xs text-secondary hover:text-primary rounded hover:bg-brand-100 transition-colors"
                    title={svc.isActive ? "Архивировать услугу" : "Восстановить из архива"}
                  >
                    {svc.isActive ? "В архив" : "Восстановить"}
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingService ? "Редактировать услугу" : "Новая услуга"}
        description="Параметры услуги в каталоге"
        footer={
          <>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsModalOpen(false)}
              disabled={saving}
            >
              Отмена
            </Button>
            <Button variant="primary" size="sm" isLoading={saving} onClick={handleSave}>
              Сохранить
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          {formError && (
            <div className="p-2.5 rounded-crm bg-rose-50 border border-rose-200 text-rose-700 text-xs">
              {formError}
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
              Название услуги <span className="text-rose-500">*</span>
            </label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Например: Стрижка + Борода"
              autoFocus
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
                Длительность (мин)
              </label>
              <Input
                type="number"
                min="5"
                step="5"
                value={durationMinutes}
                onChange={(e) => setDurationMinutes(Number(e.target.value))}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
                Цена ($)
              </label>
              <Input
                type="number"
                min="0"
                step="1"
                value={price}
                onChange={(e) => setPrice(Number(e.target.value))}
              />
            </div>
          </div>

          <div>
            <label className="flex items-center gap-2 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={isActive}
                onChange={(e) => setIsActive(e.target.checked)}
                className="w-4 h-4 text-primary rounded"
              />
              <span className="text-xs font-medium text-primary">
                Услуга активна (доступна для выбора при бронировании)
              </span>
            </label>
          </div>
        </div>
      </Modal>
    </div>
  );
}
