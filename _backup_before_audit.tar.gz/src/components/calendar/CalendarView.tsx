"use client";

import React, { useState, useEffect, useMemo } from "react";
import {
  ChevronLeft,
  ChevronRight,
  Plus,
  Calendar as CalendarIcon,
  Clock,
  User,
  Filter,
} from "lucide-react";
import { Button } from "../ui/Button";
import { Badge } from "../ui/Badge";
import { CalendarSkeleton } from "../ui/Skeleton";
import { OperationalSummary } from "./OperationalSummary";
import { DragConfirmModal } from "./DragConfirmModal";
import {
  format,
  addDays,
  subDays,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  isSameDay,
  isToday,
  parseISO,
  setHours,
  setMinutes,
} from "date-fns";
import { ru } from "date-fns/locale";
import {
  cn,
  formatCurrency,
  formatTimeRange,
  APPOINTMENT_STATUS_MAP,
  AppointmentStatusKey,
} from "@/lib/utils";
import { AppointmentItem, BarberWithSchedule, SessionUser } from "@/lib/types";

// Hours to display in calendar
const CALENDAR_HOURS = Array.from({ length: 13 }, (_, i) => i + 9); // 09:00 - 21:00

interface CalendarViewProps {
  currentUser: SessionUser | null;
  onOpenNewAppointment: (params: {
    date: Date;
    time: string;
    barberId?: string;
  }) => void;
  onSelectAppointment: (appointment: AppointmentItem) => void;
  refreshTrigger: number;
}

export function CalendarView({
  currentUser,
  onOpenNewAppointment,
  onSelectAppointment,
  refreshTrigger,
}: CalendarViewProps) {
  // Calendar mode: "day" | "week"
  const [viewMode, setViewMode] = useState<"day" | "week">("day");
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [barbers, setBarbers] = useState<BarberWithSchedule[]>([]);
  const [selectedBarberIds, setSelectedBarberIds] = useState<string[]>([]);
  const [appointments, setAppointments] = useState<AppointmentItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Drag and Drop state
  const [draggedApp, setDraggedApp] = useState<AppointmentItem | null>(null);
  const [dragTarget, setDragTarget] = useState<{
    barberId: string;
    hour: number;
    minute: number;
  } | null>(null);
  const [showDragModal, setShowDragModal] = useState(false);
  const [dragLoading, setDragLoading] = useState(false);
  const [dragError, setDragError] = useState<string | null>(null);

  // Mobile selected barber for timeline
  const [mobileActiveBarberId, setMobileActiveBarberId] = useState<string>("");

  // Keyboard navigation shortcuts: 'T' for Today, 'N' for New Appointment
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if typing inside input or textarea
      if (["INPUT", "TEXTAREA", "SELECT"].includes((e.target as HTMLElement).tagName)) {
        return;
      }
      if (e.key === "t" || e.key === "T" || e.key === "е" || e.key === "Е") {
        setSelectedDate(new Date());
      } else if (e.key === "n" || e.key === "N" || e.key === "т" || e.key === "Т") {
        onOpenNewAppointment({
          date: selectedDate,
          time: "12:00",
          barberId: selectedBarberIds[0] || (barbers[0]?.id),
        });
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [selectedDate, selectedBarberIds, barbers, onOpenNewAppointment]);

  // Load barbers once or on refresh
  useEffect(() => {
    fetch("/api/barbers")
      .then((res) => res.json())
      .then((data) => {
        const list = (data.barbers || []).filter((b: any) => b.isActive);
        setBarbers(list);
        if (list.length > 0 && selectedBarberIds.length === 0) {
          // If barber role, default to himself, else all
          if (currentUser?.role === "barber") {
            setSelectedBarberIds([currentUser.id]);
            setMobileActiveBarberId(currentUser.id);
          } else {
            setSelectedBarberIds(list.map((b: any) => b.id));
            setMobileActiveBarberId(list[0].id);
          }
        }
      })
      .catch((err) => console.error("Error loading barbers:", err));
  }, [currentUser]);

  // Fetch appointments for date range
  const loadAppointments = () => {
    setLoading(true);
    let start: Date;
    let end: Date;

    if (viewMode === "day") {
      start = new Date(selectedDate);
      start.setHours(0, 0, 0, 0);
      end = new Date(selectedDate);
      end.setHours(23, 59, 59, 999);
    } else {
      start = startOfWeek(selectedDate, { weekStartsOn: 1 });
      start.setHours(0, 0, 0, 0);
      end = endOfWeek(selectedDate, { weekStartsOn: 1 });
      end.setHours(23, 59, 59, 999);
    }

    const url = `/api/appointments?startDate=${start.toISOString()}&endDate=${end.toISOString()}`;
    fetch(url)
      .then((res) => res.json())
      .then((data) => {
        setAppointments(data.appointments || []);
      })
      .catch((err) => console.error("Error loading appointments:", err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadAppointments();
  }, [selectedDate, viewMode, refreshTrigger]);

  // Filtered barbers
  const displayedBarbers = useMemo(() => {
    if (currentUser?.role === "barber") {
      return barbers.filter((b) => b.id === currentUser.id);
    }
    if (selectedBarberIds.length === 0) return barbers;
    return barbers.filter((b) => selectedBarberIds.includes(b.id));
  }, [barbers, selectedBarberIds, currentUser]);

  // Toggle barber filter
  const toggleBarberFilter = (bId: string) => {
    if (selectedBarberIds.includes(bId)) {
      if (selectedBarberIds.length === 1) return; // Keep at least one
      setSelectedBarberIds(selectedBarberIds.filter((id) => id !== bId));
    } else {
      setSelectedBarberIds([...selectedBarberIds, bId]);
    }
  };

  const selectAllBarbers = () => {
    setSelectedBarberIds(barbers.map((b) => b.id));
  };

  // Drag and Drop handlers
  const handleDragStart = (app: AppointmentItem) => {
    setDraggedApp(app);
    setDragError(null);
  };

  const handleSlotDrop = (barberId: string, hour: number, minute: number) => {
    if (!draggedApp) return;

    // Check if same slot
    const appStart = new Date(draggedApp.startAt);
    if (
      draggedApp.barberId === barberId &&
      appStart.getHours() === hour &&
      appStart.getMinutes() === minute
    ) {
      setDraggedApp(null);
      return;
    }

    setDragTarget({ barberId, hour, minute });
    setShowDragModal(true);
  };

  const handleConfirmDrag = async () => {
    if (!draggedApp || !dragTarget) return;
    setDragLoading(true);
    setDragError(null);

    try {
      const newStart = new Date(selectedDate);
      newStart.setHours(dragTarget.hour, dragTarget.minute, 0, 0);

      const res = await fetch(`/api/appointments/${draggedApp.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          barberId: dragTarget.barberId,
          startAt: newStart.toISOString(),
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setDragError(data.error || "Не удалось перенести запись");
        return;
      }

      setShowDragModal(false);
      setDraggedApp(null);
      setDragTarget(null);
      loadAppointments();
    } catch (err: any) {
      setDragError(err.message);
    } finally {
      setDragLoading(false);
    }
  };

  // Helper: check working hours for slot
  const isSlotWorking = (barber: BarberWithSchedule, hour: number) => {
    const dayOfWeek = selectedDate.getDay();
    const sch = barber.schedules.find((s) => s.dayOfWeek === dayOfWeek);
    if (!sch || !sch.isWorking) return false;
    const [startH] = sch.startTime.split(":").map(Number);
    const [endH] = sch.endTime.split(":").map(Number);
    return hour >= startH && hour < endH;
  };

  return (
    <div className="flex-1 flex flex-col min-h-0">
      {/* Calendar Header Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-border">
        {/* Date Navigation */}
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setSelectedDate(new Date())}
            className="text-xs font-semibold px-2.5 h-8 shadow-2xs"
            title="Перейти к сегодняшней дате (Нажмите T)"
          >
            Сегодня
          </Button>

          <div className="flex items-center border border-border rounded-crm bg-surface shadow-2xs">
            <button
              onClick={() => setSelectedDate(subDays(selectedDate, viewMode === "day" ? 1 : 7))}
              className="p-1.5 text-secondary hover:text-primary hover:bg-brand-50 rounded-l-crm transition-colors"
              aria-label="Назад"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => setSelectedDate(addDays(selectedDate, viewMode === "day" ? 1 : 7))}
              className="p-1.5 text-secondary hover:text-primary hover:bg-brand-50 rounded-r-crm transition-colors"
              aria-label="Вперед"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <span className="text-sm font-bold text-primary ml-1 capitalize">
            {format(selectedDate, "d MMMM yyyy", { locale: ru })}
          </span>
          {isToday(selectedDate) && (
            <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              Сегодня
            </span>
          )}
        </div>

        {/* View Mode Toggle & New Appointment Button */}
        <div className="flex items-center gap-2">
          <div className="flex items-center p-0.5 bg-brand-100 rounded-crm text-xs font-medium">
            <button
              onClick={() => setViewMode("day")}
              className={cn(
                "px-3 py-1 rounded-crm-sm transition-all",
                viewMode === "day"
                  ? "bg-surface text-primary shadow-subtle font-semibold"
                  : "text-secondary hover:text-primary"
              )}
            >
              День
            </button>
            <button
              onClick={() => setViewMode("week")}
              className={cn(
                "px-3 py-1 rounded-crm-sm transition-all",
                viewMode === "week"
                  ? "bg-surface text-primary shadow-subtle font-semibold"
                  : "text-secondary hover:text-primary"
              )}
            >
              Неделя
            </button>
          </div>

          <Button
            variant="primary"
            size="sm"
            onClick={() =>
              onOpenNewAppointment({
                date: selectedDate,
                time: "12:00",
                barberId: displayedBarbers[0]?.id,
              })
            }
            className="h-8 px-3 text-xs font-semibold"
          >
            <Plus className="w-3.5 h-3.5 mr-1 stroke-[2.5]" />
            Запись
          </Button>
        </div>
      </div>

      {/* Operational Summary (Section 39) */}
      <div className="pt-3">
        <OperationalSummary
          appointments={appointments.filter((a) => isSameDay(parseISO(a.startAt), selectedDate))}
        />
      </div>

      {/* Barber Filters (Section 7) */}
      {currentUser?.role !== "barber" && (
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-2 no-scrollbar">
          <button
            onClick={selectAllBarbers}
            className={cn(
              "px-3 py-1 rounded-full text-xs font-medium transition-colors shrink-0 border",
              selectedBarberIds.length === barbers.length
                ? "bg-primary text-white border-primary shadow-2xs"
                : "bg-surface text-secondary border-border hover:bg-brand-50"
            )}
          >
            Все барберы
          </button>
          {barbers.map((b) => {
            const isSelected = selectedBarberIds.includes(b.id);
            return (
              <button
                key={b.id}
                onClick={() => toggleBarberFilter(b.id)}
                className={cn(
                  "flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium transition-colors shrink-0 border",
                  isSelected
                    ? "bg-surface text-primary border-border shadow-2xs"
                    : "bg-transparent text-secondary/70 border-dashed border-border hover:bg-brand-50"
                )}
              >
                <span
                  className="w-2 h-2 rounded-full shrink-0"
                  style={{ backgroundColor: b.color }}
                />
                <span>{b.name}</span>
              </button>
            );
          })}
        </div>
      )}

      {/* Loading Skeleton */}
      {loading ? (
        <CalendarSkeleton />
      ) : viewMode === "day" ? (
        /* DAY VIEW (Section 6) */
        <div className="flex-1 overflow-x-auto overflow-y-auto bg-surface rounded-crm border border-border shadow-subtle min-h-[500px]">
          {/* Day Table Grid */}
          <div
            className="grid min-w-[700px]"
            style={{
              gridTemplateColumns: `60px repeat(${displayedBarbers.length}, minmax(160px, 1fr))`,
            }}
          >
            {/* Header row */}
            <div className="sticky top-0 z-20 bg-brand-50/90 backdrop-blur-xs p-2.5 border-b border-r border-border text-[11px] font-semibold text-secondary text-center">
              Время
            </div>
            {displayedBarbers.map((barber) => (
              <div
                key={barber.id}
                className="sticky top-0 z-20 bg-brand-50/90 backdrop-blur-xs p-2.5 border-b border-r border-border text-center flex items-center justify-center gap-2"
              >
                <span
                  className="w-2.5 h-2.5 rounded-full shrink-0"
                  style={{ backgroundColor: barber.color }}
                />
                <span className="text-xs font-bold text-primary">{barber.name}</span>
                <span className="text-[10px] text-secondary capitalize font-normal">
                  ({barber.role})
                </span>
              </div>
            ))}

            {/* Time Rows */}
            {CALENDAR_HOURS.map((hour) => {
              const timeString = `${hour.toString().padStart(2, "0")}:00`;
              return (
                <React.Fragment key={hour}>
                  {/* Time label */}
                  <div className="border-b border-r border-border/60 p-2 text-[11px] font-medium text-secondary text-center select-none bg-surface/50">
                    {timeString}
                  </div>

                  {/* Columns for each barber */}
                  {displayedBarbers.map((barber) => {
                    const isWorking = isSlotWorking(barber, hour);

                    // Find appointments for this barber that overlap with this hour
                    const slotStart = new Date(selectedDate);
                    slotStart.setHours(hour, 0, 0, 0);
                    const slotEnd = new Date(selectedDate);
                    slotEnd.setHours(hour, 59, 59, 999);

                    const matchingApps = appointments.filter((a) => {
                      if (a.barberId !== barber.id) return false;
                      if (a.status === "cancelled") return false;
                      const aStart = parseISO(a.startAt);
                      const aEnd = parseISO(a.endAt);
                      return aStart < slotEnd && aEnd > slotStart;
                    });

                    return (
                      <div
                        key={`${barber.id}-${hour}`}
                        onDragOver={(e) => e.preventDefault()}
                        onDrop={() => handleSlotDrop(barber.id, hour, 0)}
                        onClick={(e) => {
                          // Only trigger create if clicking empty space
                          if (e.target === e.currentTarget && isWorking) {
                            onOpenNewAppointment({
                              date: selectedDate,
                              time: timeString,
                              barberId: barber.id,
                            });
                          }
                        }}
                        className={cn(
                          "relative min-h-[72px] border-b border-r border-border/50 p-1 transition-colors group",
                          !isWorking
                            ? "bg-brand-100/40 cursor-not-allowed"
                            : "hover:bg-brand-50/50 cursor-pointer"
                        )}
                      >
                        {!isWorking && (
                          <div className="text-[10px] text-zinc-400 select-none flex items-center justify-center h-full">
                            Не рабочий час
                          </div>
                        )}

                        {/* Appointments cards */}
                        {matchingApps.map((app) => {
                          const statusConfig =
                            APPOINTMENT_STATUS_MAP[app.status as AppointmentStatusKey] ||
                            APPOINTMENT_STATUS_MAP.pending;
                          return (
                            <div
                              key={app.id}
                              draggable
                              onDragStart={() => handleDragStart(app)}
                              onClick={(e) => {
                                e.stopPropagation();
                                onSelectAppointment(app);
                              }}
                              className={cn(
                                "p-2 rounded-crm text-xs mb-1 transition-all cursor-pointer shadow-subtle border select-none hover:shadow-dropdown hover:scale-[1.01]",
                                "bg-surface border-border",
                                app.status === "no_show" && "border-rose-300 bg-rose-50/30"
                              )}
                              style={{
                                borderLeftWidth: "4px",
                                borderLeftColor: barber.color,
                              }}
                            >
                              <div className="flex items-center justify-between">
                                <span className="font-bold text-primary truncate max-w-[110px]">
                                  {app.client.name}
                                </span>
                                <span className="text-[10px] text-secondary font-medium">
                                  {format(parseISO(app.startAt), "HH:mm")}
                                </span>
                              </div>
                              <div className="text-[11px] text-secondary truncate mt-0.5">
                                {app.services.map((s) => s.service.name).join(", ")}
                              </div>
                              <div className="flex items-center justify-between mt-1 text-[10px]">
                                <span className="font-semibold text-primary">
                                  {formatCurrency(app.totalPrice)}
                                </span>
                                <span
                                  className={cn(
                                    "px-1.5 py-0.2 rounded font-medium text-[9px] border",
                                    statusConfig.bg
                                  )}
                                >
                                  {statusConfig.label}
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    );
                  })}
                </React.Fragment>
              );
            })}
          </div>
        </div>
      ) : (
        /* WEEK VIEW */
        <div className="flex-1 overflow-x-auto overflow-y-auto bg-surface rounded-crm border border-border shadow-subtle min-h-[500px]">
          <div
            className="grid min-w-[800px]"
            style={{
              gridTemplateColumns: `60px repeat(7, minmax(130px, 1fr))`,
            }}
          >
            {/* Header row */}
            <div className="sticky top-0 z-20 bg-brand-50/90 backdrop-blur-xs p-2.5 border-b border-r border-border text-[11px] font-semibold text-secondary text-center">
              Время
            </div>
            {eachDayOfInterval({
              start: startOfWeek(selectedDate, { weekStartsOn: 1 }),
              end: endOfWeek(selectedDate, { weekStartsOn: 1 }),
            }).map((day) => {
              const isCurrent = isToday(day);
              return (
                <div
                  key={day.toISOString()}
                  className={cn(
                    "sticky top-0 z-20 p-2 border-b border-r border-border text-center transition-colors",
                    isCurrent ? "bg-brand-100 font-bold" : "bg-brand-50/90 text-secondary"
                  )}
                >
                  <div className="text-[11px] capitalize">{format(day, "eee", { locale: ru })}</div>
                  <div className={cn("text-xs font-semibold", isCurrent ? "text-primary" : "text-neutral-700")}>
                    {format(day, "d MMM", { locale: ru })}
                  </div>
                </div>
              );
            })}

            {/* Time Rows */}
            {CALENDAR_HOURS.map((hour) => {
              const timeString = `${hour.toString().padStart(2, "0")}:00`;
              return (
                <React.Fragment key={hour}>
                  <div className="border-b border-r border-border/60 p-2 text-[11px] font-medium text-secondary text-center select-none bg-surface/50">
                    {timeString}
                  </div>

                  {eachDayOfInterval({
                    start: startOfWeek(selectedDate, { weekStartsOn: 1 }),
                    end: endOfWeek(selectedDate, { weekStartsOn: 1 }),
                  }).map((day) => {
                    const slotStart = new Date(day);
                    slotStart.setHours(hour, 0, 0, 0);
                    const slotEnd = new Date(day);
                    slotEnd.setHours(hour, 59, 59, 999);

                    const matchingApps = appointments.filter((a) => {
                      if (a.status === "cancelled") return false;
                      const aStart = parseISO(a.startAt);
                      const aEnd = parseISO(a.endAt);
                      return aStart < slotEnd && aEnd > slotStart;
                    });

                    return (
                      <div
                        key={`${day.toISOString()}-${hour}`}
                        onClick={(e) => {
                          if (e.target === e.currentTarget) {
                            onOpenNewAppointment({
                              date: day,
                              time: timeString,
                              barberId: displayedBarbers[0]?.id,
                            });
                          }
                        }}
                        className="relative min-h-[64px] border-b border-r border-border/50 p-1 hover:bg-brand-50/50 cursor-pointer"
                      >
                        {matchingApps.map((app) => (
                          <div
                            key={app.id}
                            onClick={(e) => {
                              e.stopPropagation();
                              onSelectAppointment(app);
                            }}
                            className="p-1.5 rounded-crm text-[11px] mb-1 bg-surface border border-border shadow-2xs hover:shadow-subtle cursor-pointer"
                            style={{
                              borderLeftWidth: "3px",
                              borderLeftColor: app.barber.color,
                            }}
                          >
                            <div className="font-semibold text-primary truncate">
                              {app.client.name}
                            </div>
                            <div className="text-[10px] text-secondary">
                              {format(parseISO(app.startAt), "HH:mm")} • {app.barber.name}
                            </div>
                          </div>
                        ))}
                      </div>
                    );
                  })}
                </React.Fragment>
              );
            })}
          </div>
        </div>
      )}

      {/* Drag confirmation modal (Section 9) */}
      <DragConfirmModal
        isOpen={showDragModal}
        onClose={() => {
          setShowDragModal(false);
          setDraggedApp(null);
          setDragTarget(null);
        }}
        onConfirm={handleConfirmDrag}
        appointment={draggedApp}
        newStartTime={
          dragTarget
            ? `${dragTarget.hour.toString().padStart(2, "0")}:${dragTarget.minute.toString().padStart(2, "0")}`
            : null
        }
        newEndTime={
          dragTarget && draggedApp
            ? `${(dragTarget.hour + Math.floor(draggedApp.manualDuration / 60))
                .toString()
                .padStart(2, "0")}:${(dragTarget.minute + (draggedApp.manualDuration % 60))
                .toString()
                .padStart(2, "0")}`
            : null
        }
        loading={dragLoading}
        conflictError={dragError}
      />
    </div>
  );
}
