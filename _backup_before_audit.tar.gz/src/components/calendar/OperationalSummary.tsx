"use client";

import React from "react";
import { AppointmentItem } from "@/lib/types";

interface OperationalSummaryProps {
  appointments: AppointmentItem[];
}

export function OperationalSummary({ appointments }: OperationalSummaryProps) {
  const total = appointments.length;
  const completed = appointments.filter((a) => a.status === "completed").length;
  const pending = appointments.filter((a) => a.status === "pending").length;
  const cancelled = appointments.filter((a) => a.status === "cancelled").length;
  const noShow = appointments.filter((a) => a.status === "no_show").length;

  return (
    <div className="flex flex-wrap items-center gap-2 text-xs py-2 px-3 bg-surface rounded-crm border border-border text-secondary shadow-subtle mb-4">
      <span className="font-semibold text-primary">Сегодня:</span>
      <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-brand-100 text-primary font-medium">
        {total} {total === 1 ? "запись" : total >= 2 && total <= 4 ? "записи" : "записей"}
      </span>
      <span className="text-zinc-300">•</span>
      <span className="inline-flex items-center gap-1.5 text-emerald-700">
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
        {completed} завершено
      </span>
      <span className="text-zinc-300">•</span>
      <span className="inline-flex items-center gap-1.5 text-amber-700">
        <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
        {pending} ожидают
      </span>
      {cancelled > 0 && (
        <>
          <span className="text-zinc-300">•</span>
          <span className="inline-flex items-center gap-1.5 text-zinc-500">
            <span className="w-1.5 h-1.5 rounded-full bg-zinc-400" />
            {cancelled} отменено
          </span>
        </>
      )}
      {noShow > 0 && (
        <>
          <span className="text-zinc-300">•</span>
          <span className="inline-flex items-center gap-1.5 text-rose-700 font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
            {noShow} no-show
          </span>
        </>
      )}
    </div>
  );
}
