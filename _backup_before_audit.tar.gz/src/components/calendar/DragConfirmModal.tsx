"use client";

import React from "react";
import { Modal } from "../ui/Modal";
import { Button } from "../ui/Button";
import { AppointmentItem } from "@/lib/types";
import { formatTimeRange } from "@/lib/utils";

interface DragConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  appointment: AppointmentItem | null;
  newStartTime: string | null;
  newEndTime: string | null;
  loading: boolean;
  conflictError?: string | null;
}

export function DragConfirmModal({
  isOpen,
  onClose,
  onConfirm,
  appointment,
  newStartTime,
  newEndTime,
  loading,
  conflictError,
}: DragConfirmModalProps) {
  if (!appointment || !newStartTime || !newEndTime) return null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Перенести запись?"
      description="Подтверждение изменения времени"
      footer={
        <>
          <Button variant="outline" size="sm" onClick={onClose} disabled={loading}>
            Отмена
          </Button>
          {!conflictError && (
            <Button
              variant="primary"
              size="sm"
              isLoading={loading}
              onClick={onConfirm}
            >
              Перенести
            </Button>
          )}
        </>
      }
    >
      <div className="space-y-4">
        {conflictError ? (
          <div className="p-3 rounded-crm bg-rose-50 border border-rose-200 text-rose-800 text-xs">
            <span className="font-semibold block mb-0.5">Это время занято:</span>
            {conflictError}
          </div>
        ) : (
          <div className="p-4 rounded-crm bg-brand-50 border border-border space-y-2">
            <div className="text-sm font-bold text-primary">
              {appointment.barber.name} — {appointment.client.name}
            </div>
            <div className="text-xs text-secondary">
              {appointment.services.map((s) => s.service.name).join(", ")}
            </div>
            <div className="text-xs font-semibold text-primary pt-2 border-t border-border flex items-center gap-2">
              <span className="line-through text-secondary">
                {formatTimeRange(appointment.startAt, appointment.endAt)}
              </span>
              <span>→</span>
              <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                {newStartTime} – {newEndTime}
              </span>
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
}
