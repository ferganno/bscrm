"use client";

import React, { useState, useEffect } from "react";
import {
  MessageSquare,
  Send,
  RotateCw,
  CheckCircle2,
  AlertCircle,
  FileText,
  Settings,
  Clock,
  Sparkles,
  Phone,
  RefreshCw,
} from "lucide-react";
import { Button } from "../ui/Button";
import { Modal } from "../ui/Modal";
import { useToast } from "../ui/Toast";
import { formatPhone, formatAppointmentDate, formatTimeRange } from "@/lib/utils";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { SessionUser, SentMessageItem, MessageTemplateItem } from "@/lib/types";

const TEMPLATE_VARIABLES = [
  { tag: "{имя}", desc: "Имя клиента" },
  { tag: "{дата}", desc: "Дата записи" },
  { tag: "{время}", desc: "Время начала" },
  { tag: "{барбер}", desc: "Имя мастера" },
  { tag: "{услуги}", desc: "Список услуг" },
  { tag: "{адрес}", desc: "Адрес барбершопа" },
  { tag: "{название_барбершопа}", desc: "Название" },
];

interface MessagesViewProps {
  currentUser: SessionUser | null;
}

export function MessagesView({ currentUser }: MessagesViewProps) {
  const { toast, success, error: toastError } = useToast();
  const [activeTab, setActiveTab] = useState<"log" | "templates" | "settings">("log");

  // Log state
  const [messages, setMessages] = useState<SentMessageItem[]>([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [channelFilter, setChannelFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedMessage, setSelectedMessage] = useState<SentMessageItem | null>(null);
  const [retrying, setRetrying] = useState(false);

  // Templates state
  const [templates, setTemplates] = useState<MessageTemplateItem[]>([]);
  const [loadingTemplates, setLoadingTemplates] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<MessageTemplateItem | null>(null);
  const [templateText, setTemplateText] = useState("");
  const [savingTemplate, setSavingTemplate] = useState(false);

  // Settings state
  const [shopSettings, setShopSettings] = useState<any>(null);
  const [loadingSettings, setLoadingSettings] = useState(false);
  const [savingSettings, setSavingSettings] = useState(false);
  const [triggeringReminders, setTriggeringReminders] = useState(false);

  // Load message log
  const loadMessages = () => {
    setLoadingMessages(true);
    const params = new URLSearchParams();
    if (channelFilter !== "all") params.set("channel", channelFilter);
    if (typeFilter !== "all") params.set("type", typeFilter);
    if (statusFilter !== "all") params.set("status", statusFilter);

    fetch(`/api/messages?${params.toString()}`)
      .then((r) => r.json())
      .then((d) => setMessages(d.messages || []))
      .catch((err) => console.error("Error loading messages:", err))
      .finally(() => setLoadingMessages(false));
  };

  // Load templates
  const loadTemplates = () => {
    setLoadingTemplates(true);
    fetch("/api/messages/templates")
      .then((r) => r.json())
      .then((d) => setTemplates(d.templates || []))
      .catch((err) => console.error("Error loading templates:", err))
      .finally(() => setLoadingTemplates(false));
  };

  // Load settings
  const loadSettings = () => {
    setLoadingSettings(true);
    fetch("/api/settings")
      .then((r) => r.json())
      .then((d) => setShopSettings(d.shop))
      .catch((err) => console.error("Error loading settings:", err))
      .finally(() => setLoadingSettings(false));
  };

  useEffect(() => {
    if (activeTab === "log") loadMessages();
    if (activeTab === "templates") loadTemplates();
    if (activeTab === "settings") loadSettings();
  }, [activeTab, channelFilter, typeFilter, statusFilter]);

  // Retry sending failed message (Section 34 & 57)
  const handleRetryMessage = async (msgId: string) => {
    setRetrying(true);
    try {
      const res = await fetch(`/api/messages/${msgId}/retry`, {
        method: "POST",
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Не удалось повторить отправку");
      success("✓ Сообщение успешно отправлено повторно");
      setSelectedMessage(null);
      loadMessages();
    } catch (err: any) {
      toastError(err.message);
    } finally {
      setRetrying(false);
    }
  };

  // Save template edit
  const handleSaveTemplate = async () => {
    if (!editingTemplate) return;
    setSavingTemplate(true);
    try {
      const res = await fetch("/api/messages/templates", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: editingTemplate.id,
          text: templateText,
        }),
      });
      if (!res.ok) throw new Error("Не удалось сохранить шаблон");
      success("✓ Шаблон сохранен");
      setEditingTemplate(null);
      loadTemplates();
    } catch (err: any) {
      toastError(err.message);
    } finally {
      setSavingTemplate(false);
    }
  };

  // Trigger automated reminder batch runner
  const handleTriggerAutomatedReminders = async () => {
    setTriggeringReminders(true);
    try {
      const res = await fetch("/api/messages/trigger-reminders", {
        method: "POST",
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Ошибка запуска напоминаний");
      success(data.message);
      if (activeTab === "log") loadMessages();
    } catch (err: any) {
      toastError(err.message);
    } finally {
      setTriggeringReminders(false);
    }
  };

  // Update notification settings
  const handleSaveSettings = async () => {
    if (!shopSettings) return;
    setSavingSettings(true);
    try {
      const res = await fetch("/api/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          autoReminder24h: shopSettings.autoReminder24h,
          autoReminder2h: shopSettings.autoReminder2h,
          primaryChannel: shopSettings.primaryChannel,
          fallbackChannel: shopSettings.fallbackChannel,
        }),
      });
      if (!res.ok) throw new Error("Не удалось сохранить настройки");
      success("✓ Настройки уведомлений сохранены");
      loadSettings();
    } catch (err: any) {
      toastError(err.message);
    } finally {
      setSavingSettings(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-primary">Сообщения</h1>
          <p className="text-xs text-secondary mt-0.5">
            Журнал отправки, шаблоны напоминаний и настройки автоматических уведомлений
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleTriggerAutomatedReminders}
            isLoading={triggeringReminders}
            className="text-xs font-semibold"
            title="Проверить предстоящие записи и отправить напоминания за 24ч и 2ч"
          >
            <RefreshCw className="w-3.5 h-3.5 mr-1.5" />
            Запустить проверку напоминаний
          </Button>
        </div>
      </div>

      {/* Tabs navigation (Section 32) */}
      <div className="flex items-center border-b border-border text-xs font-semibold">
        <button
          onClick={() => setActiveTab("log")}
          className={`px-4 py-2.5 border-b-2 transition-colors ${
            activeTab === "log"
              ? "border-primary text-primary"
              : "border-transparent text-secondary hover:text-primary"
          }`}
        >
          Журнал сообщений
        </button>
        <button
          onClick={() => setActiveTab("templates")}
          className={`px-4 py-2.5 border-b-2 transition-colors ${
            activeTab === "templates"
              ? "border-primary text-primary"
              : "border-transparent text-secondary hover:text-primary"
          }`}
        >
          Шаблоны
        </button>
        <button
          onClick={() => setActiveTab("settings")}
          className={`px-4 py-2.5 border-b-2 transition-colors ${
            activeTab === "settings"
              ? "border-primary text-primary"
              : "border-transparent text-secondary hover:text-primary"
          }`}
        >
          Настройки
        </button>
      </div>

      {/* TAB 1: Log (Section 33) */}
      {activeTab === "log" && (
        <div className="space-y-3">
          {/* Filters */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <select
              value={channelFilter}
              onChange={(e) => setChannelFilter(e.target.value)}
              className="h-8 px-2 bg-surface rounded-crm border border-border focus:outline-none"
            >
              <option value="all">Все каналы</option>
              <option value="whatsapp">WhatsApp</option>
              <option value="telegram">Telegram</option>
              <option value="sms">SMS</option>
            </select>

            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="h-8 px-2 bg-surface rounded-crm border border-border focus:outline-none"
            >
              <option value="all">Все типы</option>
              <option value="reminder_24h">Напоминание за 24ч</option>
              <option value="reminder_2h">Напоминание за 2ч</option>
              <option value="manual">Ручное</option>
            </select>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="h-8 px-2 bg-surface rounded-crm border border-border focus:outline-none"
            >
              <option value="all">Все статусы</option>
              <option value="sent">Отправлено</option>
              <option value="failed">Ошибка</option>
            </select>
          </div>

          {/* Table */}
          {loadingMessages ? (
            <div className="py-12 text-center text-xs text-secondary">
              Загрузка журнала сообщений...
            </div>
          ) : messages.length === 0 ? (
            <div className="p-12 text-center bg-surface rounded-crm border border-border space-y-2">
              <MessageSquare className="w-8 h-8 text-secondary mx-auto" />
              <div className="text-sm font-semibold text-primary">Сообщений пока нет</div>
              <div className="text-xs text-secondary">
                Сообщения появляются после создания записей и запуска напоминаний.
              </div>
            </div>
          ) : (
            <div className="bg-surface rounded-crm border border-border shadow-subtle overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-brand-50 border-b border-border text-secondary font-semibold uppercase text-[10px] tracking-wider">
                  <tr>
                    <th className="py-3 px-4">Дата / Время</th>
                    <th className="py-3 px-4">Клиент</th>
                    <th className="py-3 px-4">Канал</th>
                    <th className="py-3 px-4">Тип</th>
                    <th className="py-3 px-4">Статус</th>
                    <th className="py-3 px-4 text-right">Действие</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/60">
                  {messages.map((m) => (
                    <tr
                      key={m.id}
                      onClick={() => setSelectedMessage(m)}
                      className="hover:bg-brand-50/60 cursor-pointer transition-colors"
                    >
                      <td className="py-3 px-4 text-secondary">
                        {format(new Date(m.createdAt), "d MMM yyyy, HH:mm", { locale: ru })}
                      </td>
                      <td className="py-3 px-4 font-semibold text-primary">
                        {m.client.name}
                        <span className="block font-normal text-[11px] text-secondary">
                          {formatPhone(m.client.phone)}
                        </span>
                      </td>
                      <td className="py-3 px-4 uppercase font-bold text-[10px] text-neutral-700">
                        {m.channel}
                      </td>
                      <td className="py-3 px-4 text-secondary">
                        {m.type === "reminder_24h"
                          ? "За 24 часа"
                          : m.type === "reminder_2h"
                          ? "За 2 часа"
                          : "Ручное"}
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-semibold border ${
                            m.status === "sent"
                              ? "bg-emerald-50 text-emerald-700 border-emerald-200"
                              : "bg-rose-50 text-rose-700 border-rose-200"
                          }`}
                        >
                          <span
                            className={`w-1.5 h-1.5 rounded-full ${
                              m.status === "sent" ? "bg-emerald-500" : "bg-rose-500"
                            }`}
                          />
                          {m.status === "sent" ? "Отправлено" : "Ошибка"}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <span className="text-secondary hover:text-primary font-medium text-[11px]">
                          Подробнее →
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: Templates (Section 35-36) */}
      {activeTab === "templates" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {templates.map((tpl) => (
              <div
                key={tpl.id}
                className="p-5 rounded-crm bg-surface border border-border shadow-subtle space-y-3"
              >
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-primary">{tpl.title}</h3>
                  <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-brand-100 text-secondary">
                    {tpl.type}
                  </span>
                </div>

                <p className="text-xs text-neutral-700 bg-brand-50 p-3 rounded-crm whitespace-pre-wrap font-mono leading-relaxed border border-border/60">
                  {tpl.text}
                </p>

                <div className="pt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full text-xs font-semibold"
                    onClick={() => {
                      setEditingTemplate(tpl);
                      setTemplateText(tpl.text);
                    }}
                  >
                    Редактировать шаблон
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: Settings (Section 37) */}
      {activeTab === "settings" && shopSettings && (
        <div className="max-w-xl p-6 rounded-crm bg-surface border border-border shadow-subtle space-y-6">
          <h3 className="text-base font-bold text-primary">
            Настройки автоматических напоминаний
          </h3>

          <div className="space-y-3">
            <label className="flex items-center gap-3 p-3 rounded-crm border border-border bg-brand-50/50 cursor-pointer">
              <input
                type="checkbox"
                checked={shopSettings.autoReminder24h}
                onChange={(e) =>
                  setShopSettings({ ...shopSettings, autoReminder24h: e.target.checked })
                }
                className="w-4 h-4 text-primary rounded"
              />
              <div>
                <span className="text-xs font-semibold text-primary block">
                  Напоминание за 24 часа
                </span>
                <span className="text-[11px] text-secondary">
                  Автоматически отправлять сообщение клиенту за сутки до визита
                </span>
              </div>
            </label>

            <label className="flex items-center gap-3 p-3 rounded-crm border border-border bg-brand-50/50 cursor-pointer">
              <input
                type="checkbox"
                checked={shopSettings.autoReminder2h}
                onChange={(e) =>
                  setShopSettings({ ...shopSettings, autoReminder2h: e.target.checked })
                }
                className="w-4 h-4 text-primary rounded"
              />
              <div>
                <span className="text-xs font-semibold text-primary block">
                  Напоминание за 2 часа
                </span>
                <span className="text-[11px] text-secondary">
                  Короткое напоминание в день визита для снижения no-show
                </span>
              </div>
            </label>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-2 border-t border-border">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
                Основной канал
              </label>
              <select
                value={shopSettings.primaryChannel}
                onChange={(e) =>
                  setShopSettings({ ...shopSettings, primaryChannel: e.target.value })
                }
                className="w-full h-10 px-3 bg-surface text-primary text-xs rounded-crm border border-border focus:outline-none"
              >
                <option value="whatsapp">WhatsApp</option>
                <option value="telegram">Telegram</option>
                <option value="sms">SMS</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
                Резервный канал
              </label>
              <select
                value={shopSettings.fallbackChannel}
                onChange={(e) =>
                  setShopSettings({ ...shopSettings, fallbackChannel: e.target.value })
                }
                className="w-full h-10 px-3 bg-surface text-primary text-xs rounded-crm border border-border focus:outline-none"
              >
                <option value="sms">SMS</option>
                <option value="telegram">Telegram</option>
                <option value="whatsapp">WhatsApp</option>
              </select>
            </div>
          </div>

          <div className="pt-2">
            <Button
              variant="primary"
              size="sm"
              isLoading={savingSettings}
              onClick={handleSaveSettings}
              className="text-xs font-semibold px-4"
            >
              Сохранить настройки
            </Button>
          </div>
        </div>
      )}

      {/* Message Details Modal (Section 34) */}
      <Modal
        isOpen={Boolean(selectedMessage)}
        onClose={() => setSelectedMessage(null)}
        title={selectedMessage?.client.name || "Детали сообщения"}
        description={selectedMessage ? `${selectedMessage.channel.toUpperCase()} • ${selectedMessage.type}` : ""}
        footer={
          <>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSelectedMessage(null)}
              disabled={retrying}
            >
              Закрыть
            </Button>
            {selectedMessage?.status === "failed" && (
              <Button
                variant="primary"
                size="sm"
                isLoading={retrying}
                onClick={() => selectedMessage && handleRetryMessage(selectedMessage.id)}
              >
                <RotateCw className="w-3.5 h-3.5 mr-1" />
                Повторить отправку
              </Button>
            )}
          </>
        }
      >
        {selectedMessage && (
          <div className="space-y-4 text-xs">
            {selectedMessage.status === "failed" && (
              <div className="p-3 rounded-crm bg-rose-50 border border-rose-200 text-rose-800">
                <span className="font-semibold block mb-0.5">Ошибка отправки:</span>
                {selectedMessage.errorMessage || "Таймаут соединения шлюза"}
              </div>
            )}

            <div className="grid grid-cols-2 gap-3 p-3 rounded-crm bg-brand-50 border border-border">
              <div>
                <span className="text-[10px] text-secondary uppercase font-semibold block">
                  Канал и тип
                </span>
                <span className="font-medium text-primary capitalize">
                  {selectedMessage.channel} ({selectedMessage.type})
                </span>
              </div>
              <div>
                <span className="text-[10px] text-secondary uppercase font-semibold block">
                  Время создания
                </span>
                <span className="font-medium text-primary">
                  {format(new Date(selectedMessage.createdAt), "d MMMM yyyy, HH:mm", { locale: ru })}
                </span>
              </div>
            </div>

            <div>
              <span className="text-[10px] text-secondary uppercase font-semibold block mb-1">
                Текст отправленного сообщения:
              </span>
              <p className="p-3 rounded-crm bg-brand-50 text-neutral-800 font-mono whitespace-pre-wrap leading-relaxed border border-border/60">
                {selectedMessage.text}
              </p>
            </div>
          </div>
        )}
      </Modal>

      {/* Edit Template Modal with Variable Insert Buttons (Section 36) */}
      <Modal
        isOpen={Boolean(editingTemplate)}
        onClose={() => setEditingTemplate(null)}
        title={editingTemplate?.title || "Редактировать шаблон"}
        description="Поддерживаемые переменные будут заменены реальными данными"
        maxWidthClass="max-w-lg"
        footer={
          <>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setEditingTemplate(null)}
              disabled={savingTemplate}
            >
              Отмена
            </Button>
            <Button
              variant="primary"
              size="sm"
              isLoading={savingTemplate}
              onClick={handleSaveTemplate}
            >
              Сохранить шаблон
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
              Текст сообщения
            </label>
            <textarea
              rows={6}
              value={templateText}
              onChange={(e) => setTemplateText(e.target.value)}
              className="w-full p-3 bg-surface text-primary text-xs rounded-crm border border-border font-mono leading-relaxed focus:outline-none focus:border-primary resize-none"
            />
          </div>

          {/* Variables insertion palette (Section 36) */}
          <div className="space-y-1.5">
            <span className="text-[11px] font-semibold text-secondary uppercase tracking-wider">
              Доступные переменные (кликните для вставки):
            </span>
            <div className="flex flex-wrap gap-1.5">
              {TEMPLATE_VARIABLES.map((v) => (
                <button
                  key={v.tag}
                  type="button"
                  onClick={() => setTemplateText((prev) => prev + " " + v.tag)}
                  className="px-2 py-1 rounded bg-brand-100 hover:bg-brand-200 text-[11px] font-mono font-medium text-primary border border-border transition-colors"
                  title={v.desc}
                >
                  {v.tag}
                </button>
              ))}
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
}
