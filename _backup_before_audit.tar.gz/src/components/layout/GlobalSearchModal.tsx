"use client";

import React, { useState, useEffect, useRef } from "react";
import { Search, X, User, Calendar, Phone, ArrowRight } from "lucide-react";
import { formatAppointmentDate, formatTimeRange, formatPhone } from "@/lib/utils";

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectClient?: (clientId: string) => void;
  onSelectAppointment?: (appointmentId: string) => void;
}

export function GlobalSearchModal({
  isOpen,
  onClose,
  onSelectClient,
  onSelectAppointment,
}: GlobalSearchModalProps) {
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<{ clients: any[]; appointments: any[] }>({
    clients: [],
    appointments: [],
  });
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 50);
    } else {
      setQuery("");
      setResults({ clients: [], appointments: [] });
    }
  }, [isOpen]);

  useEffect(() => {
    if (!query || query.trim().length < 2) {
      setResults({ clients: [], appointments: [] });
      return;
    }

    const timer = setTimeout(() => {
      setLoading(true);
      fetch(`/api/search?q=${encodeURIComponent(query.trim())}`)
        .then((res) => res.json())
        .then((data) => {
          setResults({
            clients: data.clients || [],
            appointments: data.appointments || [],
          });
        })
        .catch((err) => console.error("Search error:", err))
        .finally(() => setLoading(false));
    }, 250);

    return () => clearTimeout(timer);
  }, [query]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex min-h-full items-start justify-center p-4 pt-20 text-center">
        {/* Backdrop */}
        <div
          className="fixed inset-0 bg-black/40 backdrop-blur-xs transition-opacity"
          onClick={onClose}
        />

        <div className="w-full max-w-xl transform rounded-crm-lg bg-surface text-left shadow-modal border border-border animate-modal relative z-10 overflow-hidden">
          {/* Search Input */}
          <div className="flex items-center px-4 py-3.5 border-b border-border gap-3">
            <Search className="w-5 h-5 text-secondary shrink-0" />
            <input
              ref={inputRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Поиск клиента, телефона или записи... (Esc для выхода)"
              className="flex-1 bg-transparent text-sm text-primary placeholder:text-secondary/60 focus:outline-none"
            />
            {query && (
              <button
                onClick={() => setQuery("")}
                className="p-1 text-secondary hover:text-primary rounded"
              >
                <X className="w-4 h-4" />
              </button>
            )}
            <kbd className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-semibold text-secondary bg-brand-100 rounded border border-border">
              ESC
            </kbd>
          </div>

          {/* Search Results */}
          <div className="max-h-96 overflow-y-auto p-2">
            {loading && (
              <div className="py-8 text-center text-xs text-secondary">
                Поиск...
              </div>
            )}

            {!loading && query && results.clients.length === 0 && results.appointments.length === 0 && (
              <div className="py-8 text-center text-xs text-secondary">
                Ничего не найдено по запросу «{query}»
              </div>
            )}

            {!loading && !query && (
              <div className="py-6 px-4 text-center text-xs text-secondary">
                Введите имя клиента, номер телефона или комментарий к записи.
              </div>
            )}

            {/* Clients Results */}
            {results.clients.length > 0 && (
              <div className="mb-3">
                <div className="px-3 py-1.5 text-[11px] font-semibold text-secondary uppercase tracking-wider">
                  Клиенты
                </div>
                <div className="space-y-1">
                  {results.clients.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => {
                        onSelectClient?.(c.id);
                        onClose();
                      }}
                      className="w-full flex items-center justify-between p-2.5 rounded-crm hover:bg-brand-50 text-left transition-colors group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-brand-100 flex items-center justify-center text-secondary text-xs">
                          <User className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-sm font-medium text-primary group-hover:text-black">
                            {c.name}
                          </div>
                          <div className="text-xs text-secondary flex items-center gap-1.5">
                            <Phone className="w-3 h-3 text-secondary/70" />
                            {formatPhone(c.phone)}
                          </div>
                        </div>
                      </div>
                      <ArrowRight className="w-4 h-4 text-secondary group-hover:text-primary transition-transform group-hover:translate-x-0.5" />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Appointments Results */}
            {results.appointments.length > 0 && (
              <div>
                <div className="px-3 py-1.5 text-[11px] font-semibold text-secondary uppercase tracking-wider">
                  Записи
                </div>
                <div className="space-y-1">
                  {results.appointments.map((a) => (
                    <button
                      key={a.id}
                      onClick={() => {
                        onSelectAppointment?.(a.id);
                        onClose();
                      }}
                      className="w-full flex items-center justify-between p-2.5 rounded-crm hover:bg-brand-50 text-left transition-colors group"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-semibold shrink-0"
                          style={{ backgroundColor: a.barber.color }}
                        >
                          <Calendar className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-sm font-medium text-primary">
                            {a.client.name} — {a.barber.name}
                          </div>
                          <div className="text-xs text-secondary">
                            {formatAppointmentDate(a.startAt)}, {formatTimeRange(a.startAt, a.endAt)}
                            {a.services.length > 0 && (
                              <span className="ml-1 text-zinc-400">
                                • {a.services.map((s: any) => s.service.name).join(", ")}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      <ArrowRight className="w-4 h-4 text-secondary group-hover:text-primary transition-transform group-hover:translate-x-0.5" />
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
