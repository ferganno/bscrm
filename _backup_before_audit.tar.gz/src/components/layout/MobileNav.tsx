"use client";

import React, { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Calendar as CalendarIcon,
  Users,
  Plus,
  MessageSquare,
  Menu,
  Scissors,
  Sparkles,
  Settings,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { SessionUser } from "@/lib/types";
import { UserSwitcher } from "./UserSwitcher";

interface MobileNavProps {
  currentUser: SessionUser | null;
  onNewAppointmentClick: () => void;
}

export function MobileNav({ currentUser, onNewAppointmentClick }: MobileNavProps) {
  const pathname = usePathname();
  const [showMoreMenu, setShowMoreMenu] = useState(false);

  return (
    <>
      {/* Mobile Drawer for "More" */}
      {showMoreMenu && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div
            className="fixed inset-0 bg-black/40 backdrop-blur-xs"
            onClick={() => setShowMoreMenu(false)}
          />
          <div className="fixed bottom-16 inset-x-0 bg-surface rounded-t-2xl p-5 border-t border-border shadow-modal animate-modal space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-border">
              <span className="text-xs font-semibold uppercase tracking-wider text-secondary">
                Дополнительные разделы
              </span>
              <button
                onClick={() => setShowMoreMenu(false)}
                className="p-1 text-secondary hover:text-primary"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <Link
                href="/barbers"
                onClick={() => setShowMoreMenu(false)}
                className={cn(
                  "flex flex-col items-center justify-center p-3 rounded-crm border text-xs font-medium gap-1.5 transition-colors",
                  pathname.startsWith("/barbers")
                    ? "bg-brand-100 border-primary text-primary"
                    : "border-border text-neutral-700 hover:bg-brand-50"
                )}
              >
                <Scissors className="w-5 h-5 text-secondary" />
                <span>Барберы</span>
              </Link>
              <Link
                href="/services"
                onClick={() => setShowMoreMenu(false)}
                className={cn(
                  "flex flex-col items-center justify-center p-3 rounded-crm border text-xs font-medium gap-1.5 transition-colors",
                  pathname.startsWith("/services")
                    ? "bg-brand-100 border-primary text-primary"
                    : "border-border text-neutral-700 hover:bg-brand-50"
                )}
              >
                <Sparkles className="w-5 h-5 text-secondary" />
                <span>Услуги</span>
              </Link>
              <Link
                href="/settings"
                onClick={() => setShowMoreMenu(false)}
                className={cn(
                  "flex flex-col items-center justify-center p-3 rounded-crm border text-xs font-medium gap-1.5 transition-colors",
                  pathname.startsWith("/settings")
                    ? "bg-brand-100 border-primary text-primary"
                    : "border-border text-neutral-700 hover:bg-brand-50"
                )}
              >
                <Settings className="w-5 h-5 text-secondary" />
                <span>Настройки</span>
              </Link>
            </div>

            <div className="pt-2 border-t border-border">
              <UserSwitcher currentUser={currentUser} />
            </div>
          </div>
        </div>
      )}

      {/* Bottom bar */}
      <div className="fixed bottom-0 inset-x-0 h-16 bg-surface/95 backdrop-blur-md border-t border-border md:hidden z-40 px-3 flex items-center justify-around">
        <Link
          href="/"
          className={cn(
            "flex flex-col items-center justify-center flex-1 h-full text-[10px] font-medium transition-colors",
            pathname === "/" ? "text-primary" : "text-secondary hover:text-primary"
          )}
        >
          <CalendarIcon className="w-5 h-5 mb-0.5" />
          <span>Календарь</span>
        </Link>

        <Link
          href="/clients"
          className={cn(
            "flex flex-col items-center justify-center flex-1 h-full text-[10px] font-medium transition-colors",
            pathname.startsWith("/clients") ? "text-primary" : "text-secondary hover:text-primary"
          )}
        >
          <Users className="w-5 h-5 mb-0.5" />
          <span>Клиенты</span>
        </Link>

        {/* Central '+' action button */}
        <div className="flex-1 flex justify-center -mt-5">
          <button
            onClick={onNewAppointmentClick}
            className="w-12 h-12 rounded-full bg-primary text-white shadow-modal flex items-center justify-center hover:bg-neutral-800 transition-transform active:scale-95"
            aria-label="Новая запись"
          >
            <Plus className="w-6 h-6 stroke-[2.5]" />
          </button>
        </div>

        <Link
          href="/messages"
          className={cn(
            "flex flex-col items-center justify-center flex-1 h-full text-[10px] font-medium transition-colors",
            pathname.startsWith("/messages") ? "text-primary" : "text-secondary hover:text-primary"
          )}
        >
          <MessageSquare className="w-5 h-5 mb-0.5" />
          <span>Сообщения</span>
        </Link>

        <button
          onClick={() => setShowMoreMenu(!showMoreMenu)}
          className={cn(
            "flex flex-col items-center justify-center flex-1 h-full text-[10px] font-medium transition-colors",
            showMoreMenu ? "text-primary" : "text-secondary hover:text-primary"
          )}
        >
          <Menu className="w-5 h-5 mb-0.5" />
          <span>Ещё</span>
        </button>
      </div>
    </>
  );
}
