"use client";

import React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Calendar as CalendarIcon,
  Users,
  Scissors,
  Sparkles,
  MessageSquare,
  Settings,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { SessionUser } from "@/lib/types";
import { UserSwitcher } from "./UserSwitcher";

interface SidebarProps {
  currentUser: SessionUser | null;
}

export function Sidebar({ currentUser }: SidebarProps) {
  const pathname = usePathname();

  const navItems = [
    {
      name: "Календарь",
      href: "/",
      icon: CalendarIcon,
      active: pathname === "/",
    },
    {
      name: "Клиенты",
      href: "/clients",
      icon: Users,
      active: pathname.startsWith("/clients"),
    },
    {
      name: "Барберы",
      href: "/barbers",
      icon: Scissors,
      active: pathname.startsWith("/barbers"),
    },
    {
      name: "Услуги",
      href: "/services",
      icon: Sparkles,
      active: pathname.startsWith("/services"),
    },
    {
      name: "Сообщения",
      href: "/messages",
      icon: MessageSquare,
      active: pathname.startsWith("/messages"),
    },
    {
      name: "Настройки",
      href: "/settings",
      icon: Settings,
      active: pathname.startsWith("/settings"),
    },
  ];

  return (
    <aside className="hidden md:flex flex-col w-56 lg:w-60 bg-surface border-r border-border shrink-0 select-none h-screen sticky top-0">
      {/* Brand Header */}
      <div className="px-5 py-5 border-b border-border/60">
        <Link href="/" className="inline-flex items-center gap-2">
          <div className="w-7 h-7 rounded-crm bg-primary text-white flex items-center justify-center font-black text-sm tracking-tighter">
            B
          </div>
          <div>
            <div className="font-extrabold tracking-tight text-sm text-primary uppercase">
              BARBERCRM
            </div>
            <div className="text-[11px] font-medium text-secondary truncate max-w-[130px]">
              {currentUser?.shopName || "Barber Studio"}
            </div>
          </div>
        </Link>
      </div>

      {/* Navigation */}
      <div className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        <div className="px-2 pb-1.5 text-[10px] font-semibold text-secondary uppercase tracking-wider">
          Главное
        </div>
        {navItems.slice(0, 4).map((item) => {
          const Icon = item.icon;
          return (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                "flex items-center gap-3 px-3 py-2 rounded-crm text-sm font-medium transition-colors",
                item.active
                  ? "bg-primary text-white shadow-subtle"
                  : "text-neutral-600 hover:text-primary hover:bg-brand-100/70"
              )}
            >
              <Icon className={cn("w-4 h-4 shrink-0", item.active ? "text-white" : "text-secondary")} />
              <span>{item.name}</span>
            </Link>
          );
        })}

        <div className="pt-4 px-2 pb-1.5 text-[10px] font-semibold text-secondary uppercase tracking-wider">
          Управление
        </div>
        {navItems.slice(4).map((item) => {
          const Icon = item.icon;
          return (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                "flex items-center gap-3 px-3 py-2 rounded-crm text-sm font-medium transition-colors",
                item.active
                  ? "bg-primary text-white shadow-subtle"
                  : "text-neutral-600 hover:text-primary hover:bg-brand-100/70"
              )}
            >
              <Icon className={cn("w-4 h-4 shrink-0", item.active ? "text-white" : "text-secondary")} />
              <span>{item.name}</span>
            </Link>
          );
        })}
      </div>

      {/* Bottom User Area */}
      <div className="p-3 border-t border-border/80 bg-brand-50/40">
        <UserSwitcher currentUser={currentUser} />
      </div>
    </aside>
  );
}
