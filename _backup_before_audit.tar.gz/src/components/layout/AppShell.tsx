"use client";

import React, { useState, useEffect, useCallback } from "react";
import { Sidebar } from "./Sidebar";
import { Header } from "./Header";
import { MobileNav } from "./MobileNav";
import { GlobalSearchModal } from "./GlobalSearchModal";
import { AppointmentDrawer } from "../appointments/AppointmentDrawer";
import { AppointmentDetailsDrawer } from "../appointments/AppointmentDetailsDrawer";
import { Modal } from "../ui/Modal";
import { Button } from "../ui/Button";
import { useToast } from "../ui/Toast";
import { SessionUser, AppointmentItem } from "@/lib/types";

interface AppShellProps {
  children: (props: {
    currentUser: SessionUser | null;
    openNewAppointment: (params?: { date?: Date; time?: string; barberId?: string; clientId?: string }) => void;
    openAppointmentDetails: (app: AppointmentItem) => void;
    openClientMessageModal: (client: any) => void;
    refreshTrigger: number;
    triggerRefresh: () => void;
  }) => React.ReactNode;
}

export function AppShell({ children }: AppShellProps) {
  const { toast, success, error: toastError } = useToast();
  const [currentUser, setCurrentUser] = useState<SessionUser | null>(null);
  const [loadingUser, setLoadingUser] = useState(true);

  // Global search modal
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // New appointment drawer state
  const [isNewAppointmentOpen, setIsNewAppointmentOpen] = useState(false);
  const [newAppParams, setNewAppParams] = useState<{
    date?: Date;
    time?: string;
    barberId?: string;
    clientId?: string;
  }>({});

  // Appointment details drawer state
  const [selectedAppointment, setSelectedAppointment] = useState<AppointmentItem | null>(null);

  // Quick message modal state (for "Написать клиенту")
  const [messagingClient, setMessagingClient] = useState<any | null>(null);
  const [messageText, setMessageText] = useState("");
  const [messageChannel, setMessageChannel] = useState<"whatsapp" | "telegram" | "sms">("whatsapp");
  const [sendingMessage, setSendingMessage] = useState(false);

  // Global refresh trigger counter
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const triggerRefresh = useCallback(() => setRefreshTrigger((c) => c + 1), []);

  useEffect(() => {
    fetch("/api/auth/me")
      .then((res) => res.json())
      .then((data) => {
        if (data.user) {
          setCurrentUser(data.user);
        }
      })
      .catch((err) => console.error("Error loading current user:", err))
      .finally(() => setLoadingUser(false));
  }, []);

  // Keyboard shortcut listener: '/' for search, 'N' for new appointment
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (["INPUT", "TEXTAREA", "SELECT"].includes((e.target as HTMLElement).tagName)) {
        return;
      }
      if (e.key === "/" || e.key === "?") {
        e.preventDefault();
        setIsSearchOpen(true);
      } else if (e.key === "n" || e.key === "N" || e.key === "т" || e.key === "Т") {
        e.preventDefault();
        setIsNewAppointmentOpen(true);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  // Open new appointment drawer handler
  const handleOpenNewAppointment = useCallback(
    (params?: { date?: Date; time?: string; barberId?: string; clientId?: string }) => {
      setNewAppParams(params || {});
      setIsNewAppointmentOpen(true);
    },
    []
  );

  // Open appointment details handler
  const handleOpenAppointmentDetails = useCallback((app: AppointmentItem) => {
    setSelectedAppointment(app);
  }, []);

  // Send message to client modal submit
  const handleSendMessage = async () => {
    if (!messagingClient || !messageText.trim()) return;
    setSendingMessage(true);
    try {
      const res = await fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clientId: messagingClient.id,
          channel: messageChannel,
          text: messageText.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Ошибка отправки");
      if (messageChannel === "whatsapp" && data.whatsappUrl) {
        window.open(data.whatsappUrl, "_blank");
        success("✓ Открыт WhatsApp для отправки клиенту");
      } else {
        success("✓ Сообщение успешно отправлено клиенту");
      }
      setMessagingClient(null);
      setMessageText("");
      triggerRefresh();
    } catch (err: any) {
      toastError(err.message);
    } finally {
      setSendingMessage(false);
    }
  };

  return (
    <div className="min-h-screen flex bg-background text-primary selection:bg-brand-200">
      {/* Sidebar for Desktop */}
      <Sidebar currentUser={currentUser} />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 pb-16 md:pb-0">
        <Header
          currentUser={currentUser}
          onOpenSearch={() => setIsSearchOpen(true)}
          onNewAppointment={() => handleOpenNewAppointment()}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          {children({
            currentUser,
            openNewAppointment: handleOpenNewAppointment,
            openAppointmentDetails: handleOpenAppointmentDetails,
            openClientMessageModal: (client) => {
              setMessagingClient(client);
              setMessageText(`Здравствуйте, ${client.name}! Ждём вас в Barber Studio.`);
            },
            refreshTrigger,
            triggerRefresh,
          })}
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      <MobileNav
        currentUser={currentUser}
        onNewAppointmentClick={() => handleOpenNewAppointment()}
      />

      {/* Global Search Modal */}
      <GlobalSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectAppointment={(appId) => {
          fetch(`/api/appointments/${appId}`)
            .then((r) => r.json())
            .then((d) => {
              if (d.appointment) setSelectedAppointment(d.appointment);
            });
        }}
        onSelectClient={(clientId) => {
          // Navigate to clients with this client selected
          window.location.href = `/clients?id=${clientId}`;
        }}
      />

      {/* Global New Appointment Drawer */}
      <AppointmentDrawer
        isOpen={isNewAppointmentOpen}
        onClose={() => {
          setIsNewAppointmentOpen(false);
          setNewAppParams({});
        }}
        onSuccess={() => {
          triggerRefresh();
        }}
        initialDate={newAppParams.date}
        initialTime={newAppParams.time}
        initialBarberId={newAppParams.barberId}
        initialClientId={newAppParams.clientId}
      />

      {/* Global Appointment Details Drawer */}
      <AppointmentDetailsDrawer
        isOpen={Boolean(selectedAppointment)}
        onClose={() => setSelectedAppointment(null)}
        appointment={selectedAppointment}
        onUpdated={() => {
          triggerRefresh();
          // Reload current details
          if (selectedAppointment) {
            fetch(`/api/appointments/${selectedAppointment.id}`)
              .then((r) => r.json())
              .then((d) => setSelectedAppointment(d.appointment || null));
          }
        }}
        onBookAgain={(client, barberId, serviceIds) => {
          handleOpenNewAppointment({
            clientId: client.id,
            barberId,
          });
        }}
      />

      {/* Quick Message Modal ("Написать клиенту") */}
      <Modal
        isOpen={Boolean(messagingClient)}
        onClose={() => setMessagingClient(null)}
        title={messagingClient ? `Сообщение для: ${messagingClient.name}` : "Отправить сообщение"}
        description="Отправка ручного уведомления через мессенджер"
        footer={
          <>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setMessagingClient(null)}
              disabled={sendingMessage}
            >
              Отмена
            </Button>
            <Button
              variant="primary"
              size="sm"
              isLoading={sendingMessage}
              onClick={handleSendMessage}
            >
              Отправить
            </Button>
          </>
        }
      >
        {messagingClient && (
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
                Канал доставки
              </label>
              <select
                value={messageChannel}
                onChange={(e) => setMessageChannel(e.target.value as any)}
                className="w-full h-10 px-3 bg-surface text-primary text-xs rounded-crm border border-border focus:outline-none"
              >
                <option value="whatsapp">WhatsApp ({messagingClient.phone})</option>
                <option value="telegram">Telegram</option>
                <option value="sms">SMS</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
                Текст сообщения
              </label>
              <textarea
                rows={4}
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                className="w-full p-3 bg-surface text-primary text-xs rounded-crm border border-border focus:outline-none resize-none font-mono"
              />
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
