"use client";

import React from "react";
import { Search, Plus, Bell, RefreshCw } from "lucide-react";
import { Button } from "../ui/Button";
import { SessionUser } from "@/lib/types";

interface HeaderProps {
  currentUser: SessionUser | null;
  onOpenSearch: () => void;
  onNewAppointment: () => void;
}

export function Header({ currentUser, onOpenSearch, onNewAppointment }: HeaderProps) {
  return (
    <header className="h-14 lg:h-16 px-4 lg:px-8 border-b border-border/70 bg-surface/80 backdrop-blur-md flex items-center justify-between sticky top-0 z-30 shrink-0">
      {/* Search trigger */}
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenSearch}
          className="flex items-center gap-2.5 px-3 py-1.5 text-xs text-secondary bg-brand-50 hover:bg-brand-100 rounded-crm border border-border/80 transition-colors cursor-pointer w-48 sm:w-64 text-left"
          title="Глобальный поиск (Нажмите /)"
        >
          <Search className="w-3.5 h-3.5 text-secondary shrink-0" />
          <span className="truncate">Поиск клиента или записи...</span>
          <kbd className="ml-auto hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono text-secondary/80 bg-surface rounded border border-border">
            /
          </kbd>
        </button>
      </div>

      {/* Right controls */}
      <div className="flex items-center gap-2.5">
        <Button
          onClick={onNewAppointment}
          variant="primary"
          size="sm"
          className="h-9 px-3.5 text-xs font-semibold rounded-crm shadow-subtle flex items-center gap-1.5"
          title="Новая запись (Нажмите N)"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          <span className="hidden sm:inline">Новая запись</span>
          <kbd className="hidden md:inline-block ml-1 px-1.5 py-0.2 text-[9px] text-white/70 bg-neutral-800 rounded font-mono">
            N
          </kbd>
        </Button>
      </div>
    </header>
  );
}
