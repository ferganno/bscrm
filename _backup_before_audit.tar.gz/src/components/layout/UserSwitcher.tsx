"use client";

import React, { useState, useEffect, useRef } from "react";
import { UserRole, SessionUser } from "@/lib/types";
import { ChevronDown, Check, LogOut, ShieldAlert, User as UserIcon } from "lucide-react";
import { useToast } from "../ui/Toast";

interface UserSwitcherProps {
  currentUser: SessionUser | null;
  onUserChange?: (user: SessionUser) => void;
}

export function UserSwitcher({ currentUser, onUserChange }: UserSwitcherProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    // Fetch available users for switching
    fetch("/api/auth/me")
      .then((res) => res.json())
      .then((data) => {
        if (data.availableUsers) {
          setUsers(data.availableUsers);
        }
      })
      .catch((err) => console.error("Error loading users:", err));
  }, []);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSwitchUser = async (userId: string) => {
    setLoading(true);
    try {
      const res = await fetch("/api/auth/switch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId }),
      });
      const data = await res.json();
      if (data.success) {
        toast(`Переключено на: ${data.user.name} (${data.user.role})`);
        setIsOpen(false);
        window.location.reload();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getRoleBadge = (role: string) => {
    switch (role) {
      case "owner":
        return <span className="text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded bg-neutral-900 text-white">Owner</span>;
      case "admin":
        return <span className="text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-800">Admin</span>;
      default:
        return <span className="text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded bg-blue-100 text-blue-800">Barber</span>;
    }
  };

  if (!currentUser) return null;

  return (
    <div className="relative" ref={menuRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between p-2.5 rounded-crm hover:bg-brand-100/80 transition-colors text-left group"
        title="Сменить роль или пользователя"
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <div
            className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white shrink-0 shadow-xs"
            style={{ backgroundColor: currentUser.color || "#111111" }}
          >
            {currentUser.name.charAt(0)}
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-xs font-semibold text-primary truncate leading-tight flex items-center gap-1.5">
              {currentUser.name}
            </div>
            <div className="text-[11px] text-secondary capitalize flex items-center gap-1.5 mt-0.5">
              {getRoleBadge(currentUser.role)}
              <span className="text-zinc-400 text-[10px]">• {currentUser.shopName}</span>
            </div>
          </div>
        </div>
        <ChevronDown className="w-3.5 h-3.5 text-secondary group-hover:text-primary shrink-0 transition-transform duration-200" />
      </button>

      {isOpen && (
        <div className="absolute bottom-full left-0 mb-2 w-64 bg-surface rounded-crm-lg border border-border shadow-dropdown p-1.5 z-50 animate-fadeIn">
          <div className="px-2.5 py-1.5 border-b border-border/60 mb-1">
            <span className="text-[11px] font-medium text-secondary uppercase tracking-wider">
              Переключить аккаунт (Демо)
            </span>
          </div>

          <div className="space-y-0.5 max-h-56 overflow-y-auto">
            {users.map((u) => {
              const isSelected = u.id === currentUser.id;
              return (
                <button
                  key={u.id}
                  onClick={() => handleSwitchUser(u.id)}
                  disabled={loading}
                  className={`w-full flex items-center justify-between px-2.5 py-2 rounded-crm text-xs transition-colors ${
                    isSelected
                      ? "bg-brand-100/70 font-semibold text-primary"
                      : "hover:bg-brand-50 text-neutral-700"
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0 text-left">
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0"
                      style={{ backgroundColor: u.color }}
                    />
                    <div className="truncate">
                      <p className="truncate font-medium">{u.name}</p>
                      <p className="text-[10px] text-secondary capitalize">{u.role}</p>
                    </div>
                  </div>
                  {isSelected && <Check className="w-3.5 h-3.5 text-primary shrink-0 ml-1.5" />}
                </button>
              );
            })}
          </div>

          <div className="mt-1 pt-1 border-t border-border/60">
            <button
              onClick={() => {
                fetch("/api/auth/logout", { method: "POST" }).then(() => {
                  window.location.reload();
                });
              }}
              className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-crm text-xs text-rose-600 hover:bg-rose-50 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Выйти из аккаунта</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
