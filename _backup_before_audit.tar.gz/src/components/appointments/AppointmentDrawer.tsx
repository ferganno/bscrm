"use client";

import React, { useState, useEffect, useRef } from "react";
import { Drawer } from "../ui/Drawer";
import { Button } from "../ui/Button";
import { Input } from "../ui/Input";
import { Modal } from "../ui/Modal";
import { useToast } from "../ui/Toast";
import {
  Search,
  UserPlus,
  Clock,
  DollarSign,
  Calendar,
  Check,
  X,
  Repeat,
  AlertCircle,
  Scissors,
} from "lucide-react";
import { format, parseISO } from "date-fns";
import { ru } from "date-fns/locale";
import { formatPhone, formatCurrency, formatRelativeDate } from "@/lib/utils";

interface AppointmentDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  initialDate?: Date;
  initialTime?: string; // "11:30"
  initialBarberId?: string;
  initialClientId?: string;
}

export function AppointmentDrawer({
  isOpen,
  onClose,
  onSuccess,
  initialDate,
  initialTime,
  initialBarberId,
  initialClientId,
}: AppointmentDrawerProps) {
  const { toast, error: toastError, success: toastSuccess } = useToast();

  // State
  const [date, setDate] = useState<string>(
    format(initialDate || new Date(), "yyyy-MM-dd")
  );
  const [time, setTime] = useState<string>(initialTime || "12:00");
  const [barberId, setBarberId] = useState<string>(initialBarberId || "");
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const [manualDuration, setManualDuration] = useState<number | "">("");
  const [manualPrice, setManualPrice] = useState<number | "">("");
  const [comment, setComment] = useState("");
  const [saving, setSaving] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Client search state
  const [clientSearch, setClientSearch] = useState("");
  const [clientSearchResults, setClientSearchResults] = useState<any[]>([]);
  const [selectedClient, setSelectedClient] = useState<any | null>(null);
  const [clientHistorySnippet, setClientHistorySnippet] = useState<any | null>(null);
  const [showClientDropdown, setShowClientDropdown] = useState(false);

  // Quick new client modal state
  const [showNewClientModal, setShowNewClientModal] = useState(false);
  const [newClientName, setNewClientName] = useState("");
  const [newClientPhone, setNewClientPhone] = useState("+994 ");
  const [newClientNote, setNewClientNote] = useState("");
  const [creatingClient, setCreatingClient] = useState(false);
  const [newClientError, setNewClientError] = useState<string | null>(null);

  // Data lists
  const [barbers, setBarbers] = useState<any[]>([]);
  const [services, setServices] = useState<any[]>([]);

  // Synchronize initial props
  useEffect(() => {
    if (isOpen) {
      if (initialDate) setDate(format(initialDate, "yyyy-MM-dd"));
      if (initialTime) setTime(initialTime);
      if (initialBarberId) setBarberId(initialBarberId);
      setErrorMessage(null);

      // Load barbers & services
      fetch("/api/barbers")
        .then((r) => r.json())
        .then((d) => {
          const list = (d.barbers || []).filter((b: any) => b.isActive);
          setBarbers(list);
          if (!barberId && list.length > 0) {
            setBarberId(initialBarberId || list[0].id);
          }
        });

      fetch("/api/services?active=true")
        .then((r) => r.json())
        .then((d) => {
          setServices(d.services || []);
        });

      // If initialClientId provided
      if (initialClientId) {
        fetch(`/api/clients/${initialClientId}`)
          .then((r) => r.json())
          .then((d) => {
            if (d.client) {
              handleSelectClient(d.client);
            }
          });
      }
    } else {
      // Reset form on close
      setSelectedClient(null);
      setClientSearch("");
      setSelectedServices([]);
      setManualDuration("");
      setManualPrice("");
      setComment("");
      setErrorMessage(null);
    }
  }, [isOpen, initialDate, initialTime, initialBarberId, initialClientId]);

  // Client search debounced
  useEffect(() => {
    if (!clientSearch || clientSearch.length < 2) {
      setClientSearchResults([]);
      return;
    }
    const timer = setTimeout(() => {
      fetch(`/api/clients?search=${encodeURIComponent(clientSearch)}`)
        .then((r) => r.json())
        .then((d) => {
          setClientSearchResults(d.clients || []);
          setShowClientDropdown(true);
        });
    }, 200);
    return () => clearTimeout(timer);
  }, [clientSearch]);

  const handleSelectClient = (client: any) => {
    setSelectedClient(client);
    setClientSearch(client.name);
    setShowClientDropdown(false);

    // Fetch snippet of last visit for repeat scenario (Section 69)
    fetch(`/api/clients/${client.id}`)
      .then((r) => r.json())
      .then((d) => {
        if (d.client?.appointments && d.client.appointments.length > 0) {
          const lastApp = d.client.appointments[0];
          setClientHistorySnippet(lastApp);
        }
      });
  };

  // Calculate sum of services
  const selectedServiceObjects = services.filter((s) => selectedServices.includes(s.id));
  const autoDuration = selectedServiceObjects.reduce((acc, s) => acc + s.durationMinutes, 0);
  const autoPrice = selectedServiceObjects.reduce((acc, s) => acc + s.price, 0);

  const effectiveDuration = manualDuration !== "" ? Number(manualDuration) : autoDuration;
  const effectivePrice = manualPrice !== "" ? Number(manualPrice) : autoPrice;

  // Repeat services from last visit
  const handleRepeatServices = () => {
    if (!clientHistorySnippet) return;
    const sIds = clientHistorySnippet.services.map((s: any) => s.serviceId);
    setSelectedServices(sIds);
    if (clientHistorySnippet.barberId) {
      setBarberId(clientHistorySnippet.barberId);
    }
    toast("Услуги предыдущего визита скопированы!");
  };

  // Toggle service selection
  const toggleService = (sId: string) => {
    setSelectedServices((prev) =>
      prev.includes(sId) ? prev.filter((id) => id !== sId) : [...prev, sId]
    );
  };

  // Create new client inline
  const handleCreateNewClient = async () => {
    if (!newClientName.trim() || !newClientPhone.trim()) {
      setNewClientError("Заполните имя и номер телефона");
      return;
    }
    setCreatingClient(true);
    setNewClientError(null);

    try {
      const res = await fetch("/api/clients", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newClientName,
          phone: newClientPhone,
          notes: newClientNote,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        if (data.error === "duplicate") {
          setNewClientError(data.message);
          return;
        }
        throw new Error(data.error || "Ошибка при создании клиента");
      }

      toastSuccess("✓ Клиент создан!");
      setSelectedClient(data.client);
      setClientSearch(data.client.name);
      setShowNewClientModal(false);
      setNewClientName("");
      setNewClientPhone("+994 ");
      setNewClientNote("");
    } catch (err: any) {
      setNewClientError(err.message);
    } finally {
      setCreatingClient(false);
    }
  };

  // Submit appointment
  const handleSaveAppointment = async (sendReminder = false) => {
    setErrorMessage(null);

    if (!selectedClient) {
      setErrorMessage("Выберите клиента из списка или создайте нового");
      return;
    }

    if (!barberId) {
      setErrorMessage("Выберите барбера");
      return;
    }

    if (selectedServices.length === 0) {
      setErrorMessage("Выберите хотя бы одну услугу");
      return;
    }

    setSaving(true);
    try {
      const startAtDate = new Date(`${date}T${time}:00`);

      const res = await fetch("/api/appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clientId: selectedClient.id,
          barberId,
          startAt: startAtDate.toISOString(),
          serviceIds: selectedServices,
          manualDuration: manualDuration !== "" ? Number(manualDuration) : undefined,
          manualPrice: manualPrice !== "" ? Number(manualPrice) : undefined,
          comment,
          sendReminder,
        }),
      });

      const data = await res.json();

      if (sendReminder && data.whatsappUrl) {
        window.open(data.whatsappUrl, "_blank");
        toastSuccess("✓ Запись сохранена! Открыт WhatsApp для отправки сообщения клиенту");
      } else {
        toastSuccess("✓ Запись создана");
      }
      onSuccess();
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message);
      toastError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <Drawer
        isOpen={isOpen}
        onClose={onClose}
        title="Новая запись"
        description="Быстрое добавление клиента и бронирование времени"
        footer={
          <div className="flex flex-col gap-2">
            {errorMessage && (
              <div className="flex items-center gap-2 p-2.5 rounded-crm bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{errorMessage}</span>
              </div>
            )}
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                className="flex-1"
                onClick={onClose}
                disabled={saving}
              >
                Отмена
              </Button>
              <Button
                variant="primary"
                className="flex-1 font-semibold"
                isLoading={saving}
                onClick={() => handleSaveAppointment(false)}
              >
                Сохранить запись
              </Button>
            </div>
            <button
              onClick={() => handleSaveAppointment(true)}
              disabled={saving}
              className="text-xs text-center text-secondary hover:text-primary py-1 transition-colors underline underline-offset-2"
            >
              Сохранить и отправить напоминание
            </button>
          </div>
        }
      >
        <div className="space-y-5">
          {/* 1. Client Search Section */}
          <div className="space-y-1.5 relative">
            <label className="block text-xs font-semibold uppercase tracking-wider text-secondary">
              Клиент <span className="text-rose-500">*</span>
            </label>

            {selectedClient ? (
              <div className="flex items-center justify-between p-3 rounded-crm border border-border bg-brand-50/50">
                <div>
                  <div className="text-sm font-semibold text-primary">{selectedClient.name}</div>
                  <div className="text-xs text-secondary">{formatPhone(selectedClient.phone)}</div>
                  {selectedClient.notes && (
                    <div className="text-[11px] text-amber-700 mt-1 bg-amber-50 px-2 py-0.5 rounded border border-amber-200/60 inline-block">
                      Заметка: {selectedClient.notes}
                    </div>
                  )}
                </div>
                <button
                  onClick={() => {
                    setSelectedClient(null);
                    setClientSearch("");
                    setClientHistorySnippet(null);
                  }}
                  className="p-1 text-secondary hover:text-primary rounded"
                  title="Выбрать другого"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="relative">
                <div className="relative">
                  <Search className="w-4 h-4 text-secondary absolute left-3.5 top-3" />
                  <input
                    value={clientSearch}
                    onChange={(e) => setClientSearch(e.target.value)}
                    placeholder="🔍 Найти клиента по имени или телефону..."
                    className="w-full h-10 pl-9 pr-24 bg-surface text-primary text-sm rounded-crm border border-border placeholder:text-secondary/60 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary/20"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewClientModal(true)}
                    className="absolute right-2 top-1.5 px-2 py-1 bg-brand-100 hover:bg-brand-200 text-primary text-xs font-medium rounded-crm transition-colors"
                  >
                    + Новый
                  </button>
                </div>

                {/* Dropdown Results */}
                {showClientDropdown && clientSearchResults.length > 0 && (
                  <div className="absolute top-full left-0 right-0 mt-1 bg-surface rounded-crm border border-border shadow-modal z-20 max-h-56 overflow-y-auto p-1">
                    {clientSearchResults.map((c) => (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() => handleSelectClient(c)}
                        className="w-full flex items-center justify-between p-2 rounded-crm hover:bg-brand-50 text-left transition-colors"
                      >
                        <div>
                          <div className="text-sm font-medium text-primary">{c.name}</div>
                          <div className="text-xs text-secondary">{formatPhone(c.phone)}</div>
                        </div>
                        <div className="text-[11px] text-secondary">
                          {c.lastVisitAt ? `Визит: ${formatRelativeDate(c.lastVisitAt)}` : "Новый клиент"}
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Smart repeat snippet (Section 69) */}
            {selectedClient && clientHistorySnippet && (
              <div className="mt-2 p-2.5 rounded-crm bg-brand-100/60 border border-border flex items-center justify-between text-xs">
                <div>
                  <span className="text-secondary">Последний визит: </span>
                  <span className="font-medium text-primary">
                    {clientHistorySnippet.services.map((s: any) => s.service.name).join(" + ")}
                  </span>
                  <span className="text-secondary ml-1">
                    ({formatRelativeDate(clientHistorySnippet.startAt)})
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleRepeatServices}
                  className="inline-flex items-center gap-1 px-2 py-1 rounded bg-surface hover:bg-brand-50 border border-border text-primary font-medium text-[11px] shadow-2xs"
                >
                  <Repeat className="w-3 h-3 text-secondary" />
                  Повторить услуги
                </button>
              </div>
            )}
          </div>

          {/* 2. Date and Time */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
                Дата <span className="text-rose-500">*</span>
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full h-10 px-3 bg-surface text-primary text-sm rounded-crm border border-border focus:outline-none focus:border-primary"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
                Время <span className="text-rose-500">*</span>
              </label>
              <input
                type="time"
                value={time}
                step="300"
                onChange={(e) => setTime(e.target.value)}
                className="w-full h-10 px-3 bg-surface text-primary text-sm rounded-crm border border-border focus:outline-none focus:border-primary"
              />
            </div>
          </div>

          {/* 3. Barber Select */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
              Барбер <span className="text-rose-500">*</span>
            </label>
            <select
              value={barberId}
              onChange={(e) => setBarberId(e.target.value)}
              className="w-full h-10 px-3 bg-surface text-primary text-sm rounded-crm border border-border focus:outline-none focus:border-primary capitalize"
            >
              {barbers.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name} ({b.role})
                </option>
              ))}
            </select>
          </div>

          {/* 4. Services Selection (Multi-select) */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold uppercase tracking-wider text-secondary">
                Услуги <span className="text-rose-500">*</span>
              </label>
              <span className="text-[11px] text-secondary">
                {selectedServices.length} выбрано
              </span>
            </div>

            <div className="grid grid-cols-1 gap-1.5 max-h-48 overflow-y-auto pr-1">
              {services.map((s) => {
                const isSelected = selectedServices.includes(s.id);
                return (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => toggleService(s.id)}
                    className={`w-full flex items-center justify-between p-2.5 rounded-crm border text-xs text-left transition-colors ${
                      isSelected
                        ? "border-primary bg-primary text-white"
                        : "border-border bg-surface hover:bg-brand-50 text-neutral-800"
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <div
                        className={`w-4 h-4 rounded flex items-center justify-center border ${
                          isSelected
                            ? "bg-white text-primary border-white"
                            : "border-border bg-surface"
                        }`}
                      >
                        {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                      </div>
                      <span className="font-medium">{s.name}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className={isSelected ? "text-neutral-300" : "text-secondary"}>
                        {s.durationMinutes} мин
                      </span>
                      <span className="font-semibold">{formatCurrency(s.price)}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 5. Duration & Price Calculations / Overrides */}
          <div className="grid grid-cols-2 gap-3 p-3 rounded-crm bg-brand-50 border border-border">
            <div>
              <div className="text-[11px] font-semibold text-secondary uppercase mb-1">
                Длительность
              </div>
              <div className="flex items-center gap-1.5">
                <input
                  type="number"
                  min="5"
                  step="5"
                  value={manualDuration !== "" ? manualDuration : autoDuration}
                  onChange={(e) => setManualDuration(e.target.value === "" ? "" : Number(e.target.value))}
                  className="w-16 h-8 px-2 text-sm bg-surface rounded-crm-sm border border-border text-center font-semibold"
                />
                <span className="text-xs text-secondary font-medium">мин</span>
              </div>
            </div>

            <div>
              <div className="text-[11px] font-semibold text-secondary uppercase mb-1">
                Стоимость
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-semibold text-secondary">$</span>
                <input
                  type="number"
                  min="0"
                  step="1"
                  value={manualPrice !== "" ? manualPrice : autoPrice}
                  onChange={(e) => setManualPrice(e.target.value === "" ? "" : Number(e.target.value))}
                  className="w-20 h-8 px-2 text-sm bg-surface rounded-crm-sm border border-border text-center font-semibold"
                />
              </div>
            </div>
          </div>

          {/* 6. Comment */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
              Комментарий
            </label>
            <textarea
              rows={2}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Например: Клиент хочет оставить верх подлиннее..."
              className="w-full p-2.5 bg-surface text-primary text-sm rounded-crm border border-border placeholder:text-secondary/60 focus:outline-none focus:border-primary resize-none"
            />
          </div>
        </div>
      </Drawer>

      {/* Quick New Client Modal (Section 11) */}
      <Modal
        isOpen={showNewClientModal}
        onClose={() => setShowNewClientModal(false)}
        title="Новый клиент"
        description="Создание клиента без перехода на отдельную страницу"
        footer={
          <>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowNewClientModal(false)}
              disabled={creatingClient}
            >
              Отмена
            </Button>
            <Button
              variant="primary"
              size="sm"
              isLoading={creatingClient}
              onClick={handleCreateNewClient}
            >
              Создать клиента
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          {newClientError && (
            <div className="p-2.5 rounded-crm bg-rose-50 border border-rose-200 text-rose-700 text-xs">
              {newClientError}
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
              Имя клиента <span className="text-rose-500">*</span>
            </label>
            <Input
              value={newClientName}
              onChange={(e) => setNewClientName(e.target.value)}
              placeholder="Например: Али Гасанов"
              autoFocus
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
              Телефон <span className="text-rose-500">*</span>
            </label>
            <Input
              value={newClientPhone}
              onChange={(e) => setNewClientPhone(e.target.value)}
              placeholder="+994 50 123 45 67"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
              Заметка (предпочтения)
            </label>
            <textarea
              rows={2}
              value={newClientNote}
              onChange={(e) => setNewClientNote(e.target.value)}
              placeholder="Например: low fade, чай с сахаром"
              className="w-full p-2.5 bg-surface text-primary text-sm rounded-crm border border-border placeholder:text-secondary/60 focus:outline-none focus:border-primary resize-none"
            />
          </div>
        </div>
      </Modal>
    </>
  );
}
