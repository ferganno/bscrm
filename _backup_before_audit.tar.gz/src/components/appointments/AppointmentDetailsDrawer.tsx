"use client";

import React, { useState } from "react";
import { Drawer } from "../ui/Drawer";
import { Button } from "../ui/Button";
import { Badge } from "../ui/Badge";
import { useToast } from "../ui/Toast";
import {
  Calendar,
  Clock,
  User,
  Phone,
  DollarSign,
  Send,
  RotateCcw,
  CheckCircle,
  XCircle,
  AlertTriangle,
  FileText,
  Trash2,
} from "lucide-react";
import {
  formatAppointmentDate,
  formatTimeRange,
  formatPhone,
  formatCurrency,
  APPOINTMENT_STATUS_MAP,
  AppointmentStatusKey,
} from "@/lib/utils";
import { AppointmentItem } from "@/lib/types";

interface AppointmentDetailsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  appointment: AppointmentItem | null;
  onUpdated: () => void;
  onBookAgain: (client: any, barberId: string, serviceIds: string[]) => void;
}

export function AppointmentDetailsDrawer({
  isOpen,
  onClose,
  appointment,
  onUpdated,
  onBookAgain,
}: AppointmentDetailsDrawerProps) {
  const { toast, success, error: toastError } = useToast();
  const [updatingStatus, setUpdatingStatus] = useState(false);
  const [sendingReminder, setSendingReminder] = useState(false);
  const [cancelling, setCancelling] = useState(false);

  if (!appointment) return null;

  const handleStatusChange = async (newStatus: string) => {
    setUpdatingStatus(true);
    try {
      const res = await fetch(`/api/appointments/${appointment.id}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Не удалось изменить статус");
      success(`✓ Статус изменён: ${APPOINTMENT_STATUS_MAP[newStatus as AppointmentStatusKey]?.label}`);
      onUpdated();
    } catch (err: any) {
      toastError(err.message);
    } finally {
      setUpdatingStatus(false);
    }
  };

  const handleSendReminder = async () => {
    setSendingReminder(true);
    try {
      const res = await fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clientId: appointment.client.id,
          appointmentId: appointment.id,
          channel: "whatsapp",
          text: `Здравствуйте, ${appointment.client.name}! Напоминаем о вашей записи ${formatAppointmentDate(appointment.startAt)} в ${formatTimeRange(appointment.startAt, appointment.endAt)} к барберу ${appointment.barber.name}.`,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Ошибка отправки");
      if (data.whatsappUrl) {
        window.open(data.whatsappUrl, "_blank");
        success("✓ Открыт WhatsApp с текстом напоминания для клиента");
      } else {
        success("✓ Сообщение отправлено клиенту");
      }
      onUpdated();
    } catch (err: any) {
      toastError(err.message);
    } finally {
      setSendingReminder(false);
    }
  };

  const handleCancelAppointment = async () => {
    if (!confirm("Вы действительно хотите отменить эту запись?")) return;
    setCancelling(true);
    try {
      const res = await fetch(`/api/appointments/${appointment.id}`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("Не удалось отменить запись");
      success("✓ Запись отменена");
      onUpdated();
      onClose();
    } catch (err: any) {
      toastError(err.message);
    } finally {
      setCancelling(false);
    }
  };

  const statusConfig = APPOINTMENT_STATUS_MAP[appointment.status as AppointmentStatusKey] || APPOINTMENT_STATUS_MAP.pending;

  return (
    <Drawer
      isOpen={isOpen}
      onClose={onClose}
      title="Детали записи"
      description={`#${appointment.id.slice(-6)}`}
      footer={
        <div className="flex items-center justify-between gap-2">
          {appointment.status !== "cancelled" ? (
            <Button
              variant="outline"
              size="sm"
              className="text-rose-600 hover:bg-rose-50 border-rose-200"
              onClick={handleCancelAppointment}
              isLoading={cancelling}
            >
              <Trash2 className="w-3.5 h-3.5 mr-1" />
              Отменить
            </Button>
          ) : (
            <span className="text-xs text-secondary italic">Запись отменена</span>
          )}

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleSendReminder}
              isLoading={sendingReminder}
              title="Отправить напоминание в WhatsApp"
            >
              <Send className="w-3.5 h-3.5 mr-1.5" />
              Напоминание
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={() => {
                const sIds = appointment.services.map((s) => s.serviceId);
                onBookAgain(appointment.client, appointment.barberId, sIds);
                onClose();
              }}
            >
              <RotateCcw className="w-3.5 h-3.5 mr-1.5" />
              Записать снова
            </Button>
          </div>
        </div>
      }
    >
      <div className="space-y-5">
        {/* Status banner and quick selector */}
        <div className="p-3.5 rounded-crm bg-brand-50 border border-border flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className={`w-2.5 h-2.5 rounded-full ${statusConfig.dot}`} />
            <span className="text-sm font-semibold text-primary">{statusConfig.label}</span>
          </div>

          {/* Quick status dropdown */}
          <div className="flex items-center gap-1">
            <select
              value={appointment.status}
              disabled={updatingStatus}
              onChange={(e) => handleStatusChange(e.target.value)}
              className="h-8 px-2.5 text-xs font-medium rounded-crm bg-surface border border-border focus:outline-none focus:border-primary cursor-pointer"
            >
              <option value="pending">Ожидает</option>
              <option value="completed">Пришёл / Завершён</option>
              <option value="no_show">Не пришёл</option>
              <option value="cancelled">Отменён</option>
            </select>
          </div>
        </div>

        {/* If No-Show banner (Section 20) */}
        {appointment.status === "no_show" && (
          <div className="p-3 rounded-crm bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-center justify-between">
            <span>Клиент не пришёл на запись.</span>
            <Button
              variant="outline"
              size="sm"
              className="h-7 text-xs bg-surface border-rose-300"
              onClick={() => {
                const sIds = appointment.services.map((s) => s.serviceId);
                onBookAgain(appointment.client, appointment.barberId, sIds);
                onClose();
              }}
            >
              Записать снова
            </Button>
          </div>
        )}

        {/* Client Card */}
        <div className="p-4 rounded-crm border border-border bg-surface space-y-2">
          <div className="flex items-center justify-between">
            <div className="text-xs font-semibold uppercase tracking-wider text-secondary">
              Клиент
            </div>
            <a
              href={`tel:${appointment.client.phone}`}
              className="text-xs text-primary font-medium flex items-center gap-1 hover:underline"
            >
              <Phone className="w-3 h-3 text-secondary" />
              {formatPhone(appointment.client.phone)}
            </a>
          </div>

          <div className="text-base font-bold text-primary">
            {appointment.client.name}
          </div>

          {appointment.client.notes && (
            <div className="text-xs text-secondary bg-brand-50 p-2 rounded-crm-sm">
              <span className="font-semibold text-primary">Заметка: </span>
              {appointment.client.notes}
            </div>
          )}
        </div>

        {/* Date, Time & Barber */}
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 rounded-crm border border-border bg-surface">
            <div className="text-[11px] font-semibold text-secondary uppercase mb-1">
              Дата и время
            </div>
            <div className="text-xs font-medium text-primary">
              {formatAppointmentDate(appointment.startAt)}
            </div>
            <div className="text-sm font-bold text-primary mt-0.5">
              {formatTimeRange(appointment.startAt, appointment.endAt)}
            </div>
          </div>

          <div className="p-3 rounded-crm border border-border bg-surface">
            <div className="text-[11px] font-semibold text-secondary uppercase mb-1">
              Барбер
            </div>
            <div className="flex items-center gap-2 mt-1">
              <span
                className="w-3 h-3 rounded-full shrink-0"
                style={{ backgroundColor: appointment.barber.color }}
              />
              <span className="text-sm font-bold text-primary">
                {appointment.barber.name}
              </span>
            </div>
          </div>
        </div>

        {/* Services & Price */}
        <div className="p-4 rounded-crm border border-border bg-surface space-y-3">
          <div className="text-xs font-semibold uppercase tracking-wider text-secondary">
            Услуги
          </div>
          <div className="divide-y divide-border/60">
            {appointment.services.map((item) => (
              <div key={item.id} className="py-2 flex items-center justify-between text-xs">
                <div>
                  <span className="font-medium text-primary">{item.service.name}</span>
                  <span className="text-secondary ml-2">{item.durationMinutes} мин</span>
                </div>
                <span className="font-semibold text-primary">{formatCurrency(item.price)}</span>
              </div>
            ))}
          </div>

          <div className="pt-2 border-t border-border flex items-center justify-between">
            <span className="text-xs font-semibold text-primary uppercase">Итого к оплате</span>
            <span className="text-base font-bold text-primary">{formatCurrency(appointment.totalPrice)}</span>
          </div>
        </div>

        {/* Comment */}
        {appointment.comment && (
          <div className="p-3 rounded-crm border border-border bg-surface">
            <div className="text-[11px] font-semibold text-secondary uppercase mb-1">
              Комментарий
            </div>
            <p className="text-xs text-primary leading-relaxed">{appointment.comment}</p>
          </div>
        )}
      </div>
    </Drawer>
  );
}
