"use client";

import React, { useState, useEffect } from "react";
import { Settings as SettingsIcon, Building, Clock, Users, Shield, Save, Trash2, AlertTriangle } from "lucide-react";
import { Button } from "../ui/Button";
import { Input } from "../ui/Input";
import { Modal } from "../ui/Modal";
import { useToast } from "../ui/Toast";
import { SessionUser } from "@/lib/types";

interface SettingsViewProps {
  currentUser: SessionUser | null;
}

const TIMEZONES = [
  { value: "Asia/Baku", label: "Asia/Baku (GMT+4) — Баку" },
  { value: "Europe/Moscow", label: "Europe/Moscow (GMT+3) — Москва" },
  { value: "Asia/Tbilisi", label: "Asia/Tbilisi (GMT+4) — Тбилиси" },
  { value: "Asia/Dubai", label: "Asia/Dubai (GMT+4) — Дубай" },
  { value: "Asia/Almaty", label: "Asia/Almaty (GMT+5) — Алматы" },
  { value: "Asia/Tashkent", label: "Asia/Tashkent (GMT+5) — Ташкент" },
  { value: "Europe/Istanbul", label: "Europe/Istanbul (GMT+3) — Стамбул" },
  { value: "UTC", label: "UTC" },
];

export function SettingsView({ currentUser }: SettingsViewProps) {
  const { toast, success, error: toastError } = useToast();
  const [shop, setShop] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Form
  const [name, setName] = useState("");
  const [address, setAddress] = useState("");
  const [timezone, setTimezone] = useState("Asia/Baku");

  // Data management modals
  const [showClearAppsModal, setShowClearAppsModal] = useState(false);
  const [clearingApps, setClearingApps] = useState(false);

  const [showClearMsgsModal, setShowClearMsgsModal] = useState(false);
  const [clearingMsgs, setClearingMsgs] = useState(false);

  const canEdit = currentUser?.role === "owner" || currentUser?.role === "admin";

  const loadSettings = () => {
    setLoading(true);
    fetch("/api/settings")
      .then((r) => r.json())
      .then((d) => {
        if (d.shop) {
          setShop(d.shop);
          setName(d.shop.name);
          setAddress(d.shop.address);
          setTimezone(d.shop.timezone || "Asia/Baku");
        }
      })
      .catch((err) => console.error("Error loading settings:", err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadSettings();
  }, []);

  const handleSave = async () => {
    if (!name.trim()) {
      toastError("Укажите название барбершопа");
      return;
    }
    setSaving(true);
    try {
      const res = await fetch("/api/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, address, timezone }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Не удалось сохранить настройки");
      success("✓ Настройки барбершопа сохранены");
      loadSettings();
    } catch (err: any) {
      toastError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleClearAppointments = async () => {
    setClearingApps(true);
    try {
      const res = await fetch("/api/settings/clear-appointments", {
        method: "POST",
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Не удалось удалить записи");
      success(`✓ Все записи успешно удалены (${data.count} шт.)`);
      setShowClearAppsModal(false);
    } catch (err: any) {
      toastError(err.message);
    } finally {
      setClearingApps(false);
    }
  };

  const handleClearMessages = async () => {
    setClearingMsgs(true);
    try {
      const res = await fetch("/api/settings/clear-messages", {
        method: "POST",
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Не удалось удалить сообщения");
      success(`✓ Все сообщения удалены (${data.count} шт.)`);
      setShowClearMsgsModal(false);
    } catch (err: any) {
      toastError(err.message);
    } finally {
      setClearingMsgs(false);
    }
  };

  if (loading) {
    return <div className="py-12 text-center text-xs text-secondary">Загрузка настроек...</div>;
  }

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-primary">Настройки</h1>
        <p className="text-xs text-secondary mt-0.5">
          Параметры заведения, часовой пояс, состав команды и управление данными
        </p>
      </div>

      {/* Shop Information Card */}
      <div className="p-6 rounded-crm bg-surface border border-border shadow-subtle space-y-4">
        <div className="flex items-center gap-2 pb-3 border-b border-border">
          <Building className="w-4 h-4 text-secondary" />
          <h2 className="text-sm font-bold text-primary uppercase tracking-wider">
            Информация о барбершопе
          </h2>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
              Название барбершопа <span className="text-rose-500">*</span>
            </label>
            <Input
              value={name}
              disabled={!canEdit}
              onChange={(e) => setName(e.target.value)}
              placeholder="Barber Studio"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
              Адрес
            </label>
            <Input
              value={address}
              disabled={!canEdit}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="ул. Низами, 42, Баку"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
              Часовой пояс (Timezone)
            </label>
            <select
              value={timezone}
              disabled={!canEdit}
              onChange={(e) => setTimezone(e.target.value)}
              className="w-full h-10 px-3 bg-surface text-primary text-sm rounded-crm border border-border focus:outline-none focus:border-primary"
            >
              {TIMEZONES.map((tz) => (
                <option key={tz.value} value={tz.value}>
                  {tz.label}
                </option>
              ))}
            </select>
            <p className="text-[11px] text-secondary mt-1">
              Все записи сохраняются в UTC и автоматически отображаются в указанном часовом поясе.
            </p>
          </div>

          {canEdit && (
            <div className="pt-2">
              <Button
                variant="primary"
                size="sm"
                isLoading={saving}
                onClick={handleSave}
                className="text-xs font-semibold"
              >
                <Save className="w-3.5 h-3.5 mr-1.5" />
                Сохранить изменения
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Team Members */}
      {shop?.users && (
        <div className="p-6 rounded-crm bg-surface border border-border shadow-subtle space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-border">
            <Users className="w-4 h-4 text-secondary" />
            <h2 className="text-sm font-bold text-primary uppercase tracking-wider">
              Команда барбершопа ({shop.users.length})
            </h2>
          </div>

          <div className="divide-y divide-border/60 text-xs">
            {shop.users.map((u: any) => (
              <div key={u.id} className="py-2.5 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <span
                    className="w-3 h-3 rounded-full shrink-0"
                    style={{ backgroundColor: u.color }}
                  />
                  <div>
                    <span className="font-semibold text-primary">{u.name}</span>
                    <span className="text-secondary ml-2">({u.email})</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="capitalize px-2 py-0.5 rounded text-[10px] font-semibold bg-brand-100 text-primary">
                    {u.role}
                  </span>
                  <span
                    className={`text-[10px] font-semibold ${
                      u.isActive ? "text-emerald-700" : "text-zinc-400"
                    }`}
                  >
                    {u.isActive ? "Активен" : "Отключен"}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Data Management Section (Очистка записей) */}
      {canEdit && (
        <div className="p-6 rounded-crm bg-surface border border-rose-200 shadow-subtle space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-rose-100">
            <AlertTriangle className="w-4 h-4 text-rose-600" />
            <h2 className="text-sm font-bold text-rose-900 uppercase tracking-wider">
              Управление данными и сброс
            </h2>
          </div>

          <div className="space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between p-3.5 rounded-crm bg-rose-50/50 border border-rose-200/60 gap-3">
              <div>
                <h4 className="text-xs font-bold text-rose-900">Удалить все записи</h4>
                <p className="text-[11px] text-rose-700 mt-0.5">
                  Очищает всю сетку календаря и бронирования. Клиенты, барберы и услуги остаются нетронутыми.
                </p>
              </div>
              <Button
                variant="danger"
                size="sm"
                onClick={() => setShowClearAppsModal(true)}
                className="text-xs shrink-0 whitespace-nowrap"
              >
                <Trash2 className="w-3.5 h-3.5 mr-1" />
                Убрать все записи
              </Button>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between p-3.5 rounded-crm bg-brand-50 border border-border gap-3">
              <div>
                <h4 className="text-xs font-bold text-primary">Очистить журнал сообщений</h4>
                <p className="text-[11px] text-secondary mt-0.5">
                  Удаляет историю отправленных уведомлений (WhatsApp, SMS, Telegram).
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowClearMsgsModal(true)}
                className="text-xs shrink-0 whitespace-nowrap border-border"
              >
                <Trash2 className="w-3.5 h-3.5 mr-1 text-secondary" />
                Очистить сообщения
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal for Clearing Appointments */}
      <Modal
        isOpen={showClearAppsModal}
        onClose={() => setShowClearAppsModal(false)}
        title="Удалить все записи в календаре?"
        description="Это действие полностью очистит расписание барбершопа."
        footer={
          <>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowClearAppsModal(false)}
              disabled={clearingApps}
            >
              Отмена
            </Button>
            <Button
              variant="danger"
              size="sm"
              isLoading={clearingApps}
              onClick={handleClearAppointments}
            >
              Да, удалить все записи
            </Button>
          </>
        }
      >
        <div className="text-xs text-secondary leading-relaxed">
          Вы уверены? Будут удалены все записи из календаря. Клиентская база, услуги и графики барберов сохранятся.
        </div>
      </Modal>

      {/* Confirmation Modal for Clearing Messages */}
      <Modal
        isOpen={showClearMsgsModal}
        onClose={() => setShowClearMsgsModal(false)}
        title="Очистить журнал сообщений?"
        description="История всех отправленных уведомлений будет удалена."
        footer={
          <>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowClearMsgsModal(false)}
              disabled={clearingMsgs}
            >
              Отмена
            </Button>
            <Button
              variant="danger"
              size="sm"
              isLoading={clearingMsgs}
              onClick={handleClearMessages}
            >
              Очистить журнал
            </Button>
          </>
        }
      >
        <div className="text-xs text-secondary leading-relaxed">
          Будет удален весь журнал отправленных уведомлений. Шаблоны и настройки останутся без изменений.
        </div>
      </Modal>
    </div>
  );
}
