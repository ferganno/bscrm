"use client";

import React, { useState, useEffect } from "react";
import { Scissors, Plus, Clock, Phone, Mail, Edit3, CheckCircle, XCircle } from "lucide-react";
import { Button } from "../ui/Button";
import { Input } from "../ui/Input";
import { Modal } from "../ui/Modal";
import { useToast } from "../ui/Toast";
import { BarberWithSchedule, SessionUser } from "@/lib/types";
import { formatPhone } from "@/lib/utils";

const DAYS_OF_WEEK = [
  { day: 1, name: "Понедельник", short: "Пн" },
  { day: 2, name: "Вторник", short: "Вт" },
  { day: 3, name: "Среда", short: "Ср" },
  { day: 4, name: "Четверг", short: "Чт" },
  { day: 5, name: "Пятница", short: "Пт" },
  { day: 6, name: "Суббота", short: "Сб" },
  { day: 0, name: "Воскресенье", short: "Вс" },
];

const PRESET_COLORS = [
  "#2563EB", // Blue
  "#0D9488", // Teal
  "#D97706", // Amber
  "#7C3AED", // Violet
  "#DC2626", // Red
  "#059669", // Emerald
  "#EA580C", // Orange
  "#475569", // Slate
];

interface BarbersListProps {
  currentUser: SessionUser | null;
}

export function BarbersList({ currentUser }: BarbersListProps) {
  const { toast, success, error: toastError } = useToast();
  const [barbers, setBarbers] = useState<BarberWithSchedule[]>([]);
  const [loading, setLoading] = useState(true);

  // Edit / Add modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBarber, setEditingBarber] = useState<BarberWithSchedule | null>(null);

  // Form state
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [color, setColor] = useState("#2563EB");
  const [role, setRole] = useState("barber");
  const [isActive, setIsActive] = useState(true);
  const [schedules, setSchedules] = useState<any[]>([]);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const canManage = currentUser?.role === "owner" || currentUser?.role === "admin";

  const loadBarbers = () => {
    setLoading(true);
    fetch("/api/barbers")
      .then((r) => r.json())
      .then((d) => setBarbers(d.barbers || []))
      .catch((err) => console.error("Error loading barbers:", err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadBarbers();
  }, []);

  const openAddModal = () => {
    setEditingBarber(null);
    setName("");
    setPhone("+994 ");
    setEmail("");
    setColor(PRESET_COLORS[Math.floor(Math.random() * PRESET_COLORS.length)]);
    setRole("barber");
    setIsActive(true);

    // Default schedules: Mon-Sat 10:00-20:00, Sun off
    setSchedules(
      DAYS_OF_WEEK.map((d) => ({
        dayOfWeek: d.day,
        startTime: "10:00",
        endTime: "20:00",
        isWorking: d.day !== 0,
      }))
    );
    setFormError(null);
    setIsModalOpen(true);
  };

  const openEditModal = (barber: BarberWithSchedule) => {
    setEditingBarber(barber);
    setName(barber.name);
    setPhone(barber.phone || "");
    setEmail(barber.email || "");
    setColor(barber.color);
    setRole(barber.role);
    setIsActive(barber.isActive);

    // Populate schedules map
    const schList = DAYS_OF_WEEK.map((d) => {
      const existing = barber.schedules.find((s) => s.dayOfWeek === d.day);
      return {
        dayOfWeek: d.day,
        startTime: existing?.startTime || "10:00",
        endTime: existing?.endTime || "20:00",
        isWorking: existing ? existing.isWorking : d.day !== 0,
      };
    });
    setSchedules(schList);
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleSave = async () => {
    if (!name.trim()) {
      setFormError("Укажите имя барбера");
      return;
    }

    setSaving(true);
    setFormError(null);

    try {
      const url = editingBarber ? `/api/barbers/${editingBarber.id}` : "/api/barbers";
      const method = editingBarber ? "PATCH" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          phone,
          email,
          color,
          role,
          isActive,
          schedules,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Не удалось сохранить");

      success(editingBarber ? "✓ Данные барбера обновлены" : "✓ Барбер добавлен в команду");
      setIsModalOpen(false);
      loadBarbers();
    } catch (err: any) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  };

  // Helper to format working days summary (e.g. "Пн–Сб 10:00–20:00")
  const formatScheduleSummary = (barber: BarberWithSchedule) => {
    const workingDays = barber.schedules.filter((s) => s.isWorking);
    if (workingDays.length === 0) return "График не настроен";
    const sample = workingDays[0];
    const workingShorts = DAYS_OF_WEEK.filter((d) =>
      workingDays.some((w) => w.dayOfWeek === d.day)
    ).map((d) => d.short);

    if (workingShorts.length === 6 && !workingDays.some((w) => w.dayOfWeek === 0)) {
      return `Пн–Сб ${sample.startTime}–${sample.endTime}`;
    }
    if (workingShorts.length === 7) {
      return `Каждый день ${sample.startTime}–${sample.endTime}`;
    }
    return `${workingShorts.join(", ")} ${sample.startTime}–${sample.endTime}`;
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-primary">Барберы</h1>
          <p className="text-xs text-secondary mt-0.5">
            Команда мастеров, персональные графики работы и цветовая индикация
          </p>
        </div>

        {canManage && (
          <Button
            variant="primary"
            size="sm"
            onClick={openAddModal}
            className="h-9 px-3.5 text-xs font-semibold"
          >
            <Plus className="w-4 h-4 mr-1.5 stroke-[2.5]" />
            Добавить барбера
          </Button>
        )}
      </div>

      {/* Barbers Grid */}
      {loading ? (
        <div className="py-12 text-center text-xs text-secondary">
          Загрузка списка мастеров...
        </div>
      ) : barbers.length === 0 ? (
        <div className="p-12 text-center bg-surface rounded-crm border border-border space-y-3">
          <div className="w-12 h-12 rounded-full bg-brand-100 flex items-center justify-center mx-auto text-secondary">
            <Scissors className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-primary">Добавьте первого барбера</h3>
            <p className="text-xs text-secondary mt-1">
              Настройте расписание для отображения в сетке календаря.
            </p>
          </div>
          {canManage && (
            <Button variant="outline" size="sm" onClick={openAddModal} className="text-xs mt-2">
              Добавить барбера
            </Button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {barbers.map((barber) => (
            <div
              key={barber.id}
              className="p-5 rounded-crm bg-surface border border-border shadow-subtle flex flex-col justify-between space-y-4 hover:shadow-dropdown transition-all"
            >
              <div>
                {/* Header with color dot and status */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span
                      className="w-3.5 h-3.5 rounded-full shrink-0 shadow-2xs"
                      style={{ backgroundColor: barber.color }}
                    />
                    <h3 className="text-base font-bold text-primary">{barber.name}</h3>
                  </div>

                  <span
                    className={`text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full border ${
                      barber.isActive
                        ? "bg-emerald-50 text-emerald-700 border-emerald-200"
                        : "bg-zinc-100 text-zinc-500 border-zinc-200"
                    }`}
                  >
                    {barber.isActive ? "Активен" : "Неактивен"}
                  </span>
                </div>

                <div className="text-xs text-secondary capitalize mt-1 ml-6">
                  {barber.role}
                </div>

                {/* Schedule info */}
                <div className="mt-4 pt-3 border-t border-border/70 space-y-2 text-xs">
                  <div className="flex items-center gap-2 text-neutral-700">
                    <Clock className="w-3.5 h-3.5 text-secondary shrink-0" />
                    <span>{formatScheduleSummary(barber)}</span>
                  </div>

                  {barber.phone && (
                    <div className="flex items-center gap-2 text-neutral-700">
                      <Phone className="w-3.5 h-3.5 text-secondary shrink-0" />
                      <span>{formatPhone(barber.phone)}</span>
                    </div>
                  )}
                </div>
              </div>

              {canManage && (
                <div className="pt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openEditModal(barber)}
                    className="w-full text-xs font-semibold"
                  >
                    <Edit3 className="w-3.5 h-3.5 mr-1.5" />
                    Изменить
                  </Button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Edit / Add Barber Modal (Section 27) */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingBarber ? "Изменить барбера" : "Новый барбер"}
        description="Данные сотрудника и рабочий график"
        maxWidthClass="max-w-lg"
        footer={
          <>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsModalOpen(false)}
              disabled={saving}
            >
              Отмена
            </Button>
            <Button variant="primary" size="sm" isLoading={saving} onClick={handleSave}>
              Сохранить
            </Button>
          </>
        }
      >
        <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-1">
          {formError && (
            <div className="p-2.5 rounded-crm bg-rose-50 border border-rose-200 text-rose-700 text-xs">
              {formError}
            </div>
          )}

          {/* Basic Fields */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
                Имя <span className="text-rose-500">*</span>
              </label>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Руслан"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
                Телефон
              </label>
              <Input
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+994 50 123 45 67"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
                Роль
              </label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="w-full h-10 px-3 bg-surface text-primary text-sm rounded-crm border border-border focus:outline-none focus:border-primary"
              >
                <option value="barber">Barber (Мастер)</option>
                <option value="admin">Admin (Администратор)</option>
                <option value="owner">Owner (Владелец)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
                Цвет в календаре
              </label>
              <div className="flex items-center gap-1.5 pt-1">
                {PRESET_COLORS.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setColor(c)}
                    className={`w-6 h-6 rounded-full transition-transform ${
                      color === c ? "scale-125 ring-2 ring-primary ring-offset-2" : "hover:scale-110"
                    }`}
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
            </div>
          </div>

          <div>
            <label className="flex items-center gap-2 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={isActive}
                onChange={(e) => setIsActive(e.target.checked)}
                className="w-4 h-4 text-primary rounded"
              />
              <span className="text-xs font-medium text-primary">
                Сотрудник активен (отображается при создании записей)
              </span>
            </label>
          </div>

          {/* Schedule Configuration (Section 27) */}
          <div className="pt-2 border-t border-border">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-secondary mb-2">
              Рабочий график (по дням недели)
            </h4>

            <div className="space-y-2">
              {DAYS_OF_WEEK.map((d) => {
                const item = schedules.find((s) => s.dayOfWeek === d.day) || {
                  dayOfWeek: d.day,
                  startTime: "10:00",
                  endTime: "20:00",
                  isWorking: d.day !== 0,
                };

                const updateDay = (field: string, val: any) => {
                  setSchedules((prev) =>
                    prev.map((s) => (s.dayOfWeek === d.day ? { ...s, [field]: val } : s))
                  );
                };

                return (
                  <div
                    key={d.day}
                    className="flex items-center justify-between p-2 rounded bg-brand-50 text-xs"
                  >
                    <div className="w-28 font-medium text-primary">{d.name}</div>

                    <div className="flex items-center gap-2">
                      <label className="flex items-center gap-1.5 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={item.isWorking}
                          onChange={(e) => updateDay("isWorking", e.target.checked)}
                          className="w-3.5 h-3.5"
                        />
                        <span className="text-[11px] text-secondary">
                          {item.isWorking ? "Работает" : "Выходной"}
                        </span>
                      </label>

                      {item.isWorking && (
                        <div className="flex items-center gap-1 ml-2">
                          <input
                            type="time"
                            value={item.startTime}
                            onChange={(e) => updateDay("startTime", e.target.value)}
                            className="h-7 px-1 bg-surface border border-border rounded text-[11px]"
                          />
                          <span className="text-secondary">—</span>
                          <input
                            type="time"
                            value={item.endTime}
                            onChange={(e) => updateDay("endTime", e.target.value)}
                            className="h-7 px-1 bg-surface border border-border rounded text-[11px]"
                          />
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
}
