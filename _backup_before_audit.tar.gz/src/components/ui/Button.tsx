import React, { forwardRef } from "react";
import { cn } from "@/lib/utils";
import { Loader2 } from "lucide-react";

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "outline" | "ghost" | "danger";
  size?: "sm" | "md" | "lg" | "icon";
  isLoading?: boolean;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "primary", size = "md", isLoading, children, disabled, ...props }, ref) => {
    return (
      <button
        ref={ref}
        disabled={disabled || isLoading}
        className={cn(
          "inline-flex items-center justify-center font-medium transition-colors select-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/20 disabled:pointer-events-none disabled:opacity-50 active:scale-[0.98]",
          // Variants
          variant === "primary" && "bg-primary text-white hover:bg-neutral-800 shadow-subtle",
          variant === "secondary" && "bg-brand-100 text-primary hover:bg-brand-200 border border-transparent",
          variant === "outline" && "bg-surface text-primary border border-border hover:bg-brand-50 shadow-subtle",
          variant === "ghost" && "bg-transparent text-primary hover:bg-brand-100",
          variant === "danger" && "bg-rose-600 text-white hover:bg-rose-700 shadow-subtle",
          // Sizes
          size === "sm" && "h-8 px-3 text-xs rounded-crm-sm gap-1.5",
          size === "md" && "h-10 px-4 text-sm rounded-crm gap-2",
          size === "lg" && "h-11 px-5 text-base rounded-crm gap-2",
          size === "icon" && "h-9 w-9 p-0 rounded-crm",
          className
        )}
        {...props}
      >
        {isLoading && <Loader2 className="w-4 h-4 animate-spin shrink-0" />}
        {children}
      </button>
    );
  }
);

Button.displayName = "Button";
