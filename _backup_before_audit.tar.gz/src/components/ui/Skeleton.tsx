import React from "react";
import { cn } from "@/lib/utils";

export function Skeleton({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("animate-pulse rounded-crm bg-brand-200/60", className)}
      {...props}
    />
  );
}

export function CalendarSkeleton() {
  return (
    <div className="space-y-4 w-full">
      <div className="flex items-center justify-between pb-3">
        <Skeleton className="h-9 w-48" />
        <div className="flex gap-2">
          <Skeleton className="h-9 w-24" />
          <Skeleton className="h-9 w-24" />
        </div>
      </div>
      <div className="grid grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="space-y-3">
            <Skeleton className="h-12 w-full rounded-crm" />
            <Skeleton className="h-28 w-full rounded-crm" />
            <Skeleton className="h-20 w-full rounded-crm" />
            <Skeleton className="h-32 w-full rounded-crm" />
          </div>
        ))}
      </div>
    </div>
  );
}
