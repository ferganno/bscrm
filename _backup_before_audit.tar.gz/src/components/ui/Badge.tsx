import React from "react";
import { cn } from "@/lib/utils";

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: "default" | "success" | "warning" | "danger" | "outline";
}

export function Badge({ className, variant = "default", children, ...props }: BadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium border",
        variant === "default" && "bg-brand-100 text-brand-800 border-border",
        variant === "success" && "bg-emerald-50 text-emerald-700 border-emerald-200",
        variant === "warning" && "bg-amber-50 text-amber-700 border-amber-200",
        variant === "danger" && "bg-rose-50 text-rose-700 border-rose-200",
        variant === "outline" && "bg-transparent text-secondary border-border",
        className
      )}
      {...props}
    >
      {children}
    </span>
  );
}
