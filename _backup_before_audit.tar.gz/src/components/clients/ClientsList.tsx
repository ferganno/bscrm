"use client";

import React, { useState, useEffect } from "react";
import {
  Users,
  Search,
  Plus,
  Phone,
  Clock,
  Calendar,
  ChevronRight,
  Filter,
} from "lucide-react";
import { Button } from "../ui/Button";
import { Input } from "../ui/Input";
import { Modal } from "../ui/Modal";
import { useToast } from "../ui/Toast";
import { ClientListItem, SessionUser } from "@/lib/types";
import { formatPhone, formatRelativeDate } from "@/lib/utils";
import { ClientDetailsDrawer } from "./ClientDetailsDrawer";

interface ClientsListProps {
  currentUser: SessionUser | null;
  onBookAgain: (client: any, barberId?: string, serviceIds?: string[]) => void;
  onOpenMessageModal: (client: any) => void;
}

export function ClientsList({
  currentUser,
  onBookAgain,
  onOpenMessageModal,
}: ClientsListProps) {
  const { toast, success, error: toastError } = useToast();
  const [clients, setClients] = useState<ClientListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "inactive">("all");

  // Selected client for Drawer
  const [selectedClientId, setSelectedClientId] = useState<string | null>(null);

  // New client modal
  const [showAddModal, setShowAddModal] = useState(false);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("+994 ");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const loadClients = () => {
    setLoading(true);
    const url = `/api/clients?search=${encodeURIComponent(search)}&filter=${filter}`;
    fetch(url)
      .then((r) => r.json())
      .then((d) => {
        setClients(d.clients || []);
      })
      .catch((err) => console.error("Error loading clients:", err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      loadClients();
    }, 250);
    return () => clearTimeout(timer);
  }, [search, filter]);

  const handleCreateClient = async () => {
    if (!name.trim() || !phone.trim()) {
      setFormError("Заполните имя и номер телефона");
      return;
    }
    setSaving(true);
    setFormError(null);

    try {
      const res = await fetch("/api/clients", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, phone, notes }),
      });

      const data = await res.json();
      if (!res.ok) {
        if (data.error === "duplicate") {
          setFormError(data.message);
          return;
        }
        throw new Error(data.error || "Ошибка при создании клиента");
      }

      success("✓ Клиент создан");
      setShowAddModal(false);
      setName("");
      setPhone("+994 ");
      setNotes("");
      loadClients();
      setSelectedClientId(data.client.id);
    } catch (err: any) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header and Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-primary">Клиенты</h1>
          <p className="text-xs text-secondary mt-0.5">
            База клиентов, история посещений и персональные заметки
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={() => setShowAddModal(true)}
          className="h-9 px-3.5 text-xs font-semibold"
        >
          <Plus className="w-4 h-4 mr-1.5 stroke-[2.5]" />
          Новый клиент
        </Button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center gap-2.5">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-secondary absolute left-3 top-3" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="🔍 Поиск по имени или телефону..."
            className="w-full h-10 pl-9 pr-3 bg-surface text-primary text-sm rounded-crm border border-border placeholder:text-secondary/60 focus:outline-none focus:border-primary"
          />
        </div>

        {/* Filter buttons */}
        <div className="flex items-center p-0.5 bg-brand-100 rounded-crm text-xs font-medium self-start sm:self-auto">
          <button
            onClick={() => setFilter("all")}
            className={`px-3 py-1.5 rounded-crm-sm transition-all ${
              filter === "all"
                ? "bg-surface text-primary shadow-subtle font-semibold"
                : "text-secondary hover:text-primary"
            }`}
          >
            Все клиенты
          </button>
          <button
            onClick={() => setFilter("inactive")}
            className={`px-3 py-1.5 rounded-crm-sm transition-all ${
              filter === "inactive"
                ? "bg-surface text-primary shadow-subtle font-semibold"
                : "text-secondary hover:text-primary"
            }`}
            title="Клиенты, которые не были более 30 дней"
          >
            Давно не был (&gt; 30 дней)
          </button>
        </div>
      </div>

      {/* Content: Table for Desktop, Cards for Mobile */}
      {loading ? (
        <div className="py-12 text-center text-xs text-secondary">
          Загрузка клиентов...
        </div>
      ) : clients.length === 0 ? (
        /* Empty state (Section 40) */
        <div className="p-12 text-center bg-surface rounded-crm border border-border space-y-3">
          <div className="w-12 h-12 rounded-full bg-brand-100 flex items-center justify-center mx-auto text-secondary">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-primary">Пока нет клиентов</h3>
            <p className="text-xs text-secondary mt-1">
              {search || filter === "inactive"
                ? "По данному фильтру клиенты не найдены."
                : "Создайте первого клиента при добавлении записи."}
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowAddModal(true)}
            className="text-xs mt-2"
          >
            Создать клиента
          </Button>
        </div>
      ) : (
        <>
          {/* Desktop Table */}
          <div className="hidden md:block bg-surface rounded-crm border border-border shadow-subtle overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-brand-50 border-b border-border text-secondary font-semibold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-3 px-4">Клиент</th>
                  <th className="py-3 px-4">Телефон</th>
                  <th className="py-3 px-4 text-center">Визитов</th>
                  <th className="py-3 px-4">Последний визит</th>
                  <th className="py-3 px-4 text-right">Действие</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/60">
                {clients.map((c) => (
                  <tr
                    key={c.id}
                    onClick={() => setSelectedClientId(c.id)}
                    className="hover:bg-brand-50/60 cursor-pointer transition-colors group"
                  >
                    <td className="py-3 px-4">
                      <div className="font-semibold text-primary text-sm group-hover:text-black">
                        {c.name}
                      </div>
                      {c.notes && (
                        <div className="text-[11px] text-secondary truncate max-w-xs mt-0.5">
                          {c.notes}
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4 font-mono text-secondary">
                      {formatPhone(c.phone)}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className="inline-block px-2 py-0.5 rounded-full bg-brand-100 font-semibold text-primary">
                        {c.visitCount}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-secondary">
                      {formatRelativeDate(c.lastVisitAt)}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <ChevronRight className="w-4 h-4 text-secondary group-hover:text-primary inline-block transition-transform group-hover:translate-x-0.5" />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile Cards */}
          <div className="grid grid-cols-1 gap-2.5 md:hidden">
            {clients.map((c) => (
              <div
                key={c.id}
                onClick={() => setSelectedClientId(c.id)}
                className="p-3.5 bg-surface rounded-crm border border-border shadow-subtle flex items-center justify-between cursor-pointer active:bg-brand-50"
              >
                <div>
                  <div className="text-sm font-bold text-primary">{c.name}</div>
                  <div className="text-xs text-secondary mt-0.5">{formatPhone(c.phone)}</div>
                  <div className="flex items-center gap-2 mt-1.5 text-[11px] text-secondary">
                    <span>Визитов: {c.visitCount}</span>
                    <span>•</span>
                    <span>{formatRelativeDate(c.lastVisitAt)}</span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-secondary shrink-0" />
              </div>
            ))}
          </div>
        </>
      )}

      {/* Client Details Drawer */}
      <ClientDetailsDrawer
        isOpen={Boolean(selectedClientId)}
        onClose={() => setSelectedClientId(null)}
        clientId={selectedClientId}
        onBookAgain={onBookAgain}
        onOpenMessageModal={onOpenMessageModal}
      />

      {/* New Client Modal */}
      <Modal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        title="Новый клиент"
        description="Добавление клиента в базу CRM"
        footer={
          <>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowAddModal(false)}
              disabled={saving}
            >
              Отмена
            </Button>
            <Button
              variant="primary"
              size="sm"
              isLoading={saving}
              onClick={handleCreateClient}
            >
              Создать клиента
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          {formError && (
            <div className="p-2.5 rounded-crm bg-rose-50 border border-rose-200 text-rose-700 text-xs">
              {formError}
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
              Имя клиента <span className="text-rose-500">*</span>
            </label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Например: Али Гасанов"
              autoFocus
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
              Телефон <span className="text-rose-500">*</span>
            </label>
            <Input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+994 50 123 45 67"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-secondary mb-1.5">
              Заметка
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Предпочтения, особенности стрижки..."
              className="w-full p-2.5 bg-surface text-primary text-sm rounded-crm border border-border placeholder:text-secondary/60 focus:outline-none focus:border-primary resize-none"
            />
          </div>
        </div>
      </Modal>
    </div>
  );
}
