"use client";

import React, { useState, useEffect } from "react";
import { Drawer } from "../ui/Drawer";
import { Button } from "../ui/Button";
import { Badge } from "../ui/Badge";
import { useToast } from "../ui/Toast";
import {
  User,
  Phone,
  RotateCcw,
  MessageSquare,
  Clock,
  Sparkles,
  Plus,
  Send,
  Calendar,
  AlertCircle,
} from "lucide-react";
import {
  formatPhone,
  formatRelativeDate,
  formatAppointmentDate,
  formatCurrency,
  APPOINTMENT_STATUS_MAP,
  AppointmentStatusKey,
} from "@/lib/utils";

interface ClientDetailsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  clientId: string | null;
  onBookAgain: (client: any, barberId?: string, serviceIds?: string[]) => void;
  onOpenMessageModal: (client: any) => void;
}

export function ClientDetailsDrawer({
  isOpen,
  onClose,
  clientId,
  onBookAgain,
  onOpenMessageModal,
}: ClientDetailsDrawerProps) {
  const { toast, success, error: toastError } = useToast();
  const [client, setClient] = useState<any | null>(null);
  const [loading, setLoading] = useState(false);
  const [newNoteText, setNewNoteText] = useState("");
  const [addingNote, setAddingNote] = useState(false);

  const fetchClientDetails = () => {
    if (!clientId) return;
    setLoading(true);
    fetch(`/api/clients/${clientId}`)
      .then((r) => r.json())
      .then((d) => {
        setClient(d.client);
      })
      .catch((err) => console.error("Error loading client details:", err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    if (isOpen && clientId) {
      fetchClientDetails();
    } else {
      setClient(null);
      setNewNoteText("");
    }
  }, [isOpen, clientId]);

  const handleAddNote = async () => {
    if (!newNoteText.trim() || !client) return;
    setAddingNote(true);
    try {
      const res = await fetch(`/api/clients/${client.id}/notes`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: newNoteText }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Не удалось сохранить заметку");
      success("✓ Заметка добавлена");
      setNewNoteText("");
      fetchClientDetails();
    } catch (err: any) {
      toastError(err.message);
    } finally {
      setAddingNote(false);
    }
  };

  if (!isOpen) return null;

  return (
    <Drawer
      isOpen={isOpen}
      onClose={onClose}
      title={client?.name || "Карточка клиента"}
      description={client ? formatPhone(client.phone) : ""}
      footer={
        client && (
          <div className="flex items-center justify-between gap-3">
            <Button
              variant="outline"
              size="sm"
              className="flex-1"
              onClick={() => onOpenMessageModal(client)}
            >
              <MessageSquare className="w-3.5 h-3.5 mr-1.5" />
              Написать
            </Button>
            <Button
              variant="primary"
              size="sm"
              className="flex-1"
              onClick={() => {
                const favBarberId = client.appointments[0]?.barberId;
                const favServices = client.appointments[0]?.services.map((s: any) => s.serviceId) || [];
                onBookAgain(client, favBarberId, favServices);
                onClose();
              }}
            >
              <RotateCcw className="w-3.5 h-3.5 mr-1.5" />
              Записать снова
            </Button>
          </div>
        )
      }
    >
      {loading || !client ? (
        <div className="py-12 text-center text-xs text-secondary">
          Загрузка информации о клиенте...
        </div>
      ) : (
        <div className="space-y-5">
          {/* Summary stats (Section 24) */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3.5 rounded-crm bg-brand-50 border border-border">
              <div className="text-[11px] font-semibold text-secondary uppercase">
                Всего визитов
              </div>
              <div className="text-xl font-bold text-primary mt-1">
                {client.totalVisits}{" "}
                <span className="text-xs font-normal text-secondary">
                  {client.totalVisits === 1 ? "визит" : "визитов"}
                </span>
              </div>
            </div>

            <div className="p-3.5 rounded-crm bg-brand-50 border border-border">
              <div className="text-[11px] font-semibold text-secondary uppercase">
                Последний визит
              </div>
              <div className="text-sm font-bold text-primary mt-1">
                {formatRelativeDate(client.lastVisitAt)}
              </div>
            </div>
          </div>

          {/* Favorite Services (Section 24) */}
          {client.favoriteServices && client.favoriteServices.length > 0 && (
            <div className="p-4 rounded-crm border border-border bg-surface space-y-2">
              <div className="text-xs font-semibold uppercase tracking-wider text-secondary flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                Любимые услуги
              </div>
              <div className="space-y-1.5 pt-1">
                {client.favoriteServices.slice(0, 3).map((item: any) => (
                  <div
                    key={item.name}
                    className="flex items-center justify-between text-xs py-1 px-2 rounded bg-brand-50"
                  >
                    <span className="font-medium text-primary">{item.name}</span>
                    <span className="text-secondary font-semibold">{item.count} раз</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* General Notes & Notes History (Section 25) */}
          <div className="p-4 rounded-crm border border-border bg-surface space-y-3">
            <div className="text-xs font-semibold uppercase tracking-wider text-secondary">
              Заметки мастера
            </div>

            {client.notes && (
              <div className="text-xs text-primary bg-amber-50/60 border border-amber-200/60 p-2.5 rounded-crm">
                <span className="font-semibold text-amber-900 block mb-0.5">Общая заметка:</span>
                {client.notes}
              </div>
            )}

            {/* Add new note */}
            <div className="space-y-2 pt-1">
              <textarea
                rows={2}
                value={newNoteText}
                onChange={(e) => setNewNoteText(e.target.value)}
                placeholder="Добавить заметку о предпочтениях клиента..."
                className="w-full p-2.5 bg-brand-50 text-xs rounded-crm border border-border placeholder:text-secondary/60 focus:outline-none focus:border-primary resize-none"
              />
              <div className="flex justify-end">
                <Button
                  variant="outline"
                  size="sm"
                  isLoading={addingNote}
                  onClick={handleAddNote}
                  disabled={!newNoteText.trim()}
                  className="h-7 text-xs"
                >
                  <Plus className="w-3 h-3 mr-1" />
                  Сохранить заметку
                </Button>
              </div>
            </div>

            {/* Notes history */}
            {client.notesHistory && client.notesHistory.length > 0 && (
              <div className="space-y-2 pt-2 border-t border-border/70">
                <span className="text-[11px] font-semibold text-secondary uppercase">
                  История заметок
                </span>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {client.notesHistory.map((n: any) => (
                    <div key={n.id} className="p-2 rounded bg-brand-50 text-xs">
                      <div className="flex items-center justify-between text-[10px] text-secondary mb-1">
                        <span className="font-semibold text-primary">{n.author.name}</span>
                        <span>{formatRelativeDate(n.createdAt)}</span>
                      </div>
                      <p className="text-neutral-800 leading-snug">{n.text}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* History of Appointments (Section 24) */}
          <div className="p-4 rounded-crm border border-border bg-surface space-y-3">
            <div className="text-xs font-semibold uppercase tracking-wider text-secondary">
              История записей
            </div>

            {client.appointments && client.appointments.length > 0 ? (
              <div className="divide-y divide-border/60 max-h-60 overflow-y-auto">
                {client.appointments.map((app: any) => {
                  const statusConfig =
                    APPOINTMENT_STATUS_MAP[app.status as AppointmentStatusKey] ||
                    APPOINTMENT_STATUS_MAP.pending;
                  return (
                    <div key={app.id} className="py-2.5 text-xs flex items-center justify-between">
                      <div>
                        <div className="font-medium text-primary">
                          {app.services.map((s: any) => s.service.name).join(" + ")}
                        </div>
                        <div className="text-[11px] text-secondary mt-0.5">
                          {formatAppointmentDate(app.startAt)} • {app.barber.name}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold text-primary">
                          {formatCurrency(app.totalPrice)}
                        </div>
                        <span
                          className={`inline-block px-1.5 py-0.2 rounded text-[9px] font-medium border mt-0.5 ${statusConfig.bg}`}
                        >
                          {statusConfig.label}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-xs text-secondary py-3 text-center">
                У клиента ещё нет записей в истории
              </div>
            )}
          </div>
        </div>
      )}
    </Drawer>
  );
}
