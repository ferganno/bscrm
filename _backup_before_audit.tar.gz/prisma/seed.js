const { PrismaClient } = require("@prisma/client");

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding BarberStudio database...");

  // Clean existing data
  await prisma.sentMessage.deleteMany({});
  await prisma.messageTemplate.deleteMany({});
  await prisma.appointmentService.deleteMany({});
  await prisma.appointment.deleteMany({});
  await prisma.clientNote.deleteMany({});
  await prisma.client.deleteMany({});
  await prisma.service.deleteMany({});
  await prisma.barberSchedule.deleteMany({});
  await prisma.user.deleteMany({});
  await prisma.shop.deleteMany({});

  // 1. Create Shop
  const shop = await prisma.shop.create({
    data: {
      name: "Barber Studio",
      address: "ул. Низами, 42, Баку",
      timezone: "Asia/Baku",
      autoReminder24h: true,
      autoReminder2h: true,
      primaryChannel: "whatsapp",
      fallbackChannel: "sms",
    },
  });

  console.log(`Shop created: ${shop.name} (${shop.id})`);

  // 2. Create Users (Owner, Admin, Barbers)
  const owner = await prisma.user.create({
    data: {
      shopId: shop.id,
      name: "Эльдар Алиев",
      email: "owner@barberstudio.az",
      phone: "+994501112233",
      role: "owner",
      color: "#111111",
      isActive: true,
    },
  });

  const admin = await prisma.user.create({
    data: {
      shopId: shop.id,
      name: "Нигяр Мамедова",
      email: "admin@barberstudio.az",
      phone: "+994502223344",
      role: "admin",
      color: "#6366F1",
      isActive: true,
    },
  });

  const ruslan = await prisma.user.create({
    data: {
      shopId: shop.id,
      name: "Руслан",
      email: "ruslan@barberstudio.az",
      phone: "+994503334455",
      role: "barber",
      color: "#2563EB", // Blue
      isActive: true,
    },
  });

  const ahmed = await prisma.user.create({
    data: {
      shopId: shop.id,
      name: "Ахмед",
      email: "ahmed@barberstudio.az",
      phone: "+994504445566",
      role: "barber",
      color: "#0D9488", // Teal
      isActive: true,
    },
  });

  const elvin = await prisma.user.create({
    data: {
      shopId: shop.id,
      name: "Эльвин",
      email: "elvin@barberstudio.az",
      phone: "+994505556677",
      role: "barber",
      color: "#D97706", // Amber
      isActive: true,
    },
  });

  const barbers = [ruslan, ahmed, elvin];

  // 3. Barber Schedules (Mon to Sun)
  // DayOfWeek: 0 = Sun, 1 = Mon, ..., 6 = Sat
  for (const barber of [ruslan, ahmed]) {
    for (let day = 0; day <= 6; day++) {
      await prisma.barberSchedule.create({
        data: {
          barberId: barber.id,
          dayOfWeek: day,
          startTime: "10:00",
          endTime: "20:00",
          isWorking: day !== 0, // Sunday is day off
        },
      });
    }
  }

  // Elvin schedule: Tue-Sun 11:00-21:00, Monday off
  for (let day = 0; day <= 6; day++) {
    await prisma.barberSchedule.create({
      data: {
        barberId: elvin.id,
        dayOfWeek: day,
        startTime: "11:00",
        endTime: "21:00",
        isWorking: day !== 1, // Monday is day off
      },
    });
  }

  // 4. Create Services
  const serviceHaircut = await prisma.service.create({
    data: {
      shopId: shop.id,
      name: "Мужская стрижка (Haircut)",
      durationMinutes: 30,
      price: 15,
      isActive: true,
      sortOrder: 1,
    },
  });

  const serviceBeard = await prisma.service.create({
    data: {
      shopId: shop.id,
      name: "Моделирование бороды (Beard)",
      durationMinutes: 20,
      price: 10,
      isActive: true,
      sortOrder: 2,
    },
  });

  const serviceCombo = await prisma.service.create({
    data: {
      shopId: shop.id,
      name: "Комплекс: Стрижка + Борода",
      durationMinutes: 50,
      price: 22,
      isActive: true,
      sortOrder: 3,
    },
  });

  const serviceShave = await prisma.service.create({
    data: {
      shopId: shop.id,
      name: "Королевское бритьё (Royal Shave)",
      durationMinutes: 40,
      price: 18,
      isActive: true,
      sortOrder: 4,
    },
  });

  const serviceKids = await prisma.service.create({
    data: {
      shopId: shop.id,
      name: "Детская стрижка (Kids Haircut)",
      durationMinutes: 30,
      price: 12,
      isActive: true,
      sortOrder: 5,
    },
  });

  // 5. Create Clients
  const ali = await prisma.client.create({
    data: {
      shopId: shop.id,
      name: "Али Гасанов",
      phone: "+994 50 123 45 67",
      phoneNormalized: "+994501234567",
      notes: "Предпочитает low fade, чай с лимоном.",
    },
  });

  const murad = await prisma.client.create({
    data: {
      shopId: shop.id,
      name: "Мурад Мамедов",
      phone: "+994 50 765 43 21",
      phoneNormalized: "+994507654321",
      notes: "Любит оставить верх подлиннее, строгий контур.",
    },
  });

  const kenan = await prisma.client.create({
    data: {
      shopId: shop.id,
      name: "Кенан Ибрагимов",
      phone: "+994 51 987 65 43",
      phoneNormalized: "+994519876543",
      notes: "Четкий контур бороды, воск без сильного запаха.",
    },
  });

  const orkhan = await prisma.client.create({
    data: {
      shopId: shop.id,
      name: "Орхан Гусейнов",
      phone: "+994 55 321 65 49",
      phoneNormalized: "+994553216549",
      notes: "Чувствительная кожа, использовать успокаивающий лосьон.",
    },
  });

  const rauf = await prisma.client.create({
    data: {
      shopId: shop.id,
      name: "Рауф Бабаев",
      phone: "+994 70 456 12 38",
      phoneNormalized: "+994704561238",
      notes: "Стрижка только ножницами, машинкой не трогать.",
    },
  });

  const teymur = await prisma.client.create({
    data: {
      shopId: shop.id,
      name: "Теймур Самедов",
      phone: "+994 50 888 99 00",
      phoneNormalized: "+994508889900",
      notes: "Приходит редко, обычно перед важными событиями.",
      createdAt: new Date(Date.now() - 60 * 24 * 3600 * 1000), // 60 days ago
    },
  });

  const zaur = await prisma.client.create({
    data: {
      shopId: shop.id,
      name: "Заур Ахмедов",
      phone: "+994 55 777 11 22",
      phoneNormalized: "+994557771122",
      notes: "Постоянный клиент, каждые 2 недели.",
    },
  });

  const farid = await prisma.client.create({
    data: {
      shopId: shop.id,
      name: "Фарид Джафаров",
      phone: "+994 51 444 88 99",
      phoneNormalized: "+994514448899",
      notes: "Быстрый fade перед тренировкой.",
    },
  });

  // Client notes
  await prisma.clientNote.create({
    data: {
      clientId: ali.id,
      userId: ruslan.id,
      text: "Любит оставить верх подлиннее, бока под единицу.",
      createdAt: new Date(Date.now() - 14 * 24 * 3600 * 1000),
    },
  });

  await prisma.clientNote.create({
    data: {
      clientId: ali.id,
      userId: ahmed.id,
      text: "Перешел на классическую укладку с матовой глиной.",
      createdAt: new Date(Date.now() - 3 * 24 * 3600 * 1000),
    },
  });

  await prisma.clientNote.create({
    data: {
      clientId: murad.id,
      userId: ruslan.id,
      text: "Бороду не филировать, делать ровный срез.",
      createdAt: new Date(Date.now() - 7 * 24 * 3600 * 1000),
    },
  });

  // 6. Templates
  const tpl24h = await prisma.messageTemplate.create({
    data: {
      shopId: shop.id,
      type: "reminder_24h",
      title: "Напоминание за 24 часа",
      text: "Здравствуйте, {имя}!\n\nНапоминаем, что завтра у вас запись в {время} к барберу {барбер}.\nУслуги: {услуги}\nАдрес: {адрес}\n\nЖдём вас в {название_барбершопа}!",
      isActive: true,
    },
  });

  const tpl2h = await prisma.messageTemplate.create({
    data: {
      shopId: shop.id,
      type: "reminder_2h",
      title: "Напоминание за 2 часа",
      text: "Здравствуйте, {имя}!\n\nЖдём вас сегодня в {время} к барберу {барбер}.\nАдрес: {адрес}\n\nЕсли опаздываете, пожалуйста, предупредите нас.",
      isActive: true,
    },
  });

  const tplManual = await prisma.messageTemplate.create({
    data: {
      shopId: shop.id,
      type: "manual",
      title: "Ручное уведомление о записи",
      text: "Здравствуйте, {имя}! Вы записаны на {дата} в {время} к мастеру {барбер}. Ждём вас в {название_барбершопа} ({адрес})!",
      isActive: true,
    },
  });

  // 7. Appointments for Today and Past
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  function createTime(baseDate, hours, minutes) {
    const d = new Date(baseDate);
    d.setHours(hours, minutes, 0, 0);
    return d;
  }

  // Today's appointments
  // 1. Ruslan - Ali (10:00 - 10:30, completed)
  const app1 = await prisma.appointment.create({
    data: {
      shopId: shop.id,
      clientId: ali.id,
      barberId: ruslan.id,
      createdBy: admin.id,
      startAt: createTime(today, 10, 0),
      endAt: createTime(today, 10, 30),
      status: "completed",
      totalPrice: 15,
      manualDuration: 30,
      comment: "Постоянный клиент",
      services: {
        create: [
          {
            serviceId: serviceHaircut.id,
            price: 15,
            durationMinutes: 30,
          },
        ],
      },
    },
  });

  // 2. Ruslan - Murad (11:30 - 12:20, completed)
  const app2 = await prisma.appointment.create({
    data: {
      shopId: shop.id,
      clientId: murad.id,
      barberId: ruslan.id,
      createdBy: admin.id,
      startAt: createTime(today, 11, 30),
      endAt: createTime(today, 12, 20),
      status: "completed",
      totalPrice: 22,
      manualDuration: 50,
      comment: "Стрижка + борода",
      services: {
        create: [
          {
            serviceId: serviceCombo.id,
            price: 22,
            durationMinutes: 50,
          },
        ],
      },
    },
  });

  // 3. Ruslan - Kenan (14:00 - 14:30, completed)
  const app3 = await prisma.appointment.create({
    data: {
      shopId: shop.id,
      clientId: kenan.id,
      barberId: ruslan.id,
      createdBy: admin.id,
      startAt: createTime(today, 14, 0),
      endAt: createTime(today, 14, 30),
      status: "completed",
      totalPrice: 15,
      manualDuration: 30,
      services: {
        create: [
          {
            serviceId: serviceHaircut.id,
            price: 15,
            durationMinutes: 30,
          },
        ],
      },
    },
  });

  // 4. Ruslan - Orkhan (16:00 - 16:40, completed)
  const app4 = await prisma.appointment.create({
    data: {
      shopId: shop.id,
      clientId: orkhan.id,
      barberId: ruslan.id,
      createdBy: ruslan.id,
      startAt: createTime(today, 16, 0),
      endAt: createTime(today, 16, 40),
      status: "completed",
      totalPrice: 18,
      manualDuration: 40,
      services: {
        create: [
          {
            serviceId: serviceShave.id,
            price: 18,
            durationMinutes: 40,
          },
        ],
      },
    },
  });

  // 5. Ruslan - Ali (18:30 - 19:20, pending)
  const app5 = await prisma.appointment.create({
    data: {
      shopId: shop.id,
      clientId: ali.id,
      barberId: ruslan.id,
      createdBy: admin.id,
      startAt: createTime(today, 18, 30),
      endAt: createTime(today, 19, 20),
      status: "pending",
      totalPrice: 25,
      manualDuration: 50,
      comment: "Клиент просил чай с лимоном к приходу",
      services: {
        create: [
          {
            serviceId: serviceHaircut.id,
            price: 15,
            durationMinutes: 30,
          },
          {
            serviceId: serviceBeard.id,
            price: 10,
            durationMinutes: 20,
          },
        ],
      },
    },
  });

  // 6. Ahmed - Rauf (10:30 - 11:00, completed)
  const app6 = await prisma.appointment.create({
    data: {
      shopId: shop.id,
      clientId: rauf.id,
      barberId: ahmed.id,
      createdBy: admin.id,
      startAt: createTime(today, 10, 30),
      endAt: createTime(today, 11, 0),
      status: "completed",
      totalPrice: 15,
      manualDuration: 30,
      services: {
        create: [
          {
            serviceId: serviceHaircut.id,
            price: 15,
            durationMinutes: 30,
          },
        ],
      },
    },
  });

  // 7. Ahmed - Farid (12:00 - 12:20, completed)
  const app7 = await prisma.appointment.create({
    data: {
      shopId: shop.id,
      clientId: farid.id,
      barberId: ahmed.id,
      createdBy: ahmed.id,
      startAt: createTime(today, 12, 0),
      endAt: createTime(today, 12, 20),
      status: "completed",
      totalPrice: 10,
      manualDuration: 20,
      services: {
        create: [
          {
            serviceId: serviceBeard.id,
            price: 10,
            durationMinutes: 20,
          },
        ],
      },
    },
  });

  // 8. Ahmed - Zaur (15:00 - 15:50, pending)
  const app8 = await prisma.appointment.create({
    data: {
      shopId: shop.id,
      clientId: zaur.id,
      barberId: ahmed.id,
      createdBy: admin.id,
      startAt: createTime(today, 15, 0),
      endAt: createTime(today, 15, 50),
      status: "pending",
      totalPrice: 22,
      manualDuration: 50,
      services: {
        create: [
          {
            serviceId: serviceCombo.id,
            price: 22,
            durationMinutes: 50,
          },
        ],
      },
    },
  });

  // 9. Ahmed - Murad (17:30 - 18:00, pending)
  const app9 = await prisma.appointment.create({
    data: {
      shopId: shop.id,
      clientId: murad.id,
      barberId: ahmed.id,
      createdBy: admin.id,
      startAt: createTime(today, 17, 30),
      endAt: createTime(today, 18, 0),
      status: "pending",
      totalPrice: 15,
      manualDuration: 30,
      services: {
        create: [
          {
            serviceId: serviceHaircut.id,
            price: 15,
            durationMinutes: 30,
          },
        ],
      },
    },
  });

  // 10. Elvin - Kenan (11:00 - 11:30, completed)
  const app10 = await prisma.appointment.create({
    data: {
      shopId: shop.id,
      clientId: kenan.id,
      barberId: elvin.id,
      createdBy: admin.id,
      startAt: createTime(today, 11, 0),
      endAt: createTime(today, 11, 30),
      status: "completed",
      totalPrice: 12,
      manualDuration: 30,
      services: {
        create: [
          {
            serviceId: serviceKids.id,
            price: 12,
            durationMinutes: 30,
          },
        ],
      },
    },
  });

  // 11. Elvin - Teymur (13:00 - 13:50, no_show)
  const app11 = await prisma.appointment.create({
    data: {
      shopId: shop.id,
      clientId: teymur.id,
      barberId: elvin.id,
      createdBy: admin.id,
      startAt: createTime(today, 13, 0),
      endAt: createTime(today, 13, 50),
      status: "no_show",
      totalPrice: 22,
      manualDuration: 50,
      comment: "Не брал трубку, не пришёл",
      services: {
        create: [
          {
            serviceId: serviceCombo.id,
            price: 22,
            durationMinutes: 50,
          },
        ],
      },
    },
  });

  // 12. Elvin - Orkhan (16:30 - 17:10, pending)
  const app12 = await prisma.appointment.create({
    data: {
      shopId: shop.id,
      clientId: orkhan.id,
      barberId: elvin.id,
      createdBy: elvin.id,
      startAt: createTime(today, 16, 30),
      endAt: createTime(today, 17, 10),
      status: "pending",
      totalPrice: 18,
      manualDuration: 40,
      services: {
        create: [
          {
            serviceId: serviceShave.id,
            price: 18,
            durationMinutes: 40,
          },
        ],
      },
    },
  });

  // Past appointments for Ali (to give him 14 visits total)
  for (let i = 1; i <= 12; i++) {
    const pastDate = new Date(Date.now() - (i * 12 + 5) * 24 * 3600 * 1000);
    pastDate.setHours(11, 0, 0, 0);
    const pastEnd = new Date(pastDate.getTime() + 50 * 60 * 1000);

    await prisma.appointment.create({
      data: {
        shopId: shop.id,
        clientId: ali.id,
        barberId: i % 2 === 0 ? ruslan.id : ahmed.id,
        createdBy: admin.id,
        startAt: pastDate,
        endAt: pastEnd,
        status: "completed",
        totalPrice: i % 3 === 0 ? 15 : 22,
        manualDuration: i % 3 === 0 ? 30 : 50,
        createdAt: pastDate,
        services: {
          create: [
            {
              serviceId: i % 3 === 0 ? serviceHaircut.id : serviceCombo.id,
              price: i % 3 === 0 ? 15 : 22,
              durationMinutes: i % 3 === 0 ? 30 : 50,
            },
          ],
        },
      },
    });
  }

  // Sent messages log
  await prisma.sentMessage.create({
    data: {
      shopId: shop.id,
      appointmentId: app5.id,
      clientId: ali.id,
      channel: "whatsapp",
      type: "reminder_24h",
      status: "sent",
      providerMessageId: "wamid_demo_1092830129",
      text: "Здравствуйте, Али Гасанов!\n\nНапоминаем, что сегодня у вас запись в 18:30 к барберу Руслан.\nУслуги: Мужская стрижка, Моделирование бороды\nАдрес: ул. Низами, 42, Баку\n\nЖдём вас в Barber Studio!",
      sentAt: new Date(Date.now() - 4 * 3600 * 1000),
    },
  });

  await prisma.sentMessage.create({
    data: {
      shopId: shop.id,
      appointmentId: app8.id,
      clientId: zaur.id,
      channel: "whatsapp",
      type: "reminder_2h",
      status: "sent",
      providerMessageId: "wamid_demo_8819203112",
      text: "Здравствуйте, Заур Ахмедов!\n\nЖдём вас сегодня в 15:00 к барберу Ахмед.\nАдрес: ул. Низами, 42, Баку\n\nЕсли опаздываете, пожалуйста, предупредите нас.",
      sentAt: new Date(Date.now() - 2 * 3600 * 1000),
    },
  });

  await prisma.sentMessage.create({
    data: {
      shopId: shop.id,
      appointmentId: app11.id,
      clientId: teymur.id,
      channel: "sms",
      type: "reminder_24h",
      status: "failed",
      errorMessage: "Абонент временно недоступен / сеть занята",
      text: "Здравствуйте, Теймур! Напоминаем о записи сегодня в 13:00 к барберу Эльвин.",
      sentAt: null,
    },
  });

  console.log("Seeding complete! Successfully created demo barbershop with realistic data.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
