/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Ensure fast hot-reload and server actions
};

export default nextConfig;
