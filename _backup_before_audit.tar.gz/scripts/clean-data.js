const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

async function clean() {
  console.log("Cleaning appointments and messages...");
  const delSvc = await prisma.appointmentService.deleteMany({});
  const delApp = await prisma.appointment.deleteMany({});
  const delMsg = await prisma.sentMessage.deleteMany({});

  console.log(`Deleted ${delSvc.count} appointment services`);
  console.log(`Deleted ${delApp.count} appointments`);
  console.log(`Deleted ${delMsg.count} messages`);
  console.log("Services and clients preserved!");
}

clean()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
