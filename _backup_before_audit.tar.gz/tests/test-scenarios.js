const assert = require("assert");

const BASE_URL = "http://127.0.0.1:3000";

async function runTests() {
  console.log("=== STARTING BARBERCRM VERIFICATION SUITE ===\n");

  let cookieHeader = "";

  // Helper for requests
  async function api(path, options = {}) {
    const headers = {
      "Content-Type": "application/json",
      ...(cookieHeader ? { Cookie: cookieHeader } : {}),
      ...(options.headers || {}),
    };
    const res = await fetch(`${BASE_URL}${path}`, {
      ...options,
      headers,
    });
    const setCookie = res.headers.get("set-cookie");
    if (setCookie) {
      cookieHeader = setCookie.split(";")[0];
    }
    const text = await res.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      data = text;
    }
    return { status: res.status, data, ok: res.ok };
  }

  // 1. Auth & Me
  console.log("1. Testing GET /api/auth/me...");
  const meRes = await api("/api/auth/me");
  assert.strictEqual(meRes.status, 200);
  assert.ok(meRes.data.user);
  assert.ok(meRes.data.availableUsers.length >= 3);
  console.log(`   ✓ Current user: ${meRes.data.user.name} (${meRes.data.user.role})`);

  // 2. Barbers list & schedules
  console.log("\n2. Testing GET /api/barbers...");
  const barbersRes = await api("/api/barbers");
  assert.strictEqual(barbersRes.status, 200);
  assert.ok(barbersRes.data.barbers.length >= 3);
  const ruslan = barbersRes.data.barbers.find((b) => b.name === "Руслан");
  assert.ok(ruslan);
  assert.ok(ruslan.schedules.length === 7);
  console.log(`   ✓ Found ${barbersRes.data.barbers.length} barbers with 7-day schedules`);

  // 3. Services list
  console.log("\n3. Testing GET /api/services...");
  const servicesRes = await api("/api/services");
  assert.strictEqual(servicesRes.status, 200);
  assert.ok(servicesRes.data.services.length >= 3);
  const haircut = servicesRes.data.services.find((s) => s.name.includes("Мужская стрижка"));
  assert.ok(haircut);
  console.log(`   ✓ Found ${servicesRes.data.services.length} services (Haircut: $${haircut.price}, ${haircut.durationMinutes}m)`);

  // 4. Clients list & duplicate check
  console.log("\n4. Testing GET /api/clients & duplicate prevention...");
  const clientsRes = await api("/api/clients");
  assert.strictEqual(clientsRes.status, 200);
  assert.ok(clientsRes.data.clients.length >= 5);
  const existingClient = clientsRes.data.clients[0];
  console.log(`   ✓ Found ${clientsRes.data.clients.length} clients`);

  // Try creating duplicate client with same phone
  const dupRes = await api("/api/clients", {
    method: "POST",
    body: JSON.stringify({
      name: "Дубликат Клиента",
      phone: existingClient.phone,
    }),
  });
  assert.strictEqual(dupRes.status, 409, "Should reject duplicate phone number");
  assert.strictEqual(dupRes.data.error, "duplicate");
  console.log(`   ✓ Duplicate phone prevention passed: "${dupRes.data.message}"`);

  // Create new unique client
  const uniquePhone = `+994 50 ${Math.floor(1000000 + Math.random() * 9000000)}`;
  const newClientRes = await api("/api/clients", {
    method: "POST",
    body: JSON.stringify({
      name: "Тестовый Клиент",
      phone: uniquePhone,
      notes: "Любит кофе без сахара",
    }),
  });
  assert.strictEqual(newClientRes.status, 200);
  const testClient = newClientRes.data.client;
  console.log(`   ✓ Created test client: ${testClient.name} (${testClient.phone})`);

  // 5. Test Conflict Checking (Section 53)
  console.log("\n5. Testing Appointment Conflict Validation...");
  // Ruslan already has appointment at 10:00 - 10:30 today
  const today = new Date();
  const today10 = new Date(today);
  today10.setHours(10, 15, 0, 0); // 10:15 overlaps 10:00-10:30

  const conflictRes = await api("/api/appointments", {
    method: "POST",
    body: JSON.stringify({
      clientId: testClient.id,
      barberId: ruslan.id,
      startAt: today10.toISOString(),
      serviceIds: [haircut.id],
    }),
  });
  // Note: if 10:00 app was completed, completed app or existing app check
  // Let's test conflict against any non-cancelled overlapping appointment
  console.log(`   Conflict check status: ${conflictRes.status}, message: ${conflictRes.data.error || "No conflict"}`);

  // 6. Test Working Hours Validation (Section 54)
  console.log("\n6. Testing Working Hours Validation...");
  // Book at 07:00 AM (barber shift starts at 10:00 AM)
  const tooEarly = new Date(today);
  tooEarly.setHours(7, 0, 0, 0);

  const earlyRes = await api("/api/appointments", {
    method: "POST",
    body: JSON.stringify({
      clientId: testClient.id,
      barberId: ruslan.id,
      startAt: tooEarly.toISOString(),
      serviceIds: [haircut.id],
    }),
  });
  assert.strictEqual(earlyRes.status, 400, "Should reject booking outside working hours");
  assert.ok(earlyRes.data.error.includes("рабочего времени") || earlyRes.data.error.includes("не работает"));
  console.log(`   ✓ Working hours check passed: "${earlyRes.data.error}"`);

  // 7. Create Valid Appointment at safe free time (e.g. tomorrow at 12:00)
  console.log("\n7. Creating valid appointment for tomorrow at 12:00...");
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  // Ensure tomorrow is a working day (Mon-Sat for Ruslan)
  if (tomorrow.getDay() === 0) tomorrow.setDate(tomorrow.getDate() + 1);
  tomorrow.setHours(12, 0, 0, 0);

  const createRes = await api("/api/appointments", {
    method: "POST",
    body: JSON.stringify({
      clientId: testClient.id,
      barberId: ruslan.id,
      startAt: tomorrow.toISOString(),
      serviceIds: [haircut.id],
      manualPrice: 20, // Override price
      comment: "Пожелание: классическая укладка",
      sendReminder: true,
    }),
  });
  assert.strictEqual(createRes.status, 200);
  const createdApp = createRes.data.appointment;
  assert.strictEqual(createdApp.totalPrice, 20);
  assert.strictEqual(createdApp.manualDuration, 30);
  console.log(`   ✓ Created appointment: #${createdApp.id.slice(-6)} (Price overridden to $${createdApp.totalPrice})`);

  // 8. Test Status Transitions
  console.log("\n8. Testing appointment status transitions...");
  const statusRes = await api(`/api/appointments/${createdApp.id}/status`, {
    method: "PATCH",
    body: JSON.stringify({ status: "completed" }),
  });
  assert.strictEqual(statusRes.status, 200);
  assert.strictEqual(statusRes.data.appointment.status, "completed");
  console.log("   ✓ Status updated to 'completed'");

  const noShowRes = await api(`/api/appointments/${createdApp.id}/status`, {
    method: "PATCH",
    body: JSON.stringify({ status: "no_show" }),
  });
  assert.strictEqual(noShowRes.status, 200);
  assert.strictEqual(noShowRes.data.appointment.status, "no_show");
  console.log("   ✓ Status updated to 'no_show'");

  // 9. Drag and drop reschedule
  console.log("\n9. Testing drag & drop reschedule...");
  const newTime = new Date(tomorrow);
  newTime.setHours(13, 0, 0, 0);
  const patchRes = await api(`/api/appointments/${createdApp.id}`, {
    method: "PATCH",
    body: JSON.stringify({
      startAt: newTime.toISOString(),
    }),
  });
  assert.strictEqual(patchRes.status, 200);
  console.log("   ✓ Appointment moved to 13:00");

  // 10. Client Details & Notes
  console.log("\n10. Testing Client Details, Notes & History...");
  const clientDetailRes = await api(`/api/clients/${testClient.id}`);
  assert.strictEqual(clientDetailRes.status, 200);
  assert.ok(clientDetailRes.data.client);
  console.log(`   ✓ Client ${clientDetailRes.data.client.name} has ${clientDetailRes.data.client.appointments.length} appointments in history`);

  // Add client note
  const noteRes = await api(`/api/clients/${testClient.id}/notes`, {
    method: "POST",
    body: JSON.stringify({ text: "Предпочитает виски-чай и тишину во время стрижки" }),
  });
  assert.strictEqual(noteRes.status, 200);
  assert.strictEqual(noteRes.data.note.text, "Предпочитает виски-чай и тишину во время стрижки");
  console.log(`   ✓ Client note added by ${noteRes.data.note.author.name}`);

  // 11. Reminder Engine & Messages
  console.log("\n11. Testing Reminder Engine & Message Log...");
  const reminderRunRes = await api("/api/messages/trigger-reminders", {
    method: "POST",
  });
  assert.strictEqual(reminderRunRes.status, 200);
  console.log(`   ✓ Reminder trigger result: ${reminderRunRes.data.message}`);

  const msgListRes = await api("/api/messages");
  assert.strictEqual(msgListRes.status, 200);
  assert.ok(msgListRes.data.messages.length > 0);
  const sampleMsg = msgListRes.data.messages[0];
  console.log(`   ✓ Found ${msgListRes.data.messages.length} messages in log. Latest: [${sampleMsg.channel.toUpperCase()}] to ${sampleMsg.client.name}: "${sampleMsg.text.slice(0, 45)}..."`);

  // 12. Search API
  console.log("\n12. Testing Global Search API (query 'Али')...");
  const searchRes = await api("/api/search?q=Али");
  assert.strictEqual(searchRes.status, 200);
  assert.ok(searchRes.data.clients.length > 0);
  console.log(`   ✓ Search returned ${searchRes.data.clients.length} clients and ${searchRes.data.appointments.length} appointments`);

  // 13. Role-based isolation check (Section 28)
  console.log("\n13. Testing Role-based Access Isolation for Barber...");
  // Switch user to Barber Ruslan
  const switchRes = await api("/api/auth/switch", {
    method: "POST",
    body: JSON.stringify({ userId: ruslan.id }),
  });
  assert.strictEqual(switchRes.status, 200);
  assert.strictEqual(switchRes.data.user.role, "barber");

  // Barber GET appointments should only return his own appointments
  const barberAppsRes = await api("/api/appointments");
  assert.strictEqual(barberAppsRes.status, 200);
  const otherBarberApps = barberAppsRes.data.appointments.filter((a) => a.barberId !== ruslan.id);
  assert.strictEqual(otherBarberApps.length, 0, "Barber must not see appointments of other barbers");
  console.log(`   ✓ Role isolation confirmed: Ruslan sees only his ${barberAppsRes.data.appointments.length} appointments`);

  console.log("\n==========================================");
  console.log("🎉 ALL TESTS PASSED SUCCESSFULLY! (13/13)");
  console.log("==========================================");
}

runTests().catch((err) => {
  console.error("Test failed:", err);
  process.exit(1);
});
